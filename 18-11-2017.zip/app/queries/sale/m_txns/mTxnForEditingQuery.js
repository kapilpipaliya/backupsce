import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/sale/m_txns/EditMTxn';

export default function (WrappedComponent) {
  const GET_M_TXN = gql`
    query getMTxn($id: ID) {
      mTxn(id: $id) {
        ...MTxnForEditingFragment
      }
    }
    ${fragments.mTxn}
  `;

  const withMTxnForEditing = graphql(GET_M_TXN, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMTxnForEditing(WrappedComponent);
}
