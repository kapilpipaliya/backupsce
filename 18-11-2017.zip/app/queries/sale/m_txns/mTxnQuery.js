import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MTxnFragments } from '../../../containers/sale/m_txns/MTxn';

export default function (WrappedComponent) {
  const GET_M_TXN = gql`
    query getMTxn($id: ID) {
      mTxn(id: $id) {
        ...MTxnFragment
      }
    }
    ${MTxnFragments.mTxn}
  `;

  const withMTxn = graphql(GET_M_TXN, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withMTxn(WrappedComponent);
}
