import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MTxnPreviewFragments } from '../../../containers/sale/m_txns/_MTxnPreview';

export const AllMTxnsQuery = gql`
  query allSaleMTxnsQuery {
    mTxnsCount
    allSaleMTxns {
      ...MTxnPreviewFragment
    }
  }
  ${MTxnPreviewFragments.mTxn}
`;

export default graphql(AllMTxnsQuery, {
  name: 'mtxns',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
