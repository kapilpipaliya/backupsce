import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/sale/m_txn_types/EditMTxnType';

export default function (WrappedComponent) {
  const GET_M_TXN_TYPE = gql`
    query getMTxnType($id: ID) {
      mTxnType(id: $id) {
        ...MTxnTypeForEditingFragment
      }
    }
    ${fragments.mTxnType}
  `;

  const withMTxnTypeForEditing = graphql(GET_M_TXN_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMTxnTypeForEditing(WrappedComponent);
}
