import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MTxnTypePreviewFragments } from '../../../containers/sale/m_txn_types/_MTxnTypePreview';

export const AllMTxnTypesQuery = gql`
  query allSaleMTxnTypesQuery {
    mTxnTypesCount
    allSaleMTxnTypes {
      ...MTxnTypePreviewFragment
    }
  }
  ${MTxnTypePreviewFragments.mTxnType}
`;

export default graphql(AllMTxnTypesQuery, {
  name: 'mtxntypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
