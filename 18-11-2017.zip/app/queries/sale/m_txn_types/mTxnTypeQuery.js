import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MTxnTypeFragments } from '../../../containers/sale/m_txn_types/MTxnType';

export default function (WrappedComponent) {
  const GET_M_TXN_TYPE = gql`
    query getMTxnType($id: ID) {
      mTxnType(id: $id) {
        ...MTxnTypeFragment
      }
    }
    ${MTxnTypeFragments.mTxnType}
  `;

  const withMTxnType = graphql(GET_M_TXN_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withMTxnType(WrappedComponent);
}
