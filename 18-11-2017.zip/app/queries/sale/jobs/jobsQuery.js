import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as JobPreviewFragments } from '../../../containers/sale/jobs/_JobPreview';

export const AllJobsQuery = gql`
  query allSaleJobsQuery {
    jobsCount
    allSaleJobs {
      ...JobPreviewFragment
    }
  }
  ${JobPreviewFragments.job}
`;

export default graphql(AllJobsQuery, {
  name: 'jobs',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
