import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as OrderTypeFragments } from '../../../containers/sale/order_types/OrderType';

export default function (WrappedComponent) {
  const GET_ORDER_TYPE = gql`
    query getOrderType($id: ID) {
      orderType(id: $id) {
        ...OrderTypeFragment
      }
    }
    ${OrderTypeFragments.orderType}
  `;

  const withOrderType = graphql(GET_ORDER_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withOrderType(WrappedComponent);
}
