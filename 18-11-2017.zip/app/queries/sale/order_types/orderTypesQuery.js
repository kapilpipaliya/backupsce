import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as OrderTypePreviewFragments } from '../../../containers/sale/order_types/_OrderTypePreview';

export const AllOrderTypesQuery = gql`
  query allSaleOrderTypesQuery {
    orderTypesCount
    allSaleOrderTypes {
      ...OrderTypePreviewFragment
    }
  }
  ${OrderTypePreviewFragments.orderType}
`;

export default graphql(AllOrderTypesQuery, {
  name: 'ordertypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
