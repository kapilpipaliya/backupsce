import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/sale/order_types/EditOrderType';

export default function (WrappedComponent) {
  const GET_ORDER_TYPE = gql`
    query getOrderType($id: ID) {
      orderType(id: $id) {
        ...OrderTypeForEditingFragment
      }
    }
    ${fragments.orderType}
  `;

  const withOrderTypeForEditing = graphql(GET_ORDER_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withOrderTypeForEditing(WrappedComponent);
}
