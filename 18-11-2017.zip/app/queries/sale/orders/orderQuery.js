import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as OrderFragments } from '../../../containers/sale/orders/Order';

export default function (WrappedComponent) {
  const GET_ORDER = gql`
    query getOrder($id: ID) {
      order(id: $id) {
        ...OrderFragment
      }
    }
    ${OrderFragments.order}
  `;

  const withOrder = graphql(GET_ORDER, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withOrder(WrappedComponent);
}
