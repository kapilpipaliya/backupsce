import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/sale/orders/EditOrder';

export default function (WrappedComponent) {
  const GET_ORDER = gql`
    query getOrder($id: ID) {
      order(id: $id) {
        ...OrderForEditingFragment
      }
    }
    ${fragments.order}
  `;

  const withOrderForEditing = graphql(GET_ORDER, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withOrderForEditing(WrappedComponent);
}
