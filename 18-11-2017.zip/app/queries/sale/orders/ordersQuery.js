import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as OrderPreviewFragments } from '../../../containers/sale/orders/_OrderPreview';

export const AllOrdersQuery = gql`
  query allSaleOrdersQuery {
    ordersCount
    allSaleOrders {
      ...OrderPreviewFragment
    }
  }
  ${OrderPreviewFragments.order}
`;

export default graphql(AllOrdersQuery, {
  name: 'orders',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
