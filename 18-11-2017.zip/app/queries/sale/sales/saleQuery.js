import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as SaleFragments } from '../../../containers/sale/sales/Sale';

export default function (WrappedComponent) {
  const GET_SALE = gql`
    query getSale($id: ID) {
      sale(id: $id) {
        ...SaleFragment
      }
    }
    ${SaleFragments.sale}
  `;

  const withSale = graphql(GET_SALE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withSale(WrappedComponent);
}
