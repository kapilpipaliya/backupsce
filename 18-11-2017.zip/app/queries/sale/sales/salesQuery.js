import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as SalePreviewFragments } from '../../../containers/sale/sales/_SalePreview';

export const AllSalesQuery = gql`
  query allSaleSalesQuery {
    salesCount
    allSaleSales {
      ...SalePreviewFragment
    }
  }
  ${SalePreviewFragments.sale}
`;

export default graphql(AllSalesQuery, {
  name: 'sales',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
