import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/sale/sales/EditSale';

export default function (WrappedComponent) {
  const GET_SALE = gql`
    query getSale($id: ID) {
      sale(id: $id) {
        ...SaleForEditingFragment
      }
    }
    ${fragments.sale}
  `;

  const withSaleForEditing = graphql(GET_SALE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withSaleForEditing(WrappedComponent);
}
