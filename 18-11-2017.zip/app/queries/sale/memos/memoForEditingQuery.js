import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/sale/memos/EditMemo';

export default function (WrappedComponent) {
  const GET_MEMO = gql`
    query getMemo($id: ID) {
      memo(id: $id) {
        ...MemoForEditingFragment
      }
    }
    ${fragments.memo}
  `;

  const withMemoForEditing = graphql(GET_MEMO, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMemoForEditing(WrappedComponent);
}
