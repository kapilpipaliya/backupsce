import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MemoPreviewFragments } from '../../../containers/sale/memos/_MemoPreview';

export const AllMemosQuery = gql`
  query allSaleMemosQuery {
    memosCount
    allSaleMemos {
      ...MemoPreviewFragment
    }
  }
  ${MemoPreviewFragments.memo}
`;

export default graphql(AllMemosQuery, {
  name: 'memos',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
