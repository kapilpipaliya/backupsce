import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/material/colors/EditColor';

export default function (WrappedComponent) {
  const GET_COLOR = gql`
    query getColor($id: ID) {
      color(id: $id) {
        ...ColorForEditingFragment
      }
    }
    ${fragments.color}
  `;

  const withColorForEditing = graphql(GET_COLOR, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withColorForEditing(WrappedComponent);
}
