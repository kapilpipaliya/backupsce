import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as ColorPreviewFragments } from '../../../containers/material/colors/_ColorPreview';

export const AllColorsQuery = gql`
  query allMaterialColorsQuery($f_material_id: Int) {
    colorsCount
    allMaterialColors(f_material_id: $f_material_id) {
      ...ColorPreviewFragment
    }
  }
  ${ColorPreviewFragments.color}
`;

export default graphql(AllColorsQuery, {
  name: 'colors',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_material_id: 0 },
  }),
});
