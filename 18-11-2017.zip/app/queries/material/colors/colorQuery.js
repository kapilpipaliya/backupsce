import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as ColorFragments } from '../../../containers/material/colors/Color';

export default function (WrappedComponent) {
  const GET_COLOR = gql`
    query getColor($id: ID) {
      color(id: $id) {
        ...ColorFragment
      }
    }
    ${ColorFragments.color}
  `;

  const withColor = graphql(GET_COLOR, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withColor(WrappedComponent);
}
