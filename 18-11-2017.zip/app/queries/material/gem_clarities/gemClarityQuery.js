import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as GemClarityFragments } from '../../../containers/material/gem_clarities/GemClarity';

export default function (WrappedComponent) {
  const GET_GEM_CLARITY = gql`
    query getGemClarity($id: ID) {
      gemClarity(id: $id) {
        ...GemClarityFragment
      }
    }
    ${GemClarityFragments.gemClarity}
  `;

  const withGemClarity = graphql(GET_GEM_CLARITY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withGemClarity(WrappedComponent);
}
