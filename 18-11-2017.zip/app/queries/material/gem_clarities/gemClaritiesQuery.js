import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as GemClarityPreviewFragments } from '../../../containers/material/gem_clarities/_GemClarityPreview';

export const AllGemClaritiesQuery = gql`
  query allMaterialGemClaritiesQuery($f_material_id: Int) {
    gemClaritiesCount
    allMaterialGemClarities(f_material_id: $f_material_id) {
      ...GemClarityPreviewFragment
    }
  }
  ${GemClarityPreviewFragments.gemClarity}
`;

export default graphql(AllGemClaritiesQuery, {
  name: 'gemclarities',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_material_id: 0 },
  }),
});
