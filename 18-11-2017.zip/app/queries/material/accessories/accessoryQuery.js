import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as AccessoryFragments } from '../../../containers/material/accessories/Accessory';

export default function (WrappedComponent) {
  const GET_ACCESSORY = gql`
    query getAccessory($id: ID) {
      accessory(id: $id) {
        ...AccessoryFragment
      }
    }
    ${AccessoryFragments.accessory}
  `;

  const withAccessory = graphql(GET_ACCESSORY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withAccessory(WrappedComponent);
}
