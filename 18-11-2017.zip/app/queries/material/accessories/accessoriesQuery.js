import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as AccessoryPreviewFragments } from '../../../containers/material/accessories/_AccessoryPreview';

export const AllAccessoriesQuery = gql`
  query allMaterialAccessoriesQuery {
    accessoriesCount
    allMaterialAccessories {
      ...AccessoryPreviewFragment
    }
  }
  ${AccessoryPreviewFragments.accessory}
`;

export default graphql(AllAccessoriesQuery, {
  name: 'accessories',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
