import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as GemSizeFragments } from '../../../containers/material/gem_sizes/GemSize';

export default function (WrappedComponent) {
  const GET_GEM_SIZE = gql`
    query getGemSize($id: ID) {
      gemSize(id: $id) {
        ...GemSizeFragment
      }
    }
    ${GemSizeFragments.gemSize}
  `;

  const withGemSize = graphql(GET_GEM_SIZE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withGemSize(WrappedComponent);
}
