import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as GemSizePreviewFragments } from '../../../containers/material/gem_sizes/_GemSizePreview';

export const AllGemSizesQuery = gql`
  query allMaterialGemSizesQuery($f_material_id: Int, $f_gem_shape_id: Int, $f_gem_clarity_id: Int) {
    gemSizesCount
    allMaterialGemSizes(f_material_id: $f_material_id, f_gem_shape_id: $f_gem_shape_id, f_gem_clarity_id: $f_gem_clarity_id) {
      ...GemSizePreviewFragment
    }
  }
  ${GemSizePreviewFragments.gemSize}
`;

export default graphql(AllGemSizesQuery, {
  name: 'gemsizes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_material_id: 0, f_gem_shape_id: 0, f_gem_clarity_id: 0 },
  }),
});
