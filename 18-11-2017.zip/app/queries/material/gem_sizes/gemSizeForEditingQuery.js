import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/material/gem_sizes/EditGemSize';

export default function (WrappedComponent) {
  const GET_GEM_SIZE = gql`
    query getGemSize($id: ID) {
      gemSize(id: $id) {
        ...GemSizeForEditingFragment
      }
    }
    ${fragments.gemSize}
  `;

  const withGemSizeForEditing = graphql(GET_GEM_SIZE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withGemSizeForEditing(WrappedComponent);
}
