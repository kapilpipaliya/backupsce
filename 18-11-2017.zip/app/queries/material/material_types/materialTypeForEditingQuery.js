import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/material/material_types/EditMaterialType';

export default function (WrappedComponent) {
  const GET_MATERIAL_TYPE = gql`
    query getMaterialType($id: ID) {
      materialType(id: $id) {
        ...MaterialTypeForEditingFragment
      }
    }
    ${fragments.materialType}
  `;

  const withMaterialTypeForEditing = graphql(GET_MATERIAL_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMaterialTypeForEditing(WrappedComponent);
}
