import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MaterialTypeFragments } from '../../../containers/material/material_types/MaterialType';

export default function (WrappedComponent) {
  const GET_MATERIAL_TYPE = gql`
    query getMaterialType($id: ID) {
      materialType(id: $id) {
        ...MaterialTypeFragment
      }
    }
    ${MaterialTypeFragments.materialType}
  `;

  const withMaterialType = graphql(GET_MATERIAL_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withMaterialType(WrappedComponent);
}
