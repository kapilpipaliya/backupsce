import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MaterialTypePreviewFragments } from '../../../containers/material/material_types/_MaterialTypePreview';

export const AllMaterialTypesQuery = gql`
  query allMaterialMaterialTypesQuery {
    materialTypesCount
    allMaterialMaterialTypes {
      ...MaterialTypePreviewFragment
    }
  }
  ${MaterialTypePreviewFragments.materialType}
`;

export default graphql(AllMaterialTypesQuery, {
  name: 'materialtypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
