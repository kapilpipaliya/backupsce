import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/material/lockers/EditLocker';

export default function (WrappedComponent) {
  const GET_LOCKER = gql`
    query getLocker($id: ID) {
      locker(id: $id) {
        ...LockerForEditingFragment
      }
    }
    ${fragments.locker}
  `;

  const withLockerForEditing = graphql(GET_LOCKER, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withLockerForEditing(WrappedComponent);
}
