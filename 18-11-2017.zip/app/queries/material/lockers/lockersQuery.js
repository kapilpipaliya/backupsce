import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as LockerPreviewFragments } from '../../../containers/material/lockers/_LockerPreview';

export const AllLockersQuery = gql`
  query allMaterialLockersQuery($f_location_id: Int) {
    lockersCount
    allMaterialLockers(f_location_id: $f_location_id) {
      ...LockerPreviewFragment
    }
  }
  ${LockerPreviewFragments.locker}
`;

export default graphql(AllLockersQuery, {
  name: 'lockers',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_location_id: 0 },
  }),
});
