import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MetalPurityFragments } from '../../../containers/material/metal_purities/MetalPurity';

export default function (WrappedComponent) {
  const GET_METAL_PURITY = gql`
    query getMetalPurity($id: ID) {
      metalPurity(id: $id) {
        ...MetalPurityFragment
      }
    }
    ${MetalPurityFragments.metalPurity}
  `;

  const withMetalPurity = graphql(GET_METAL_PURITY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withMetalPurity(WrappedComponent);
}
