import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/material/metal_purities/EditMetalPurity';

export default function (WrappedComponent) {
  const GET_METAL_PURITY = gql`
    query getMetalPurity($id: ID) {
      metalPurity(id: $id) {
        ...MetalPurityForEditingFragment
      }
    }
    ${fragments.metalPurity}
  `;

  const withMetalPurityForEditing = graphql(GET_METAL_PURITY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMetalPurityForEditing(WrappedComponent);
}
