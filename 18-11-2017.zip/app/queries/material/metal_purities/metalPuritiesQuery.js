import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MetalPurityPreviewFragments } from '../../../containers/material/metal_purities/_MetalPurityPreview';

export const AllMetalPuritiesQuery = gql`
  query allMaterialMetalPuritiesQuery($f_material_id: Int) {
    metalPuritiesCount
    allMaterialMetalPurities(f_material_id: $f_material_id) {
      ...MetalPurityPreviewFragment
    }
  }
  ${MetalPurityPreviewFragments.metalPurity}
`;

export default graphql(AllMetalPuritiesQuery, {
  name: 'metalpurities',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_material_id: 0 },
  }),
});
