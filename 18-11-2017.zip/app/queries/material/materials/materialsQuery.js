import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MaterialPreviewFragments } from '../../../containers/material/materials/_MaterialPreview';

export const AllMaterialsQuery = gql`
  query allMaterialMaterialsQuery($f_m_type_id: Int) {
    materialsCount
    allMaterialMaterials(f_m_type_id: $f_m_type_id) {
      ...MaterialPreviewFragment
    }
  }
  ${MaterialPreviewFragments.material}
`;

export default graphql(AllMaterialsQuery, {
  name: 'materials',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_m_type_id: 0 },
  }),
});
