import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MaterialFragments } from '../../../containers/material/materials/Material';

export default function (WrappedComponent) {
  const GET_MATERIAL = gql`
    query getMaterial($id: ID) {
      material(id: $id) {
        ...MaterialFragment
      }
    }
    ${MaterialFragments.material}
  `;

  const withMaterial = graphql(GET_MATERIAL, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withMaterial(WrappedComponent);
}
