import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/material/materials/EditMaterial';

export default function (WrappedComponent) {
  const GET_MATERIAL = gql`
    query getMaterial($id: ID) {
      material(id: $id) {
        ...MaterialForEditingFragment
      }
    }
    ${fragments.material}
  `;

  const withMaterialForEditing = graphql(GET_MATERIAL, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMaterialForEditing(WrappedComponent);
}
