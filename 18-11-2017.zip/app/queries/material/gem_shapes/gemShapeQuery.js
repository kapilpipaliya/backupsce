import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as GemShapeFragments } from '../../../containers/material/gem_shapes/GemShape';

export default function (WrappedComponent) {
  const GET_GEM_SHAPE = gql`
    query getGemShape($id: ID) {
      gemShape(id: $id) {
        ...GemShapeFragment
      }
    }
    ${GemShapeFragments.gemShape}
  `;

  const withGemShape = graphql(GET_GEM_SHAPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withGemShape(WrappedComponent);
}
