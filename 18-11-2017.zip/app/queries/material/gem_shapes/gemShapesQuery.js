import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as GemShapePreviewFragments } from '../../../containers/material/gem_shapes/_GemShapePreview';

export const AllGemShapesQuery = gql`
  query allMaterialGemShapesQuery($f_material_id: Int) {
    gemShapesCount
    allMaterialGemShapes(f_material_id: $f_material_id) {
      ...GemShapePreviewFragment
    }
  }
  ${GemShapePreviewFragments.gemShape}
`;

export default graphql(AllGemShapesQuery, {
  name: 'gemshapes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_material_id: 0 },
  }),
});
