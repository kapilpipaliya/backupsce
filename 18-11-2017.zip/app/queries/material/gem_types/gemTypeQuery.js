import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as GemTypeFragments } from '../../../containers/material/gem_types/GemType';

export default function (WrappedComponent) {
  const GET_GEM_TYPE = gql`
    query getGemType($id: ID) {
      gemType(id: $id) {
        ...GemTypeFragment
      }
    }
    ${GemTypeFragments.gemType}
  `;

  const withGemType = graphql(GET_GEM_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withGemType(WrappedComponent);
}
