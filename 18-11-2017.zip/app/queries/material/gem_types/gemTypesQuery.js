import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as GemTypePreviewFragments } from '../../../containers/material/gem_types/_GemTypePreview';

export const AllGemTypesQuery = gql`
  query allMaterialGemTypesQuery {
    gemTypesCount
    allMaterialGemTypes {
      ...GemTypePreviewFragment
    }
  }
  ${GemTypePreviewFragments.gemType}
`;

export default graphql(AllGemTypesQuery, {
  name: 'gemtypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
