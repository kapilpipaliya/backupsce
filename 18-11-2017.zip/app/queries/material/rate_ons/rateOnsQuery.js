import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as RateOnPreviewFragments } from '../../../containers/material/rate_ons/_RateOnPreview';

export const AllRateOnsQuery = gql`
  query allMaterialRateOnsQuery {
    rateOnsCount
    allMaterialRateOns {
      ...RateOnPreviewFragment
    }
  }
  ${RateOnPreviewFragments.rateOn}
`;

export default graphql(AllRateOnsQuery, {
  name: 'rateons',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
