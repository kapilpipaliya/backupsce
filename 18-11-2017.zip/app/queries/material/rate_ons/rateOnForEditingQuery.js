import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/material/rate_ons/EditRateOn';

export default function (WrappedComponent) {
  const GET_RATE_ON = gql`
    query getRateOn($id: ID) {
      rateOn(id: $id) {
        ...RateOnForEditingFragment
      }
    }
    ${fragments.rateOn}
  `;

  const withRateOnForEditing = graphql(GET_RATE_ON, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withRateOnForEditing(WrappedComponent);
}
