import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as RateOnFragments } from '../../../containers/material/rate_ons/RateOn';

export default function (WrappedComponent) {
  const GET_RATE_ON = gql`
    query getRateOn($id: ID) {
      rateOn(id: $id) {
        ...RateOnFragment
      }
    }
    ${RateOnFragments.rateOn}
  `;

  const withRateOn = graphql(GET_RATE_ON, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withRateOn(WrappedComponent);
}
