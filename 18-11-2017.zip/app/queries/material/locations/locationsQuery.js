import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as LocationPreviewFragments } from '../../../containers/material/locations/_LocationPreview';

export const AllLocationsQuery = gql`
  query allMaterialLocationsQuery {
    locationsCount
    allMaterialLocations {
      ...LocationPreviewFragment
    }
  }
  ${LocationPreviewFragments.location}
`;

export default graphql(AllLocationsQuery, {
  name: 'locations',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
