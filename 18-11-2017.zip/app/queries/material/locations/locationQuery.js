import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as LocationFragments } from '../../../containers/material/locations/Location';

export default function (WrappedComponent) {
  const GET_LOCATION = gql`
    query getLocation($id: ID) {
      location(id: $id) {
        ...LocationFragment
      }
    }
    ${LocationFragments.location}
  `;

  const withLocation = graphql(GET_LOCATION, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withLocation(WrappedComponent);
}
