import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as CompanyFragments } from '../../../containers/user/companies/Company';

export default function (WrappedComponent) {
  const GET_COMPANY = gql`
    query getCompany($id: ID) {
      company(id: $id) {
        ...CompanyFragment
      }
    }
    ${CompanyFragments.company}
  `;

  const withCompany = graphql(GET_COMPANY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withCompany(WrappedComponent);
}
