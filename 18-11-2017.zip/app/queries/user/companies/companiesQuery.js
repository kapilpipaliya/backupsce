import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as CompanyPreviewFragments } from '../../../containers/user/companies/_CompanyPreview';

export const AllCompaniesQuery = gql`
  query allUserCompaniesQuery {
    companiesCount
    allUserCompanies {
      ...CompanyPreviewFragment
    }
  }
  ${CompanyPreviewFragments.company}
`;

export default graphql(AllCompaniesQuery, {
  name: 'companies',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
