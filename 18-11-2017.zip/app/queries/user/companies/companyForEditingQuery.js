import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/user/companies/EditCompany';

export default function (WrappedComponent) {
  const GET_COMPANY = gql`
    query getCompany($id: ID) {
      company(id: $id) {
        ...CompanyForEditingFragment
      }
    }
    ${fragments.company}
  `;

  const withCompanyForEditing = graphql(GET_COMPANY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withCompanyForEditing(WrappedComponent);
}
