import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as StatePreviewFragments } from '../../../containers/user/states/_StatePreview';

export const AllStatesQuery = gql`
  query allUserStatesQuery($f_country_id: Int) {
    statesCount
    allUserStates(f_country_id: $f_country_id) {
      ...StatePreviewFragment
    }
  }
  ${StatePreviewFragments.state}
`;

export default graphql(AllStatesQuery, {
  name: 'states',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_country_id: 0 },
  }),
});
