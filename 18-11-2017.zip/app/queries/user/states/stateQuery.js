import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as StateFragments } from '../../../containers/user/states/State';

export default function (WrappedComponent) {
  const GET_STATE = gql`
    query getState($id: ID) {
      state(id: $id) {
        ...StateFragment
      }
    }
    ${StateFragments.state}
  `;

  const withState = graphql(GET_STATE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withState(WrappedComponent);
}
