import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/user/states/EditState';

export default function (WrappedComponent) {
  const GET_STATE = gql`
    query getState($id: ID) {
      state(id: $id) {
        ...StateForEditingFragment
      }
    }
    ${fragments.state}
  `;

  const withStateForEditing = graphql(GET_STATE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withStateForEditing(WrappedComponent);
}
