import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as CountryFragments } from '../../../containers/user/countries/Country';

export default function (WrappedComponent) {
  const GET_COUNTRY = gql`
    query getCountry($id: ID) {
      country(id: $id) {
        ...CountryFragment
      }
    }
    ${CountryFragments.country}
  `;

  const withCountry = graphql(GET_COUNTRY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withCountry(WrappedComponent);
}
