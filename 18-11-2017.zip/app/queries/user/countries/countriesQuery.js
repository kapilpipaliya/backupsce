import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as CountryPreviewFragments } from '../../../containers/user/countries/_CountryPreview';

export const AllCountriesQuery = gql`
  query allUserCountriesQuery {
    countriesCount
    allUserCountries {
      ...CountryPreviewFragment
    }
  }
  ${CountryPreviewFragments.country}
`;

export default graphql(AllCountriesQuery, {
  name: 'countries',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
