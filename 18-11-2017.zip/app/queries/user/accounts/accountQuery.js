import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as AccountFragments } from '../../../containers/user/accounts/Account';

export default function (WrappedComponent) {
  const GET_ACCOUNT = gql`
    query getAccount($id: ID) {
      account(id: $id) {
        ...AccountFragment
      }
    }
    ${AccountFragments.account}
  `;

  const withAccount = graphql(GET_ACCOUNT, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withAccount(WrappedComponent);
}
