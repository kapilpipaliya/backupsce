import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as AccountPreviewFragments } from '../../../containers/user/accounts/_AccountPreview';

export const AllAccountsQuery = gql`
  query allUserAccountsQuery($f_a_type_id: Int) {
    accountsCount
    allUserAccounts(f_a_type_id: $f_a_type_id) {
      ...AccountPreviewFragment
    }
  }
  ${AccountPreviewFragments.account}
`;

export default graphql(AllAccountsQuery, {
  name: 'accounts',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_a_type_id: 0 },
  }),
});
