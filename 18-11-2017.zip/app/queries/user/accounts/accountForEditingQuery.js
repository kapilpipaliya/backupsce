import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/user/accounts/EditAccount';

export default function (WrappedComponent) {
  const GET_ACCOUNT = gql`
    query getAccount($id: ID) {
      account(id: $id) {
        ...AccountForEditingFragment
      }
    }
    ${fragments.account}
  `;

  const withAccountForEditing = graphql(GET_ACCOUNT, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withAccountForEditing(WrappedComponent);
}
