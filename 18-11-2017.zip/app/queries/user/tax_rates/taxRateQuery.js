import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as TaxRateFragments } from '../../../containers/user/tax_rates/TaxRate';

export default function (WrappedComponent) {
  const GET_TAX_RATE = gql`
    query getTaxRate($id: ID) {
      taxRate(id: $id) {
        ...TaxRateFragment
      }
    }
    ${TaxRateFragments.taxRate}
  `;

  const withTaxRate = graphql(GET_TAX_RATE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withTaxRate(WrappedComponent);
}
