import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as TaxRatePreviewFragments } from '../../../containers/user/tax_rates/_TaxRatePreview';

export const AllTaxRatesQuery = gql`
  query allUserTaxRatesQuery {
    taxRatesCount
    allUserTaxRates {
      ...TaxRatePreviewFragment
    }
  }
  ${TaxRatePreviewFragments.taxRate}
`;

export default graphql(AllTaxRatesQuery, {
  name: 'taxrates',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
