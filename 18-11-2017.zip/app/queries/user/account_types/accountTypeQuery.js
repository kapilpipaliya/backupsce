import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as AccountTypeFragments } from '../../../containers/user/account_types/AccountType';

export default function (WrappedComponent) {
  const GET_ACCOUNT_TYPE = gql`
    query getAccountType($id: ID) {
      accountType(id: $id) {
        ...AccountTypeFragment
      }
    }
    ${AccountTypeFragments.accountType}
  `;

  const withAccountType = graphql(GET_ACCOUNT_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withAccountType(WrappedComponent);
}
