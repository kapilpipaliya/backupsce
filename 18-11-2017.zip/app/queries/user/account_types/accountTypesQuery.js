import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as AccountTypePreviewFragments } from '../../../containers/user/account_types/_AccountTypePreview';

export const AllAccountTypesQuery = gql`
  query allUserAccountTypesQuery {
    accountTypesCount
    allUserAccountTypes {
      ...AccountTypePreviewFragment
    }
  }
  ${AccountTypePreviewFragments.accountType}
`;

export default graphql(AllAccountTypesQuery, {
  name: 'accounttypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
