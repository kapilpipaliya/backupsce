import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as AddressPreviewFragments } from '../../../containers/user/addresses/_AddressPreview';

export const AllAddressesQuery = gql`
  query allUserAddressesQuery {
    addressesCount
    allUserAddresses {
      ...AddressPreviewFragment
    }
  }
  ${AddressPreviewFragments.address}
`;

export default graphql(AllAddressesQuery, {
  name: 'addresses',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
