import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as AddressFragments } from '../../../containers/user/addresses/Address';

export default function (WrappedComponent) {
  const GET_ADDRESS = gql`
    query getAddress($id: ID) {
      address(id: $id) {
        ...AddressFragment
      }
    }
    ${AddressFragments.address}
  `;

  const withAddress = graphql(GET_ADDRESS, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withAddress(WrappedComponent);
}
