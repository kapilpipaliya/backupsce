import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/user/addresses/EditAddress';

export default function (WrappedComponent) {
  const GET_ADDRESS = gql`
    query getAddress($id: ID) {
      address(id: $id) {
        ...AddressForEditingFragment
      }
    }
    ${fragments.address}
  `;

  const withAddressForEditing = graphql(GET_ADDRESS, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withAddressForEditing(WrappedComponent);
}
