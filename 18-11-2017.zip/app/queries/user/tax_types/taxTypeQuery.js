import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as TaxTypeFragments } from '../../../containers/user/tax_types/TaxType';

export default function (WrappedComponent) {
  const GET_TAX_TYPE = gql`
    query getTaxType($id: ID) {
      taxType(id: $id) {
        ...TaxTypeFragment
      }
    }
    ${TaxTypeFragments.taxType}
  `;

  const withTaxType = graphql(GET_TAX_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withTaxType(WrappedComponent);
}
