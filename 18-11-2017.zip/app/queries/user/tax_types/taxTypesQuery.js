import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as TaxTypePreviewFragments } from '../../../containers/user/tax_types/_TaxTypePreview';

export const AllTaxTypesQuery = gql`
  query allUserTaxTypesQuery {
    taxTypesCount
    allUserTaxTypes {
      ...TaxTypePreviewFragment
    }
  }
  ${TaxTypePreviewFragments.taxType}
`;

export default graphql(AllTaxTypesQuery, {
  name: 'taxtypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
