import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/user/roles/EditRole';

export default function (WrappedComponent) {
  const GET_ROLE = gql`
    query getRole($id: ID) {
      role(id: $id) {
        ...RoleForEditingFragment
      }
    }
    ${fragments.role}
  `;

  const withRoleForEditing = graphql(GET_ROLE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withRoleForEditing(WrappedComponent);
}
