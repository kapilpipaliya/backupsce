import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as RolePreviewFragments } from '../../../containers/user/roles/_RolePreview';

export const AllRolesQuery = gql`
  query allUserRolesQuery {
    rolesCount
    allUserRoles {
      ...RolePreviewFragment
    }
  }
  ${RolePreviewFragments.role}
`;

export default graphql(AllRolesQuery, {
  name: 'roles',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
