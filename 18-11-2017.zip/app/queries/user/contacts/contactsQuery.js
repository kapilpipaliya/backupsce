import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as ContactPreviewFragments } from '../../../containers/user/contacts/_ContactPreview';

export const AllContactsQuery = gql`
  query allUserContactsQuery {
    contactsCount
    allUserContacts {
      ...ContactPreviewFragment
    }
  }
  ${ContactPreviewFragments.contact}
`;

export default graphql(AllContactsQuery, {
  name: 'contacts',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
