import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as ContactFragments } from '../../../containers/user/contacts/Contact';

export default function (WrappedComponent) {
  const GET_CONTACT = gql`
    query getContact($id: ID) {
      contact(id: $id) {
        ...ContactFragment
      }
    }
    ${ContactFragments.contact}
  `;

  const withContact = graphql(GET_CONTACT, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withContact(WrappedComponent);
}
