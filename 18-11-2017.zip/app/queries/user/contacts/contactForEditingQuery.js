import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/user/contacts/EditContact';

export default function (WrappedComponent) {
  const GET_CONTACT = gql`
    query getContact($id: ID) {
      contact(id: $id) {
        ...ContactForEditingFragment
      }
    }
    ${fragments.contact}
  `;

  const withContactForEditing = graphql(GET_CONTACT, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withContactForEditing(WrappedComponent);
}
