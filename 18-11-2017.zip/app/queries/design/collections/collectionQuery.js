import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as CollectionFragments } from '../../../containers/design/collections/Collection';

export default function (WrappedComponent) {
  const GET_COLLECTION = gql`
    query getCollection($id: ID) {
      collection(id: $id) {
        ...CollectionFragment
      }
    }
    ${CollectionFragments.collection}
  `;

  const withCollection = graphql(GET_COLLECTION, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withCollection(WrappedComponent);
}
