import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as CollectionPreviewFragments } from '../../../containers/design/collections/_CollectionPreview';

export const AllCollectionsQuery = gql`
  query allDesignCollectionsQuery {
    collectionsCount
    allDesignCollections {
      ...CollectionPreviewFragment
    }
  }
  ${CollectionPreviewFragments.collection}
`;

export default graphql(AllCollectionsQuery, {
  name: 'collections',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
