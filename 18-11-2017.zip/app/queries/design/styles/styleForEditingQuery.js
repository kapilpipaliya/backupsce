import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/design/styles/EditStyle';

export default function (WrappedComponent) {
  const GET_STYLE = gql`
    query getStyle($id: ID) {
      style(id: $id) {
        ...StyleForEditingFragment
      }
    }
    ${fragments.style}
  `;

  const withStyleForEditing = graphql(GET_STYLE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withStyleForEditing(WrappedComponent);
}
