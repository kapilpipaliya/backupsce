import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as StyleFragments } from '../../../containers/design/styles/Style';

export default function (WrappedComponent) {
  const GET_STYLE = gql`
    query getStyle($id: ID) {
      style(id: $id) {
        ...StyleFragment
      }
    }
    ${StyleFragments.style}
  `;

  const withStyle = graphql(GET_STYLE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withStyle(WrappedComponent);
}
