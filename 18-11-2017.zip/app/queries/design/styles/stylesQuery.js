import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as StylePreviewFragments } from '../../../containers/design/styles/_StylePreview';

export const AllStylesQuery = gql`
  query allDesignStylesQuery {
    stylesCount
    allDesignStyles {
      ...StylePreviewFragment
    }
  }
  ${StylePreviewFragments.style}
`;

export default graphql(AllStylesQuery, {
  name: 'styles',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
