import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as ImageFragments } from '../../../containers/design/images/Image';

export default function (WrappedComponent) {
  const GET_IMAGE = gql`
    query getImage($id: ID) {
      image(id: $id) {
        ...ImageFragment
      }
    }
    ${ImageFragments.image}
  `;

  const withImage = graphql(GET_IMAGE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withImage(WrappedComponent);
}
