import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as ImagePreviewFragments } from '../../../containers/design/images/_ImagePreview';

export const AllImagesQuery = gql`
  query allDesignImagesQuery {
    imagesCount
    allDesignImages {
      ...ImagePreviewFragment
    }
  }
  ${ImagePreviewFragments.image}
`;

export default graphql(AllImagesQuery, {
  name: 'images',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
