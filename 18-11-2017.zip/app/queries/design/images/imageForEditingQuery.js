import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/design/images/EditImage';

export default function (WrappedComponent) {
  const GET_IMAGE = gql`
    query getImage($id: ID) {
      image(id: $id) {
        ...ImageForEditingFragment
      }
    }
    ${fragments.image}
  `;

  const withImageForEditing = graphql(GET_IMAGE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withImageForEditing(WrappedComponent);
}
