import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as SettingTypeFragments } from '../../../containers/design/setting_types/SettingType';

export default function (WrappedComponent) {
  const GET_SETTING_TYPE = gql`
    query getSettingType($id: ID) {
      settingType(id: $id) {
        ...SettingTypeFragment
      }
    }
    ${SettingTypeFragments.settingType}
  `;

  const withSettingType = graphql(GET_SETTING_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withSettingType(WrappedComponent);
}
