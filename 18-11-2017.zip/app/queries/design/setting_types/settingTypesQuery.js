import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as SettingTypePreviewFragments } from '../../../containers/design/setting_types/_SettingTypePreview';

export const AllSettingTypesQuery = gql`
  query allDesignSettingTypesQuery {
    settingTypesCount
    allDesignSettingTypes {
      ...SettingTypePreviewFragment
    }
  }
  ${SettingTypePreviewFragments.settingType}
`;

export default graphql(AllSettingTypesQuery, {
  name: 'settingtypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
