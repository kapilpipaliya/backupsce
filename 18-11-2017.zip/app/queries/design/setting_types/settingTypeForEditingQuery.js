import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/design/setting_types/EditSettingType';

export default function (WrappedComponent) {
  const GET_SETTING_TYPE = gql`
    query getSettingType($id: ID) {
      settingType(id: $id) {
        ...SettingTypeForEditingFragment
      }
    }
    ${fragments.settingType}
  `;

  const withSettingTypeForEditing = graphql(GET_SETTING_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withSettingTypeForEditing(WrappedComponent);
}
