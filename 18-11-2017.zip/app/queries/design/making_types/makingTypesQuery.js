import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MakingTypePreviewFragments } from '../../../containers/design/making_types/_MakingTypePreview';

export const AllMakingTypesQuery = gql`
  query allDesignMakingTypesQuery {
    makingTypesCount
    allDesignMakingTypes {
      ...MakingTypePreviewFragment
    }
  }
  ${MakingTypePreviewFragments.makingType}
`;

export default graphql(AllMakingTypesQuery, {
  name: 'makingtypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
