import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/design/making_types/EditMakingType';

export default function (WrappedComponent) {
  const GET_MAKING_TYPE = gql`
    query getMakingType($id: ID) {
      makingType(id: $id) {
        ...MakingTypeForEditingFragment
      }
    }
    ${fragments.makingType}
  `;

  const withMakingTypeForEditing = graphql(GET_MAKING_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMakingTypeForEditing(WrappedComponent);
}
