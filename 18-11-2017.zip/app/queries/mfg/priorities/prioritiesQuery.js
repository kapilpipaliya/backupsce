import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as PriorityPreviewFragments } from '../../../containers/mfg/priorities/_PriorityPreview';

export const AllPrioritiesQuery = gql`
  query allMfgPrioritiesQuery {
    prioritiesCount
    allMfgPriorities {
      ...PriorityPreviewFragment
    }
  }
  ${PriorityPreviewFragments.priority}
`;

export default graphql(AllPrioritiesQuery, {
  name: 'priorities',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
