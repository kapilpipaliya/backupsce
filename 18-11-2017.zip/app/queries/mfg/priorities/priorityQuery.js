import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as PriorityFragments } from '../../../containers/mfg/priorities/Priority';

export default function (WrappedComponent) {
  const GET_PRIORITY = gql`
    query getPriority($id: ID) {
      priority(id: $id) {
        ...PriorityFragment
      }
    }
    ${PriorityFragments.priority}
  `;

  const withPriority = graphql(GET_PRIORITY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withPriority(WrappedComponent);
}
