import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MfgTxnPreviewFragments } from '../../../containers/mfg/mfg_txns/_MfgTxnPreview';

export const AllMfgTxnsQuery = gql`
  query allMfgMfgTxnsQuery {
    mfgTxnsCount
    allMfgMfgTxns {
      ...MfgTxnPreviewFragment
    }
  }
  ${MfgTxnPreviewFragments.mfgTxn}
`;

export default graphql(AllMfgTxnsQuery, {
  name: 'mfgtxns',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
