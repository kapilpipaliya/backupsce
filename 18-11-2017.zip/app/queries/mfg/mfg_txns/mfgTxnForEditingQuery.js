import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/mfg/mfg_txns/EditMfgTxn';

export default function (WrappedComponent) {
  const GET_MFG_TXN = gql`
    query getMfgTxn($id: ID) {
      mfgTxn(id: $id) {
        ...MfgTxnForEditingFragment
      }
    }
    ${fragments.mfgTxn}
  `;

  const withMfgTxnForEditing = graphql(GET_MFG_TXN, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMfgTxnForEditing(WrappedComponent);
}
