import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as DustResourcePreviewFragments } from '../../../containers/mfg/dust_resources/_DustResourcePreview';

export const AllDustResourcesQuery = gql`
  query allMfgDustResourcesQuery {
    dustResourcesCount
    allMfgDustResources {
      ...DustResourcePreviewFragment
    }
  }
  ${DustResourcePreviewFragments.dustResource}
`;

export default graphql(AllDustResourcesQuery, {
  name: 'dustresources',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
