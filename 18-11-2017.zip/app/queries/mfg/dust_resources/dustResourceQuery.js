import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as DustResourceFragments } from '../../../containers/mfg/dust_resources/DustResource';

export default function (WrappedComponent) {
  const GET_DUST_RESOURCE = gql`
    query getDustResource($id: ID) {
      dustResource(id: $id) {
        ...DustResourceFragment
      }
    }
    ${DustResourceFragments.dustResource}
  `;

  const withDustResource = graphql(GET_DUST_RESOURCE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withDustResource(WrappedComponent);
}
