import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as ProductTypeFragments } from '../../../containers/mfg/product_types/ProductType';

export default function (WrappedComponent) {
  const GET_PRODUCT_TYPE = gql`
    query getProductType($id: ID) {
      productType(id: $id) {
        ...ProductTypeFragment
      }
    }
    ${ProductTypeFragments.productType}
  `;

  const withProductType = graphql(GET_PRODUCT_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withProductType(WrappedComponent);
}
