import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as ProductTypePreviewFragments } from '../../../containers/mfg/product_types/_ProductTypePreview';

export const AllProductTypesQuery = gql`
  query allMfgProductTypesQuery {
    productTypesCount
    allMfgProductTypes {
      ...ProductTypePreviewFragment
    }
  }
  ${ProductTypePreviewFragments.productType}
`;

export default graphql(AllProductTypesQuery, {
  name: 'producttypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
