import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as SubDepartmentPreviewFragments } from '../../../containers/mfg/sub_departments/_SubDepartmentPreview';

export const AllSubDepartmentsQuery = gql`
  query allMfgSubDepartmentsQuery {
    subDepartmentsCount
    allMfgSubDepartments {
      ...SubDepartmentPreviewFragment
    }
  }
  ${SubDepartmentPreviewFragments.subDepartment}
`;

export default graphql(AllSubDepartmentsQuery, {
  name: 'subdepartments',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
