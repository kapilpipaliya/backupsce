import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/mfg/sub_departments/EditSubDepartment';

export default function (WrappedComponent) {
  const GET_SUB_DEPARTMENT = gql`
    query getSubDepartment($id: ID) {
      subDepartment(id: $id) {
        ...SubDepartmentForEditingFragment
      }
    }
    ${fragments.subDepartment}
  `;

  const withSubDepartmentForEditing = graphql(GET_SUB_DEPARTMENT, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withSubDepartmentForEditing(WrappedComponent);
}
