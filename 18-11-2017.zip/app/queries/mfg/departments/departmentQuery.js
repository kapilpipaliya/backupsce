import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as DepartmentFragments } from '../../../containers/mfg/departments/Department';

export default function (WrappedComponent) {
  const GET_DEPARTMENT = gql`
    query getDepartment($id: ID) {
      department(id: $id) {
        ...DepartmentFragment
      }
    }
    ${DepartmentFragments.department}
  `;

  const withDepartment = graphql(GET_DEPARTMENT, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withDepartment(WrappedComponent);
}
