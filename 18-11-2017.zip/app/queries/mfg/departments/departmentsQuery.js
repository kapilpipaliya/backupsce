import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as DepartmentPreviewFragments } from '../../../containers/mfg/departments/_DepartmentPreview';

export const AllDepartmentsQuery = gql`
  query allMfgDepartmentsQuery {
    departmentsCount
    allMfgDepartments {
      ...DepartmentPreviewFragment
    }
  }
  ${DepartmentPreviewFragments.department}
`;

export default graphql(AllDepartmentsQuery, {
  name: 'departments',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
