import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/mfg/castings/EditCasting';

export default function (WrappedComponent) {
  const GET_CASTING = gql`
    query getCasting($id: ID) {
      casting(id: $id) {
        ...CastingForEditingFragment
      }
    }
    ${fragments.casting}
  `;

  const withCastingForEditing = graphql(GET_CASTING, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withCastingForEditing(WrappedComponent);
}
