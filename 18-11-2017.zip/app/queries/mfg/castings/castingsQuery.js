import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as CastingPreviewFragments } from '../../../containers/mfg/castings/_CastingPreview';

export const AllCastingsQuery = gql`
  query allMfgCastingsQuery {
    castingsCount
    allMfgCastings {
      ...CastingPreviewFragment
    }
  }
  ${CastingPreviewFragments.casting}
`;

export default graphql(AllCastingsQuery, {
  name: 'castings',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
