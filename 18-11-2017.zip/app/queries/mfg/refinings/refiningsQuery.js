import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as RefiningPreviewFragments } from '../../../containers/mfg/refinings/_RefiningPreview';

export const AllRefiningsQuery = gql`
  query allMfgRefiningsQuery {
    refiningsCount
    allMfgRefinings {
      ...RefiningPreviewFragment
    }
  }
  ${RefiningPreviewFragments.refining}
`;

export default graphql(AllRefiningsQuery, {
  name: 'refinings',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
