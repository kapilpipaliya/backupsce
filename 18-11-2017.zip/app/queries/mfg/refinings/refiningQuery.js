import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as RefiningFragments } from '../../../containers/mfg/refinings/Refining';

export default function (WrappedComponent) {
  const GET_REFINING = gql`
    query getRefining($id: ID) {
      refining(id: $id) {
        ...RefiningFragment
      }
    }
    ${RefiningFragments.refining}
  `;

  const withRefining = graphql(GET_REFINING, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withRefining(WrappedComponent);
}
