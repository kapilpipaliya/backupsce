import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/mfg/refinings/EditRefining';

export default function (WrappedComponent) {
  const GET_REFINING = gql`
    query getRefining($id: ID) {
      refining(id: $id) {
        ...RefiningForEditingFragment
      }
    }
    ${fragments.refining}
  `;

  const withRefiningForEditing = graphql(GET_REFINING, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withRefiningForEditing(WrappedComponent);
}
