import axios from 'axios';


const Backend = {

  // Temp store of all data for only this page load
  cache: {},

  getUsers() {
    return this.cacheAjax('https://api.github.com/users');
  },

  // Cache the result by wrapping the request in another promise
  cacheAjax(url) {
    const that = this;
    const p = new Promise(((resolve, reject) => {
      // Already have a copy?
      if (that.cache[url] !== undefined) {
        resolve(that.cache[url]);
        return;
      }

      console.log('HTTP request:', url);

      // Load and save a copy
      axios.get(url).then((response) => {
        if (response.status === 200) {
          that.cache[url] = response;
          resolve(response);
        } else {
          reject(response.statusText);
        }
      }).catch((e) => {
        reject(e);
      });
    }));

    return p;
  },
};

export default Backend;
