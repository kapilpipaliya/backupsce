// import ApolloClient, { createBatchingNetworkInterface } from 'apollo-client'; Increase Performance.
// http://dev.apollodata.com/core/network.html

import { ApolloClient } from 'apollo-client';
// import { ApolloProvider, renderToStringWithData } from 'react-apollo';
import { ApolloLink } from 'apollo-link';
import { InMemoryCache } from 'apollo-cache-inmemory';
// import { HttpLink } from 'apollo-link-http';
import fetch from 'node-fetch';
import ROOT_URL from './rootUrl';
import {
  // errorLink,
  queryOrMutationLink1,
  // subscriptionLink1,
  // requestLink,
} from './links';
export default new ApolloClient({
  ssrMode: true,
  link: ApolloLink.from([
    // errorLink,
    queryOrMutationLink1({
      fetch,
      uri: `${ROOT_URL}/graphql`,
    }),
  ]),
  cache: new InMemoryCache(),
  queryDeduplication: true,
  dataIdFromObject: (result) => {
    /* eslint no-underscore-dangle: 0 */
    if (result.id && result.__typename) {
      return result.__typename + result.id;
    }
    return null;
  },
});


// const client = new ApolloClient({
//     networkInterface: createNetworkInterface({uri: 'http://localhost:3000/graphql'}),
// })
