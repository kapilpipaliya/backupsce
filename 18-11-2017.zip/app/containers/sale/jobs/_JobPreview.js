import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroyJob from '../../../mutations/sale/jobs/destroyJobMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class JobPreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroyJob(this.props.jobRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { jobRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(job.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/jobs/${jobRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  job: gql`
    fragment JobPreviewFragment on SaleJob {
      id
      processable_type
      processable_id { id slug }
      salable_type
      salable_id { id slug }
      is_exist
      position
      style_id { id slug }
      product_type_id { id slug }
      location_id { id slug }
      material_id { id slug }
      metal_purity_id { id slug }
      metal_color_id { id slug }
      qty
      diamond_clarity_id { id slug }
      diamond_color_id { id slug }
      cs_clarity_id { id slug }
      cs_color_id { id slug }
      instruction
      item_size
      priority_id { id slug }
      department_id { id slug }
      sub_department_id { id slug }
      net_weight
      pure_weight
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
      created_at
    }
  `,
};

export default withDestroyJob(withCurrentUser(JobPreview));
