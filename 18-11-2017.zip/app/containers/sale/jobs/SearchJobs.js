import React, { Component } from 'react';
import ListJobs from './_ListJobs';
import HeadListJobs from './_HeadListJobs';
import withJobsData from '../../../queries/sale/jobs/jobsQuery';

class SearchJobs extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.jobs = [];
    }
  }

  render() {
    const { jobs, jobsCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreJobs,
      firstJobsLoading,
    } = this.props;

    return (
      <div className="search-jobs">
        <h1>Searching jobs</h1>
        <HeadListJobs
          initialKeywords={keywords}
          loading={firstJobsLoading}
        />

        {!firstJobsLoading && jobs && jobs.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListJobs
            jobs={jobs}
            jobsCount={jobsCount}
            loading={loading}
            loadMoreJobs={loadMoreJobs}
          />
        )}
      </div>
    );
  }
}

export default withJobsData(SearchJobs);
