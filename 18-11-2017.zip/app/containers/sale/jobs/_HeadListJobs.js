import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import Button from 'material-ui/Button';
import AddIcon from 'material-ui-icons/Add';

import SearchJobForm from './_SearchJobForm';
import withCurrentUser from '../../../queries/users/currentUserQuery';


const styles = (theme) => ({
  button: {
    margin: theme.spacing.unit,
  },
});

@withStyles(styles)
class ListJobs extends Component {
  render() {
    const { keywords, searchLoading, currentUser } = this.props;
    const { classes } = this.props;

    return (
      <div>
        <div>
          <SearchJobForm initialKeywords={keywords} loading={searchLoading} />
        </div>
        {currentUser ? (
          <div>
            <Link to="/jobs/new">
              <Button fab color="primary" aria-label="add" className={classes.button}><AddIcon /></Button>
            </Link>
          </div>
        ) : null}
      </div>
    );
  }
}

export default withCurrentUser(ListJobs);
