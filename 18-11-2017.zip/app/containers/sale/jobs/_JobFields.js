import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';
import S from '../../../components/form/SimpleSelect';
import Sw from '../../../components/form/RenderSwitch';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI, parsefloat as pF } from '../../../utils/libs';

export class ProcessableType extends React.Component {
  render() {
    return (
      <Field name='processable_type' label='Processable type' component={F} {...this.props} />
    );
  }
}

export class ProcessableId extends React.Component {
  render() {
    return (
      <Field name='processable_id' label='Processable' component={S} parse={pI} {...this.props} />
    );
  }
}

export class SalableType extends React.Component {
  render() {
    return (
      <Field name='salable_type' label='Salable type' component={F} {...this.props} />
    );
  }
}

export class SalableId extends React.Component {
  render() {
    return (
      <Field name='salable_id' label='Salable' component={S} parse={pI} {...this.props} />
    );
  }
}

export class IsExist extends React.Component {
  render() {
    return (
      <Field name='is_exist' label='Is exist?' component={Sw} type='checkbox' {...this.props} />
    );
  }
}

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class StyleId extends React.Component {
  render() {
    return (
      <Field name='style_id' label='Style' component={S} parse={pI} {...this.props} />
    );
  }
}

export class ProductTypeId extends React.Component {
  render() {
    return (
      <Field name='product_type_id' label='Product type' component={S} parse={pI} {...this.props} />
    );
  }
}

export class LocationId extends React.Component {
  render() {
    return (
      <Field name='location_id' label='Location' component={S} parse={pI} {...this.props} />
    );
  }
}

export class MaterialId extends React.Component {
  render() {
    return (
      <Field name='material_id' label='Material' component={S} parse={pI} {...this.props} />
    );
  }
}

export class MetalPurityId extends React.Component {
  render() {
    return (
      <Field name='metal_purity_id' label='Metal purity' component={S} parse={pI} {...this.props} />
    );
  }
}

export class MetalColorId extends React.Component {
  render() {
    return (
      <Field name='metal_color_id' label='Metal color' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Qty extends React.Component {
  render() {
    return (
      <Field name='qty' label='Qty' component={F} parse={pI} placeholder='Qty' type='number' {...this.props} />
    );
  }
}

export class DiamondClarityId extends React.Component {
  render() {
    return (
      <Field name='diamond_clarity_id' label='Diamond clarity' component={S} parse={pI} {...this.props} />
    );
  }
}

export class DiamondColorId extends React.Component {
  render() {
    return (
      <Field name='diamond_color_id' label='Diamond color' component={S} parse={pI} {...this.props} />
    );
  }
}

export class CsClarityId extends React.Component {
  render() {
    return (
      <Field name='cs_clarity_id' label='Cs clarity' component={S} parse={pI} {...this.props} />
    );
  }
}

export class CsColorId extends React.Component {
  render() {
    return (
      <Field name='cs_color_id' label='Cs color' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Instruction extends React.Component {
  render() {
    return (
      <Field name='instruction' label='Instruction' component={F} {...this.props} />
    );
  }
}

export class ItemSize extends React.Component {
  render() {
    return (
      <Field name='item_size' label='Item size' component={F} {...this.props} />
    );
  }
}

export class PriorityId extends React.Component {
  render() {
    return (
      <Field name='priority_id' label='Priority' component={S} parse={pI} {...this.props} />
    );
  }
}

export class DepartmentId extends React.Component {
  render() {
    return (
      <Field name='department_id' label='Department' component={S} parse={pI} {...this.props} />
    );
  }
}

export class SubDepartmentId extends React.Component {
  render() {
    return (
      <Field name='sub_department_id' label='Sub department' component={S} parse={pI} {...this.props} />
    );
  }
}

export class NetWeight extends React.Component {
  render() {
    return (
      <Field name='net_weight' label='Net weight' component={F} parse={pF} placeholder='Net weight' type='number' {...this.props} />
    );
  }
}

export class PureWeight extends React.Component {
  render() {
    return (
      <Field name='pure_weight' label='Pure weight' component={F} parse={pF} placeholder='Pure weight' type='number' {...this.props} />
    );
  }
}

export class DiamondPcs extends React.Component {
  render() {
    return (
      <Field name='diamond_pcs' label='Diamond pcs' component={F} parse={pI} placeholder='Diamond pcs' type='number' {...this.props} />
    );
  }
}

export class DiamondWeight extends React.Component {
  render() {
    return (
      <Field name='diamond_weight' label='Diamond weight' component={F} parse={pF} placeholder='Diamond weight' type='number' {...this.props} />
    );
  }
}

export class CsPcs extends React.Component {
  render() {
    return (
      <Field name='cs_pcs' label='Cs pcs' component={F} parse={pI} placeholder='Cs pcs' type='number' {...this.props} />
    );
  }
}

export class CsWeight extends React.Component {
  render() {
    return (
      <Field name='cs_weight' label='Cs weight' component={F} parse={pF} placeholder='Cs weight' type='number' {...this.props} />
    );
  }
}

export class GrossWeight extends React.Component {
  render() {
    return (
      <Field name='gross_weight' label='Gross weight' component={F} parse={pF} placeholder='Gross weight' type='number' {...this.props} />
    );
  }
}

// import { ProcessableType, ProcessableId, SalableType, SalableId, IsExist, Position, StyleId, ProductTypeId, LocationId, MaterialId, MetalPurityId, MetalColorId, Qty, DiamondClarityId, DiamondColorId, CsClarityId, CsColorId, Instruction, ItemSize, PriorityId, DepartmentId, SubDepartmentId, NetWeight, PureWeight, DiamondPcs, DiamondWeight, CsPcs, CsWeight, GrossWeight } from './_JobFields'; // eslint-disable-line no-unused-vars
