import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroyMemo from '../../../mutations/sale/memos/destroyMemoMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class MemoPreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroyMemo(this.props.memoRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { memoRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(memo.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/memos/${memoRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  memo: gql`
    fragment MemoPreviewFragment on SaleMemo {
      id
      position
      date
      description
      created_at
    }
  `,
};

export default withDestroyMemo(withCurrentUser(MemoPreview));
