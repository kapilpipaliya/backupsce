import React, { Component } from 'react';
import ListMemos from './_ListMemos';
import HeadListMemos from './_HeadListMemos';
import withMemosData from '../../../queries/sale/memos/memosQuery';

class SearchMemos extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.memos = [];
    }
  }

  render() {
    const { memos, memosCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreMemos,
      firstMemosLoading,
    } = this.props;

    return (
      <div className="search-memos">
        <h1>Searching memos</h1>
        <HeadListMemos
          initialKeywords={keywords}
          loading={firstMemosLoading}
        />

        {!firstMemosLoading && memos && memos.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListMemos
            memos={memos}
            memosCount={memosCount}
            loading={loading}
            loadMoreMemos={loadMoreMemos}
          />
        )}
      </div>
    );
  }
}

export default withMemosData(SearchMemos);
