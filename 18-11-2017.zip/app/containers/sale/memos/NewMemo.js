import React, { Component } from 'react';
import Button from 'material-ui/Button';
import MemoForm from './_MemoForm';
import withCreateMemo from '../../../mutations/sale/memos/createMemoMutation';

class NewMemo extends Component {
  render() {
    return (
      <div>
        <h1>New Memo</h1>
        <MemoForm action={this.props.createMemo} submitName="Create Memo" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateMemo(NewMemo);
