import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withMemosData from '../../../queries/sale/memos/memosQuery';

import ListMemos from './_ListMemos';
import HeadListMemos from './_HeadListMemos';

class AllMemos extends Component {
  componentDidMount() {
    this.props.memos.refetch(); // You can pass variables here.
  }

  render() {
    const { memos: { loading, error }, memos } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListMemos />
        <ListMemos data={memos} />
      </div>
    );
  }
}

export default withMemosData(AllMemos);
