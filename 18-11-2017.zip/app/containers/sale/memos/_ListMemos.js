import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import MemoPreview from './_MemoPreview';

class ListMemos extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allSaleMemos,
      // memosCount,
      loading,
      error,
      // loadMoreMemos,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allSaleMemos}
        columns={[
          // @formatter:off
          { accessor: 'MemoPreview', Header: '-', Cell: (props) => <MemoPreview memoRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'date', Header: 'Date' },
          { accessor: 'description', Header: 'Description' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListMemos;
