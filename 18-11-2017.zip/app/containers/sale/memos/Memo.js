import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withMemo from '../../../queries/sale/memos/memoQuery';

class Memo extends Component {
  render() {
    const { memo, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="memo">
        <p>Memo</p>
        <h2 className="memo-heading">{memo.slug}</h2>
        <div className="memo-meta">
          <span className="memo-author">
            Posted by: <em>{/* {memo.author.name} */}</em>
          </span>
          <span className="memo-date">
            {moment(new Date(memo.created_at)).fromNow()}
          </span>
        </div>
        <div className="memo-content">
          contents display here: ID : {memo.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  memo: gql`
    fragment MemoFragment on SaleMemo {
      id
      position
      date
      description
      created_at
    }
  `,
};

export default withMemo(Memo);
