import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import MemoForm from './_MemoForm';
import withMemoForEditing from '../../../queries/sale/memos/memoForEditingQuery';
import withUpdateMemo from '../../../mutations/sale/memos/updateMemoMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditMemo extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { memo, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing memo</h1>
        <MemoForm action={this.props.updateMemo} initialValues={{ ...flatIDValue(memo) }} submitName="Update Memo" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  memo: gql`
    fragment MemoForEditingFragment on SaleMemo {
      id
      position
      date
      description
    }
  `,
};

export default withMemoForEditing(withUpdateMemo(EditMemo));
