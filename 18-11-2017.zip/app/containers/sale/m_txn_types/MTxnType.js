import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withMTxnType from '../../../queries/sale/m_txn_types/mTxnTypeQuery';

class MTxnType extends Component {
  render() {
    const { mTxnType, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="mTxnType">
        <p>MTxnType</p>
        <h2 className="mTxnType-heading">{mTxnType.slug}</h2>
        <div className="mTxnType-meta">
          <span className="mTxnType-author">
            Posted by: <em>{/* {mTxnType.author.name} */}</em>
          </span>
          <span className="mTxnType-date">
            {moment(new Date(mTxnType.created_at)).fromNow()}
          </span>
        </div>
        <div className="mTxnType-content">
          contents display here: ID : {mTxnType.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  mTxnType: gql`
    fragment MTxnTypeFragment on SaleMTxnType {
      id
      position
      slug
      txn_type
      created_at
    }
  `,
};

export default withMTxnType(MTxnType);
