import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withMTxnTypesData from '../../../queries/sale/m_txn_types/mTxnTypesQuery';

import ListMTxnTypes from './_ListMTxnTypes';
import HeadListMTxnTypes from './_HeadListMTxnTypes';

class AllMTxnTypes extends Component {
  componentDidMount() {
    this.props.mtxntypes.refetch(); // You can pass variables here.
  }

  render() {
    const { mtxntypes: { loading, error }, mtxntypes } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListMTxnTypes />
        <ListMTxnTypes data={mtxntypes} />
      </div>
    );
  }
}

export default withMTxnTypesData(AllMTxnTypes);
