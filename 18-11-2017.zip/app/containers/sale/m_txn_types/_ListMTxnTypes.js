import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import MTxnTypePreview from './_MTxnTypePreview';

class ListMTxnTypes extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allSaleMTxnTypes,
      // mTxnTypesCount,
      loading,
      error,
      // loadMoreMTxnTypes,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allSaleMTxnTypes}
        columns={[
          // @formatter:off
          { accessor: 'MTxnTypePreview', Header: '-', Cell: (props) => <MTxnTypePreview mTxnTypeRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'slug', Header: 'Code' },
          { accessor: 'txn_type', Header: 'Txn type' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListMTxnTypes;
