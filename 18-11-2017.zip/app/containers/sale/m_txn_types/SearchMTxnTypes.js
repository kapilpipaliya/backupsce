import React, { Component } from 'react';
import ListMTxnTypes from './_ListMTxnTypes';
import HeadListMTxnTypes from './_HeadListMTxnTypes';
import withMTxnTypesData from '../../../queries/sale/m_txn_types/mTxnTypesQuery';

class SearchMTxnTypes extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.mTxnTypes = [];
    }
  }

  render() {
    const { mTxnTypes, mTxnTypesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreMTxnTypes,
      firstMTxnTypesLoading,
    } = this.props;

    return (
      <div className="search-mTxnTypes">
        <h1>Searching mTxnTypes</h1>
        <HeadListMTxnTypes
          initialKeywords={keywords}
          loading={firstMTxnTypesLoading}
        />

        {!firstMTxnTypesLoading && mTxnTypes && mTxnTypes.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListMTxnTypes
            mTxnTypes={mTxnTypes}
            mTxnTypesCount={mTxnTypesCount}
            loading={loading}
            loadMoreMTxnTypes={loadMoreMTxnTypes}
          />
        )}
      </div>
    );
  }
}

export default withMTxnTypesData(SearchMTxnTypes);
