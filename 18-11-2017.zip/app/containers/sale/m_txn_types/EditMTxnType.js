import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import MTxnTypeForm from './_MTxnTypeForm';
import withMTxnTypeForEditing from '../../../queries/sale/m_txn_types/mTxnTypeForEditingQuery';
import withUpdateMTxnType from '../../../mutations/sale/m_txn_types/updateMTxnTypeMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditMTxnType extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { mTxnType, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing mTxnType</h1>
        <MTxnTypeForm action={this.props.updateMTxnType} initialValues={{ ...flatIDValue(mTxnType) }} submitName="Update MTxnType" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  mTxnType: gql`
    fragment MTxnTypeForEditingFragment on SaleMTxnType {
      id
      position
      slug
      txn_type
    }
  `,
};

export default withMTxnTypeForEditing(withUpdateMTxnType(EditMTxnType));
