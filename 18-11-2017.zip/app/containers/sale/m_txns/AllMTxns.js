import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withMTxnsData from '../../../queries/sale/m_txns/mTxnsQuery';

import ListMTxns from './_ListMTxns';
import HeadListMTxns from './_HeadListMTxns';

class AllMTxns extends Component {
  componentDidMount() {
    this.props.mtxns.refetch(); // You can pass variables here.
  }

  render() {
    const { mtxns: { loading, error }, mtxns } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListMTxns />
        <ListMTxns data={mtxns} />
      </div>
    );
  }
}

export default withMTxnsData(AllMTxns);
