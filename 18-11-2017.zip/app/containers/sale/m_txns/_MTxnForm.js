import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Field, FieldArray, formValueSelector, reduxForm, SubmissionError } from 'redux-form/immutable';
import { withApollo } from 'react-apollo';
import { List } from 'immutable';
import { Button } from 'material-ui';
import { withStyles } from 'material-ui/styles';
import Grid from 'material-ui/Grid';
import { Helmet } from 'react-helmet';
import SimpleSelect from '../../../components/form/SimpleSelect';
import { Position, MTxnTypeId, PartyId, TakenById, Date, DueDate, TotalWeight, Amount, Description } from './_MTxnFields'; // eslint-disable-line no-unused-vars
import RenderMTxnDetails from '../../../components/form/RenderMTxnDetails';
import { parseint as pI } from '../../../utils/libs';
import { fexecuteA, fexecuteMTxnType } from '../../../utils/Fetch';
import HOCFetch from '../../HOC/Fetch';
const styles = (theme) => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  formControl: {
    margin: theme.spacing.unit,

    marginLeft: 0,
    marginRight: theme.spacing.unit,
    minWidth: 200,
  },
});
@withApollo
@HOCFetch
@withStyles(styles)
class MTxnForm extends Component {
  state = {
    loading: false,
  };

  // Fetch Internal Options
  componentDidMount() {
    this.props.fetch(fexecuteA, 'parties', 2);// Fetch Customers.
    this.props.fetch(fexecuteA, 'staffs', 1);
    this.props.fetch(fexecuteMTxnType, 'm_txn_types');
  }
  submitForm = (values) => {
    this.setState({ loading: true });
    return this.props.action(values).then((errors) => {
      if (errors) {
        this.setState({ loading: false });
        throw new SubmissionError(errors);
      }
    });
  }
  render() {
    const {
      handleSubmit, pristine, reset, invalid, submitting, submitName,
    } = this.props;
    const { loading } = this.state;

    const { classes } = this.props;

    return (
      <form onSubmit={handleSubmit(this.submitForm)}>
        <fieldset>
          <Helmet>
            <meta charSet="utf-8" />
            <title>My Title</title>
            <link rel="canonical" href="http://mysite.com/example" />
          </Helmet>
          <Grid className={classes.container} container spacing={16}>
            <Grid item xs={6}><MTxnTypeId
              label="Transaction Type *"
              oField="txn_type"
              options={this.props.m_txn_types}
              onChange2={(value) => { if (value === 3) { this.props.fetch(fexecuteA, 'parties', 3); } else { this.props.fetch(fexecuteA, 'parties', 2); } }}
            />
            </Grid>
            {/* <Field name="position" label="Position(optional)" component={RenderField} parse={pI} placeholder="Position" type='number'/> */}
            <Grid item xs={6}><PartyId options={this.props.parties} /></Grid>

            <Grid item xs={6}><Date /></Grid>
            <Grid item xs={6}><DueDate /> <br /></Grid>

            <Grid item xs={4}><TakenById options={this.props.staffs} /></Grid>
            <Grid item xs={4}><Description /></Grid>
            <Grid item xs={4}><Field name="status" label="Status *" component={SimpleSelect} parse={pI} options={this.props.states} /></Grid>

            <Grid item xs={6}><TotalWeight /></Grid>
            <Grid item xs={6}><Amount /></Grid>
          </Grid>
        </fieldset>
        <FieldArray
          name="mTxnDetails"
          component={RenderMTxnDetails}
          mTxnDetails={this.props.mTxnDetails}
          change={this.props.change}
          calcTotals={this.props.calcTotals}
        />
        <Button
          raised
          type="submit"
          disabled={loading || invalid || submitting}
        >
          {submitName}
        </Button>
        <Button
          raised
          disabled={loading || pristine || submitting}
          onClick={reset}
          style={{ margin: '5px' }}
        >
          Clear Values
        </Button>

      </form>
    );
  }
}

function validate(values) {
  const errors = {};
  if (!values.get('m_txn_type_id')) {
    errors.m_txn_type_id = "can't be blank";
  }
  return errors;
}

// Decorate with connect to read form values
const selector = formValueSelector('MTxnForm'); // <-- same as form name
const mapStateToProps = (state) => {
  // const {material_id, metal_purity_id, purity_per, net_weight} = selector(state, 'material_id', 'metal_purity_id', 'purity_per', 'net_weight');
  let mTxnDetails = selector(state, 'mTxnDetails');
  if (!mTxnDetails) mTxnDetails = List();
  return {
    mTxnDetails,
  };
};

const mapDispatchToProps = () => ({
  calcTotals: () => {

  },
});

// const C = compose(
  // withCollectionsData,
  // withMakingTypesData,
  // withSettingTypesData,
// )(
const C = connect(mapStateToProps, mapDispatchToProps)(MTxnForm);

export default reduxForm({
  form: 'MTxnForm',
  // fields: _.keys(FIELDS),
  validate,
})(C);
