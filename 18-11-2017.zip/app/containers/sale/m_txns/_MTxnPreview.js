import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroyMTxn from '../../../mutations/sale/m_txns/destroyMTxnMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class MTxnPreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroyMTxn(this.props.mTxnRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { mTxnRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(mTxn.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/mtxns/${mTxnRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  mTxn: gql`
    fragment MTxnPreviewFragment on SaleMTxn {
      id
      position
      m_txn_type_id { id slug }
      party_id { id slug }
      taken_by_id { id slug }
      date
      due_date
      total_weight
      amount
      description
      created_at
    }
  `,
};

export default withDestroyMTxn(withCurrentUser(MTxnPreview));
