import React, { Component } from 'react';
import ListMTxns from './_ListMTxns';
import HeadListMTxns from './_HeadListMTxns';
import withMTxnsData from '../../../queries/sale/m_txns/mTxnsQuery';

class SearchMTxns extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.mTxns = [];
    }
  }

  render() {
    const { mTxns, mTxnsCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreMTxns,
      firstMTxnsLoading,
    } = this.props;

    return (
      <div className="search-mTxns">
        <h1>Searching mTxns</h1>
        <HeadListMTxns
          initialKeywords={keywords}
          loading={firstMTxnsLoading}
        />

        {!firstMTxnsLoading && mTxns && mTxns.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListMTxns
            mTxns={mTxns}
            mTxnsCount={mTxnsCount}
            loading={loading}
            loadMoreMTxns={loadMoreMTxns}
          />
        )}
      </div>
    );
  }
}

export default withMTxnsData(SearchMTxns);
