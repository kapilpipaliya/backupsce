import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';
import S from '../../../components/form/SimpleSelect';
import RDate from '../../../components/shared/CustomDatePicker/index';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI, parsefloat as pF } from '../../../utils/libs';

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class MTxnTypeId extends React.Component {
  render() {
    return (
      <Field name='m_txn_type_id' label='M txn type' component={S} parse={pI} {...this.props} />
    );
  }
}

export class PartyId extends React.Component {
  render() {
    return (
      <Field name='party_id' label='Party' component={S} parse={pI} {...this.props} />
    );
  }
}

export class TakenById extends React.Component {
  render() {
    return (
      <Field name='taken_by_id' label='Taken by' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Date extends React.Component {
  render() {
    return (
      <Field name='date' label='Date' type='datetime' component={RDate} {...this.props} />
    );
  }
}

export class DueDate extends React.Component {
  render() {
    return (
      <Field name='due_date' label='Due date' type='datetime' component={RDate} {...this.props} />
    );
  }
}

export class TotalWeight extends React.Component {
  render() {
    return (
      <Field name='total_weight' label='Total weight' component={F} parse={pF} placeholder='Total weight' type='number' {...this.props} />
    );
  }
}

export class Amount extends React.Component {
  render() {
    return (
      <Field name='amount' label='Amount' component={F} parse={pF} placeholder='Amount' type='number' {...this.props} />
    );
  }
}

export class Description extends React.Component {
  render() {
    return (
      <Field name='description' label='Description' component={F} {...this.props} />
    );
  }
}

// import { Position, MTxnTypeId, PartyId, TakenById, Date, DueDate, TotalWeight, Amount, Description } from './_MTxnFields'; // eslint-disable-line no-unused-vars
