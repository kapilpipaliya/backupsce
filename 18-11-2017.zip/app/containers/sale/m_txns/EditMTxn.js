import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import MTxnForm from './_MTxnForm';
import withMTxnForEditing from '../../../queries/sale/m_txns/mTxnForEditingQuery';
import withUpdateMTxn from '../../../mutations/sale/m_txns/updateMTxnMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditMTxn extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { mTxn, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing mTxn</h1>
        <MTxnForm action={this.props.updateMTxn} initialValues={{ ...flatIDValue(mTxn) }} submitName="Update MTxn" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  mTxn: gql`
    fragment MTxnForEditingFragment on SaleMTxn {
      id
      position
      m_txn_type_id { id slug }
      party_id { id slug }
      taken_by_id { id slug }
      date
      due_date
      total_weight
      amount
      description
    }
  `,
};

export default withMTxnForEditing(withUpdateMTxn(EditMTxn));
