import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import MTxnPreview from './_MTxnPreview';

class ListMTxns extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allSaleMTxns,
      // mTxnsCount,
      loading,
      error,
      // loadMoreMTxns,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allSaleMTxns}
        columns={[
          // @formatter:off
          { accessor: 'MTxnPreview', Header: '-', Cell: (props) => <MTxnPreview mTxnRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'position', Header: 'SN#' },
          { Header: 'M txn type', Cell: (props) => (props.original.m_txn_type_id ? props.original.m_txn_type_id.slug : undefined) },
          { Header: 'Party', Cell: (props) => (props.original.party_id ? props.original.party_id.slug : undefined) },
          { Header: 'Taken by', Cell: (props) => (props.original.taken_by_id ? props.original.taken_by_id.slug : undefined) },
          { accessor: 'date', Header: 'Date' },
          { accessor: 'due_date', Header: 'Due date' },
          { accessor: 'total_weight', Header: 'Total weight' },
          { accessor: 'amount', Header: 'Amount' },
          { accessor: 'description', Header: 'Description' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListMTxns;
