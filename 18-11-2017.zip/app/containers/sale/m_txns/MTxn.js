import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withMTxn from '../../../queries/sale/m_txns/mTxnQuery';

class MTxn extends Component {
  render() {
    const { mTxn, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="mTxn">
        <p>MTxn</p>
        <h2 className="mTxn-heading">{mTxn.slug}</h2>
        <div className="mTxn-meta">
          <span className="mTxn-author">
            Posted by: <em>{/* {mTxn.author.name} */}</em>
          </span>
          <span className="mTxn-date">
            {moment(new Date(mTxn.created_at)).fromNow()}
          </span>
        </div>
        <div className="mTxn-content">
          contents display here: ID : {mTxn.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  mTxn: gql`
    fragment MTxnFragment on SaleMTxn {
      id
      position
      m_txn_type_id { id slug }
      party_id { id slug }
      taken_by_id { id slug }
      date
      due_date
      total_weight
      amount
      description
      created_at
    }
  `,
};

export default withMTxn(MTxn);
