import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withSalesData from '../../../queries/sale/sales/salesQuery';

import ListSales from './_ListSales';
import HeadListSales from './_HeadListSales';

class AllSales extends Component {
  componentDidMount() {
    this.props.sales.refetch(); // You can pass variables here.
  }

  render() {
    const { sales: { loading, error }, sales } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListSales />
        <ListSales data={sales} />
      </div>
    );
  }
}

export default withSalesData(AllSales);
