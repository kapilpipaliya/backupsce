import React, { Component } from 'react';
import Button from 'material-ui/Button';
import SaleForm from './_SaleForm';
import withCreateSale from '../../../mutations/sale/sales/createSaleMutation';

class NewSale extends Component {
  render() {
    return (
      <div>
        <h1>New Sale</h1>
        <SaleForm action={this.props.createSale} submitName="Create Sale" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateSale(NewSale);
