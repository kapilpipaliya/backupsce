import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import SaleForm from './_SaleForm';
import withSaleForEditing from '../../../queries/sale/sales/saleForEditingQuery';
import withUpdateSale from '../../../mutations/sale/sales/updateSaleMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditSale extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { sale, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing sale</h1>
        <SaleForm action={this.props.updateSale} initialValues={{ ...flatIDValue(sale) }} submitName="Update Sale" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  sale: gql`
    fragment SaleForEditingFragment on SaleSale {
      id
      position
      customer_id { id slug }
      sold_by_id { id slug }
      date
      due_date
      description
      net_weight
      pure_weight
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
      tax
      discount
      amount
    }
  `,
};

export default withSaleForEditing(withUpdateSale(EditSale));
