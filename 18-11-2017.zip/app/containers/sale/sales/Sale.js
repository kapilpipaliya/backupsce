import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withSale from '../../../queries/sale/sales/saleQuery';

class Sale extends Component {
  render() {
    const { sale, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="sale">
        <p>Sale</p>
        <h2 className="sale-heading">{sale.slug}</h2>
        <div className="sale-meta">
          <span className="sale-author">
            Posted by: <em>{/* {sale.author.name} */}</em>
          </span>
          <span className="sale-date">
            {moment(new Date(sale.created_at)).fromNow()}
          </span>
        </div>
        <div className="sale-content">
          contents display here: ID : {sale.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  sale: gql`
    fragment SaleFragment on SaleSale {
      id
      position
      customer_id { id slug }
      sold_by_id { id slug }
      date
      due_date
      description
      net_weight
      pure_weight
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
      tax
      discount
      amount
      created_at
    }
  `,
};

export default withSale(Sale);
