import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';
import S from '../../../components/form/SimpleSelect';
import RDate from '../../../components/shared/CustomDatePicker/index';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI, parsefloat as pF } from '../../../utils/libs';

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class CustomerId extends React.Component {
  render() {
    return (
      <Field name='customer_id' label='Customer' component={S} parse={pI} {...this.props} />
    );
  }
}

export class SoldById extends React.Component {
  render() {
    return (
      <Field name='sold_by_id' label='Sold by' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Date extends React.Component {
  render() {
    return (
      <Field name='date' label='Date' type='datetime' component={RDate} {...this.props} />
    );
  }
}

export class DueDate extends React.Component {
  render() {
    return (
      <Field name='due_date' label='Due date' type='datetime' component={RDate} {...this.props} />
    );
  }
}

export class Description extends React.Component {
  render() {
    return (
      <Field name='description' label='Description' component={F} {...this.props} />
    );
  }
}

export class NetWeight extends React.Component {
  render() {
    return (
      <Field name='net_weight' label='Net weight' component={F} parse={pF} placeholder='Net weight' type='number' {...this.props} />
    );
  }
}

export class PureWeight extends React.Component {
  render() {
    return (
      <Field name='pure_weight' label='Pure weight' component={F} parse={pF} placeholder='Pure weight' type='number' {...this.props} />
    );
  }
}

export class DiamondPcs extends React.Component {
  render() {
    return (
      <Field name='diamond_pcs' label='Diamond pcs' component={F} parse={pI} placeholder='Diamond pcs' type='number' {...this.props} />
    );
  }
}

export class DiamondWeight extends React.Component {
  render() {
    return (
      <Field name='diamond_weight' label='Diamond weight' component={F} parse={pF} placeholder='Diamond weight' type='number' {...this.props} />
    );
  }
}

export class CsPcs extends React.Component {
  render() {
    return (
      <Field name='cs_pcs' label='Cs pcs' component={F} parse={pI} placeholder='Cs pcs' type='number' {...this.props} />
    );
  }
}

export class CsWeight extends React.Component {
  render() {
    return (
      <Field name='cs_weight' label='Cs weight' component={F} parse={pF} placeholder='Cs weight' type='number' {...this.props} />
    );
  }
}

export class GrossWeight extends React.Component {
  render() {
    return (
      <Field name='gross_weight' label='Gross weight' component={F} parse={pF} placeholder='Gross weight' type='number' {...this.props} />
    );
  }
}

export class Tax extends React.Component {
  render() {
    return (
      <Field name='tax' label='Tax' component={F} parse={pF} placeholder='Tax' type='number' {...this.props} />
    );
  }
}

export class Discount extends React.Component {
  render() {
    return (
      <Field name='discount' label='Discount' component={F} parse={pF} placeholder='Discount' type='number' {...this.props} />
    );
  }
}

export class Amount extends React.Component {
  render() {
    return (
      <Field name='amount' label='Amount' component={F} parse={pF} placeholder='Amount' type='number' {...this.props} />
    );
  }
}

// import { Position, CustomerId, SoldById, Date, DueDate, Description, NetWeight, PureWeight, DiamondPcs, DiamondWeight, CsPcs, CsWeight, GrossWeight, Tax, Discount, Amount } from './_SaleFields'; // eslint-disable-line no-unused-vars
