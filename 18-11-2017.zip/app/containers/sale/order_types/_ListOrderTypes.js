import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import OrderTypePreview from './_OrderTypePreview';

class ListOrderTypes extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allSaleOrderTypes,
      // orderTypesCount,
      loading,
      error,
      // loadMoreOrderTypes,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allSaleOrderTypes}
        columns={[
          // @formatter:off
          { accessor: 'OrderTypePreview', Header: '-', Cell: (props) => <OrderTypePreview orderTypeRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'slug', Header: 'Code' },
          { accessor: 'order_type', Header: 'Order type' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListOrderTypes;
