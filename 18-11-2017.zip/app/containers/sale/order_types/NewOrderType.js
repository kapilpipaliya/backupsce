import React, { Component } from 'react';
import Button from 'material-ui/Button';
import OrderTypeForm from './_OrderTypeForm';
import withCreateOrderType from '../../../mutations/sale/order_types/createOrderTypeMutation';

class NewOrderType extends Component {
  render() {
    return (
      <div>
        <h1>New OrderType</h1>
        <OrderTypeForm action={this.props.createOrderType} submitName="Create OrderType" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateOrderType(NewOrderType);
