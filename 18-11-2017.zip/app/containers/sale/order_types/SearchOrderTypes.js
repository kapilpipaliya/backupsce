import React, { Component } from 'react';
import ListOrderTypes from './_ListOrderTypes';
import HeadListOrderTypes from './_HeadListOrderTypes';
import withOrderTypesData from '../../../queries/sale/order_types/orderTypesQuery';

class SearchOrderTypes extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.orderTypes = [];
    }
  }

  render() {
    const { orderTypes, orderTypesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreOrderTypes,
      firstOrderTypesLoading,
    } = this.props;

    return (
      <div className="search-orderTypes">
        <h1>Searching orderTypes</h1>
        <HeadListOrderTypes
          initialKeywords={keywords}
          loading={firstOrderTypesLoading}
        />

        {!firstOrderTypesLoading && orderTypes && orderTypes.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListOrderTypes
            orderTypes={orderTypes}
            orderTypesCount={orderTypesCount}
            loading={loading}
            loadMoreOrderTypes={loadMoreOrderTypes}
          />
        )}
      </div>
    );
  }
}

export default withOrderTypesData(SearchOrderTypes);
