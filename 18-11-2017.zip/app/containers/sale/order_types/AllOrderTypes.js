import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withOrderTypesData from '../../../queries/sale/order_types/orderTypesQuery';

import ListOrderTypes from './_ListOrderTypes';
import HeadListOrderTypes from './_HeadListOrderTypes';

class AllOrderTypes extends Component {
  componentDidMount() {
    this.props.ordertypes.refetch(); // You can pass variables here.
  }

  render() {
    const { ordertypes: { loading, error }, ordertypes } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListOrderTypes />
        <ListOrderTypes data={ordertypes} />
      </div>
    );
  }
}

export default withOrderTypesData(AllOrderTypes);
