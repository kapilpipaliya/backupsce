import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withOrder from '../../../queries/sale/orders/orderQuery';

class Order extends Component {
  render() {
    const { order, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="order">
        <p>Order</p>
        <h2 className="order-heading">{order.slug}</h2>
        <div className="order-meta">
          <span className="order-author">
            Posted by: <em>{/* {order.author.name} */}</em>
          </span>
          <span className="order-date">
            {moment(new Date(order.created_at)).fromNow()}
          </span>
        </div>
        <div className="order-content">
          contents display here: ID : {order.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  order: gql`
    fragment OrderFragment on SaleOrder {
      id
      position
      customer_id { id slug }
      taken_by_id { id slug }
      order_type_id { id slug }
      order_date
      delivery_date
      product_type_id { id slug }
      description
      created_at
    }
  `,
};

export default withOrder(Order);
