import { combineReducers } from 'redux';

import {
  FETCH_MATERIALS,
  FETCH_METAL_PURITIES,
  FETCH_STYLES,
  FETCH_STYLE_COMPLETE,
  FETCH_D_GEM_CLARITIES,
  FETCH_CS_GEM_CLARITIES,
  FETCH_GEMSIZES,
  FETCH_COLORS,
  FETCH_D_COLORS,
  FETCH_CS_COLORS,
  FETCH_PRIORITIES,
  FETCH_LOCATIONS,
  DELETE_JOB_ROW,
} from './actions_order';

const orderJobMaterials = function (previousState = {}, action) {
  switch (action.type) {
    case FETCH_MATERIALS: {
      const n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n[action.row] = v;
      });
      return n;
    }
    case DELETE_JOB_ROW: {
      const d = Object.assign({}, previousState);
      delete d[action.payload];
      return d;
    }
    default: {
      return previousState;
    }
  }
};
const orderJobMetalPurities = function (previousState = {}, action) {
  switch (action.type) {
    case FETCH_METAL_PURITIES: {
      const n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n[action.row] = v;
      });
      return n;
    }
    case DELETE_JOB_ROW: {
      const d = Object.assign({}, previousState);
      delete d[action.payload];
      return d;
    }
    default: {
      return previousState;
    }
  }
};
const orderJobStyles = function (previousState = {}, action) {
  switch (action.type) {
    case FETCH_STYLES: {
      const n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n[action.row] = v;
      });
      return n;
    }
    case DELETE_JOB_ROW: {
      const d = Object.assign({}, previousState);
      delete d[action.payload];
      return d;
    }
    default: {
      return previousState;
    }
  }
};
const orderJobStyleComplete = function (previousState = {}, action) {
  switch (action.type) {
    case FETCH_STYLE_COMPLETE: {
      const n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n[action.row] = v;
      });
      return n;
    }
    case DELETE_JOB_ROW: {
      const d = Object.assign({}, previousState);
      delete d[action.payload];
      return d;
    }
    default: {
      return previousState;
    }
  }
};
const orderJobDGemClarities = function (previousState = {}, action) {
  switch (action.type) {
    case FETCH_D_GEM_CLARITIES: {
      const n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n[action.row] = v;
      });
      return n;
    }
    case DELETE_JOB_ROW: {
      const d = Object.assign({}, previousState);
      delete d[action.payload];
      return d;
    }
    default: {
      return previousState;
    }
  }
};
const orderJobCSGemClarities = function (previousState = {}, action) {
  switch (action.type) {
    case FETCH_CS_GEM_CLARITIES: {
      const n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n[action.row] = v;
      });
      return n;
    }
    case DELETE_JOB_ROW: {
      const d = Object.assign({}, previousState);
      delete d[action.payload];
      return d;
    }
    default: {
      return previousState;
    }
  }
};
const orderJobGemsizes = function (previousState = {}, action) {
  switch (action.type) {
    case FETCH_GEMSIZES: {
      const n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n[action.row] = v;
      });
      return n;
    }
    case DELETE_JOB_ROW: {
      const d = Object.assign({}, previousState);
      delete d[action.payload];
      return d;
    }
    default: {
      return previousState;
    }
  }
};
const orderJobColors = function (previousState = {}, action) {
  switch (action.type) {
    case FETCH_COLORS: {
      const n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n[action.row] = v;
      });
      return n;
    }
    case DELETE_JOB_ROW: {
      const d = Object.assign({}, previousState);
      delete d[action.payload];
      return d;
    }
    default: {
      return previousState;
    }
  }
};
const orderJobDColors = function (previousState = {}, action) {
  switch (action.type) {
    case FETCH_D_COLORS: {
      const n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n[action.row] = v;
      });
      return n;
    }
    case DELETE_JOB_ROW: {
      const d = Object.assign({}, previousState);
      delete d[action.payload];
      return d;
    }
    default: {
      return previousState;
    }
  }
};
const orderJobCSColors = function (previousState = {}, action) {
  switch (action.type) {
    case FETCH_CS_COLORS: {
      const n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n[action.row] = v;
      });
      return n;
    }
    case DELETE_JOB_ROW: {
      const d = Object.assign({}, previousState);
      delete d[action.payload];
      return d;
    }
    default: {
      return previousState;
    }
  }
};
const orderJobPriorities = function (previousState = {}, action) {
  switch (action.type) {
    case FETCH_PRIORITIES: {
      const n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n[action.row] = v;
      });
      return n;
    }
    case DELETE_JOB_ROW: {
      const d = Object.assign({}, previousState);
      delete d[action.payload];
      return d;
    }
    default: {
      return previousState;
    }
  }
};
const orderJobLocations = function (previousState = {}, action) {
  switch (action.type) {
    case FETCH_LOCATIONS: {
      const n = Object.assign({}, previousState);
      action.payload.then((v) => {
        n[action.row] = v;
      });
      return n;
    }
    case DELETE_JOB_ROW: {
      const d = Object.assign({}, previousState);
      delete d[action.payload];
      return d;
    }
    default: {
      return previousState;
    }
  }
};

export default combineReducers({
  jobMaterials: orderJobMaterials,
  jobMetalPurities: orderJobMetalPurities,
  jobStyles: orderJobStyles,
  jobStyleComplete: orderJobStyleComplete,
  jobDGemClarities: orderJobDGemClarities,
  jobCSGemClarities: orderJobCSGemClarities,
  jobGemsizes: orderJobGemsizes,
  jobColors: orderJobColors,
  jobDColors: orderJobDColors,
  jobCSColors: orderJobCSColors,
  jobPriorities: orderJobPriorities,
  jobLocations: orderJobLocations,
});
