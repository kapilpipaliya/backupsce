import React, { Component } from 'react';
import Button from 'material-ui/Button';
import OrderForm from './_OrderForm';
import withCreateOrder from '../../../mutations/sale/orders/createOrderMutation';

class NewOrder extends Component {
  render() {
    return (
      <div>
        <h1>New Order</h1>
        <OrderForm action={this.props.createOrder} submitName="Create Order" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateOrder(NewOrder);
