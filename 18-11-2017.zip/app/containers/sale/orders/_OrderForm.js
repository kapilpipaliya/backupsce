import React, { Component } from 'react';
import PropTypes from 'prop-types';
// Redux-Form
import { reduxForm, SubmissionError } from 'redux-form/immutable';

import WizardFormJobsPage from './Forms/WizardFormJobsMainPage';
import WizardFormDiamondsPage from './Forms/WizardFormDiamondsPage';
import JobsFormTable from './Forms/JobsFormTable';

class OrderForm extends Component {
  static propTypes = {
    action: PropTypes.func,
    // submitName: PropTypes.string.isRequired,
    // handleSubmit: PropTypes.func,
  };
  constructor(props) {
    super(props);
    // this.state = { loading: false };
    this.submitForm = this.submitForm.bind(this);
    this.state = {
      page: 1,
    };
  }

  jobsPage = () => {
    // console.log('job page request');
    this.setState({ page: 1 });
  };
  diamondsPage = (jobno) => {
    // console.log('diamonds page request', jobno);
    this.setState({
      page: 2,
      jobno,
    });
  };

  submitForm = (values) =>
    // this.setState({ loading: true });
    this.props.action(values).then((errors) => {
      if (errors) {
        // this.setState({ loading: false });
        throw new SubmissionError(errors);
      }
    });

  render() {
    // const {handleSubmit, pristine, reset, invalid, submitting, submitName} = this.props;
    // const {loading} = this.state;

    const { page } = this.state;

    return (
      <div>
        {page === 1 && <WizardFormJobsPage diamondsPage={this.diamondsPage} onSubmit={this.submitForm} change={this.props.change} />}
        {page === 2 && <WizardFormDiamondsPage jobno={this.state.jobno} onSubmit={this.jobsPage} change={this.props.change} />}

        <h5>Jobs (View):</h5>
        <JobsFormTable />
      </div>
    );
  }
}
// using to pass change function.
export default reduxForm({
  form: 'new_order',
  // validate,
})(OrderForm);

// export default OrderForm;
