// Utilites
// React
import React, { Component } from 'react';
// import PropTypes from 'prop-types';
// Redux
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
// Redux-Form
import { Field, FieldArray, formValueSelector, reduxForm } from 'redux-form/immutable';
// import validate from '../validate'
// React-Apollo
import { withApollo } from 'react-apollo';
import { fromJS, List } from 'immutable';
// Material-Ui
import { withStyles } from 'material-ui/styles';
import Button from 'material-ui/Button';
import { FormLabel } from 'material-ui/Form';
import Grid from 'material-ui/Grid';
import moment from 'moment';
import Card, { CardActions, CardContent } from 'material-ui/Card';
// import { FormControl, FormHelperText } from 'material-ui/Form';
// import validate from '../validate'
import * as actions from '../reducers/actions_order';
import RenderJobs from './WizardFormJobsSubPage';
import RenderRadio from '../../../../components/form/RenderRadio';
import { Position, CustomerId, TakenById, OrderTypeId, OrderDate, DeliveryDate, ProductTypeId, Description } from '../_OrderFields'; // eslint-disable-line no-unused-vars

import HOCFetch from '../../../HOC/Fetch';
import { fexecuteS2, fexecuteA, fexecutePT } from '../../../../utils/Fetch';

const styles = (theme) => ({
  card: {
    minWidth: 275,
  },
  // card: {},
  title: {
    marginBottom: 16,
    fontSize: 14,
    color: theme.palette.text.secondary,
  },
  pos: {
    marginBottom: 12,
    color: theme.palette.text.secondary,
  },
  bullet: {},
});

@withApollo
@HOCFetch
@withStyles(styles)
class WizardFormJobsPage extends Component {
  componentDidMount() {
    this.props.fetch(fexecuteA, 'customers', 2); // Fetch Customer.
    this.props.fetch(fexecuteA, 'staffs', 1); // staffs
    this.props.fetch(fexecutePT, 'producttypes', 1); // Product Types.
    this.props.change('date', moment().toISOString());
    this.props.change('due_date', moment().toISOString());
  }

  showJobSummery = () => (
    <span>All Materials - Purity - Color: NetWt, PureWt, DPCS, DWt, CSPCS, CSWt, GrossWt</span>
  )

  render() {
    const { classes } = this.props;
    // TODO support error handling.
    // eslint-disable-next-line
    const renderError = ({ meta: { touched, error } }) => (touched && error ? <span>{error}</span> : false);
    const { handleSubmit, diamondsPage } = this.props;
    return (
      <Card>


        <Grid className={classes.container} container spacing={16}>
          <Grid item xs={6}>
            <Card className={classes.card}>
              <form onSubmit={handleSubmit}>
                <CardContent>
                  <Grid item xs={12}><Position label="SN#" /></Grid>
                  <br /> <br />
                  <Grid item xs={12}>
                    <FormLabel>Order Type </FormLabel>
                    <div>
                      <label htmlFor="order_type_id">
                        <Field
                          name="order_type_id"
                          component={RenderRadio}
                          type="radio"
                          value="1"
                        />{' '}
                        Regular Order
                      </label>
                      <label htmlFor="order_type_id">
                        <Field
                          name="order_type_id"
                          component={RenderRadio}
                          type="radio"
                          value="2"
                        />{' '}
                        Repair Order
                      </label>
                    </div>
                  </Grid>

                  <Grid item xs={12}><CustomerId options={this.props.customers} /></Grid>
                  <Grid item xs={4}><span>Order Date: </span></Grid>
                  <Grid item xs={8}><OrderDate /></Grid>
                  <Grid item xs={4}><span>Delivery Date: </span></Grid>
                  <Grid item xs={8}><DeliveryDate /></Grid>

                  <Grid item xs={12}><ProductTypeId options={this.props.producttypes} oField="product_type" /></Grid>
                  <Grid item xs={6}><TakenById options={this.props.staffs} /></Grid>
                  {/* <Field name="due_date" type="date" component={RenderField} label="Due Date" placeholder='' InputLabelProps={{shrink: true,}}/> */}
                  <Grid item xs={6}><Description /></Grid>
                </CardContent>
                <CardActions>
                  <Button raised color="primary" type="submit" className="next">Next</Button>
                  <Button raised onClick={this.props.reset} style={{ margin: '5px' }}>Reset Form</Button>
                </CardActions>
              </form>
            </Card>
          </Grid>
        </Grid>


        <form onSubmit={handleSubmit}>
          <CardContent>
            <h2>Jobs:</h2>
            <FieldArray
              name="jobs"
              component={RenderJobs}
              diamondsPage={diamondsPage}
              change={this.props.change}
              jobs={this.props.jobs}
              total_d_pcs={this.props.total_d_pcs}
              total_d_wt={this.props.total_d_wt}
              total_cs_pcs={this.props.total_cs_pcs}
              total_cs_weight={this.props.total_cs_weight}
              total_gross_wt={this.props.total_gross_wt}
              jobMaterials={this.props.jobMaterials}
              jobMetalPurities={this.props.jobMetalPurities}
              jobStyles={this.props.jobStyles}
              jobStyleComplete={this.props.jobStyleComplete}
              jobDGemClarities={this.props.jobDGemClarities}
              jobCSGemClarities={this.props.jobCSGemClarities}
              jobGemsizes={this.props.jobGemsizes}
              jobColors={this.props.jobColors}
              jobDColors={this.props.jobDColors}
              jobCSColors={this.props.jobCSColors}
              jobPriorities={this.props.jobPriorities}
              jobLocations={this.props.jobLocations}
              orderFetchMaterials={this.props.actions.orderFetchMaterials}
              orderFetchMetalPurities={this.props.actions.orderFetchMetalPurities}
              orderFetchStyles={this.props.actions.orderFetchStyles}
              orderFetchStyleComplete={this.props.actions.orderFetchStyleComplete}
              orderFetchDGemClarities={this.props.actions.orderFetchDGemClarities}
              orderFetchCSGemClarities={this.props.actions.orderFetchCSGemClarities}
              orderFetchGemsizes={this.props.actions.orderFetchGemsizes}
              orderFetchColors={this.props.actions.orderFetchColors}
              orderFetchDColors={this.props.actions.orderFetchDColors}
              orderFetchCSColors={this.props.actions.orderFetchCSColors}
              orderFetchPriorities={this.props.actions.orderFetchPriorities}
              orderFetchLocations={this.props.actions.orderFetchLocations}
              orderJobDeleteRow={this.props.actions.orderJobDeleteRow}
              calcStyleChange={this.props.calcStyleChange}
            />
          </CardContent>
          <CardActions>
            <Button raised color="primary" type="submit">
              Submit
            </Button>
            {this.showJobSummery()}
          </CardActions>
        </form>
      </Card>
    );
  }
}

WizardFormJobsPage.propTypes = {
  // classes: PropTypes.object.isRequired,
};

// Decorate with connect to read form values
// Job - Using Selector
// Options - Using Thunk to get Redux State.
const selector = formValueSelector('new_order'); // <-- same as form name
const mapStateToProps = (state) => {
  const position = selector(state, 'position');
  const slug = selector(state, 'slug');
  const { description, customer } = selector(state, 'description', 'customer');
  let jobs = selector(state, 'jobs');
  if (!jobs) jobs = List();
  let totalJobs = 0;
  let totalQty = 0;
  let totalDPcs = 0;
  let totalDWt = 0.0;
  let totalCSPcs = 0;
  let totalCSWt = 0.0;
  let totalGrossWt = 0.0;
  if (jobs && jobs.length > 0) {
    jobs.forEach((item) => {
      totalJobs = jobs.length;
      totalQty += item.qty;
      totalDPcs += item.diamond_pcs;
      totalDWt += item.diamond_weight;
      totalCSPcs += item.cs_pcs;
      totalCSWt += item.cs_weight;
      totalGrossWt += item.gross_weigh;
    });
  }
  return {
    position,
    slug,
    description,
    customer,
    jobs,
    totalJobs,
    totalQty,
    totalDPcs,
    totalDWt,
    totalCSPcs,
    totalCSWt,
    totalGrossWt,
    jobMaterials: state.get('order_form').jobMaterials,
    jobMetalPurities: state.get('order_form').jobMetalPurities,
    jobStyles: state.get('order_form').jobStyles,
    jobStyleComplete: state.get('order_form').jobStyleComplete,
    jobDGemClarities: state.get('order_form').jobDGemClarities,
    jobCSGemClarities: state.get('order_form').jobCSGemClarities,
    jobGemsizes: state.get('order_form').jobGemsizes,
    jobColors: state.get('order_form').jobColors,
    jobDColors: state.get('order_form').jobDColors,
    jobCSColors: state.get('order_form').jobCSColors,
    jobPriorities: state.get('order_form').jobPriorities,
    jobLocations: state.get('order_form').jobLocations,
  };
};

const mapDispatchToProps = (dispatch) => ({
  actions: bindActionCreators({ ...actions }, dispatch),
  calcStyleChange: (a1, a, b, d, change) => {
    dispatch(doStyleChangeActions(a1, a, b, d, change));
  },
});

const J = connect(mapStateToProps, mapDispatchToProps)(WizardFormJobsPage);

const JF = reduxForm({
  form: 'new_order', // Form name is same
  destroyOnUnmount: false,
  forceUnregisterOnUnmount: true, // <------ unregister fields on unmount
  // validate
})(J);

export default JF;

// Actions. Redux-Thunk Can Return Function instead of action.
function doStyleChangeActions(aClient, row, sID, name, change) {
  return (dispatch, getState) => {
    dispatch(actions.orderFetchStyleComplete(aClient, sID, row));
    dispatch(actions.orderFetchMaterials(aClient, 1, row));
    // console.log(getState().order_form.jobStyleComplete[row])
    fexecuteS2(aClient, sID).then(async (style) => { // TRICK // TODO direct chane state with redux-thunk...
      dispatch(actions.orderFetchMetalPurities(aClient, parseInt(style.material.id, 10), row));
      dispatch(actions.orderFetchColors(aClient, parseInt(style.material.id, 10), row));
      // const name = `${this.props.fields.name}[${row}]`;
      change(`${name}.material_id`, parseInt(style.material.id, 10));
      change(`${name}.metal_purity_id`, parseInt(style.metal_purity.id, 10));
      change(`${name}.metal_color_id`, parseInt(style.color.id, 10));

      // const { qty } = getState().form.new_order.values.jobs[row];
      const { qty } = selector(getState(), 'jobs').get(row).toJS();
      //
      change(`${name}.net_weight`, style.net_weight * qty);
      change(`${name}.pure_weight`, style.pure_weight * qty);
      change(`${name}.diamond_pcs`, style.diamond_pcs * qty);
      change(`${name}.diamond_weight`, style.diamond_weight * qty);
      change(`${name}.cs_pcs`, style.cs_pcs * qty);
      change(`${name}.cs_weight`, style.cs_weight * qty);
      change(`${name}.gross_weight`, style.gross_weight * qty);

      change(`${name}.diamond_clarity_id`, 0);
      change(`${name}.diamond_color_id`, 0);
      change(`${name}.cs_clarity_id`, 0);
      change(`${name}.cs_color_id`, 0);

      // const styleDiamonds = getState().order_form.jobStyleComplete[row].diamonds;
      const orderForm = getState().get('order_form');
      const styleDiamonds = orderForm.jobStyleComplete[row].diamonds;

      const newDiamonds = styleDiamonds.map((currentValue) => {
        // clone the current object
        const newObj = Object.assign({}, currentValue);
        // update the new object
        newObj.color_id = parseInt(currentValue.color.id, 10);
        newObj.gem_clarity_id = parseInt(currentValue.gem_clarity.id, 10);
        newObj.gem_shape_id = parseInt(currentValue.gem_shape.id, 10);
        newObj.gem_size_id = parseInt(currentValue.gem_size.id, 10);
        newObj.material_id = parseInt(currentValue.material.id, 10);

        delete newObj.color;
        delete newObj.gem_clarity;
        delete newObj.gem_shape;
        delete newObj.gem_size;
        delete newObj.material;
        newObj.pcs = currentValue.pcs * qty;
        newObj.pointer = currentValue.pointer * qty;
        newObj.weight = currentValue.weight * qty;
        return newObj;
      });
      change(`${name}.diamonds`, fromJS(newDiamonds));
      // calcTotals()*/ // Todo
    });
  };
}
