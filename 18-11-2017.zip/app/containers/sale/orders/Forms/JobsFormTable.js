import React, { Component } from 'react';
import { connect } from 'react-redux';
import { formValueSelector } from 'redux-form/immutable';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';

class JobsFormTable extends Component {
  render() {
    let data = [];
    if (this.props.jobs) data = this.props.jobs.toJS();

    const columns = [
      // @formatter:off
      { Header: 'Position', accessor: 'position' },
      { Header: 'Style', accessor: 'style_id' },
      { Header: 'Product Type', accessor: 'product_type_id' },
      { Header: 'Location', accessor: 'location_id' },
      { Header: 'Material', accessor: 'material_id' },
      { Header: 'Purity', accessor: 'metal_purity_id' },
      { Header: 'Tone', accessor: 'metal_color_id' },
      { Header: 'Qty', accessor: 'qty' },
      { Header: 'D Clarity', accessor: 'diamond_clarity_id' },
      { Header: 'D Color', accessor: 'diamond_color_id' },
      { Header: 'CS Clarity', accessor: 'cs_clarity_id' },
      { Header: 'CS Color', accessor: 'cs_color_id' },
      { Header: 'description', accessor: 'description' },
      { Header: 'Item Size', accessor: 'item_size' },
      { Header: 'Priority', accessor: 'priority_id' },
      { Header: 'Department', accessor: 'department_id' },
      { Header: 'Sub Department', accessor: 'sub_department_id' },
      { Header: 'Net Wt', accessor: 'net_weight' },
      { Header: 'Pure Wt', accessor: 'pure_weight' },
      { Header: 'D PCs', accessor: 'diamond_pcs' },
      { Header: 'D Wt', accessor: 'diamond_weight' },
      { Header: 'CS PCs', accessor: 'cs_pcs' },
      { Header: 'CS Wt', accessor: 'cs_weight' },
      { Header: 'Gross Wt', accessor: 'gross_weight' },

      // Cell: props => <span className='number'>{props.value}</span> // Custom cell components!
      // },
      //   {
      //   id: 'friendName', // Required because our accessor is not a string
      //   Header: 'Friend Name',
      //   accessor: d => d.friend.name // Custom value accessors!
      // }, {
      //   Header: props => <span>Friend Age</span>, // Custom header components!
      //   accessor: 'friend.age'
      // }
      // @formatter:on
    ];

    const dColumns = [
      { Header: 'Position', accessor: 'position' },
      { Header: 'Material', accessor: 'material_id' },
      { Header: 'Shape', accessor: 'gem_shape_id' },
      { Header: 'Clarity', accessor: 'gem_clarity_id' },
      { Header: 'Size', accessor: 'gem_size_id' },
      { Header: 'Color', accessor: 'color_id' },
      { Header: 'Pcs', accessor: 'pcs' },
      { Header: 'Pointer', accessor: 'pointer' },
      { Header: 'Weight', accessor: 'weight' },
    ];

    return (
      <ReactTable
        data={data}
        columns={columns}
        defaultPageSize={10}
        SubComponent={(row) => (
          <div style={{ padding: '20px' }}>
            {/* {console.log(row)} */}
            <ReactTable
              data={row.original.diamonds}
              columns={dColumns}
              defaultPageSize={10}
              width={100}
            />
          </div>
        )}
      />
    );
  }
}

/*
JobsFormTable = reduxForm({
  form: 'new_order', //Form name is same
  destroyOnUnmount: false,
  forceUnregisterOnUnmount: true, // <------ unregister fields on unmount
  validate
})(JobsFormTable)
*/

// Decorate with connect to read form values
const selector = formValueSelector('new_order'); // <-- same as form name
const J = connect((state) => {
  const position = selector(state, 'position');
  const slug = selector(state, 'slug');
  const { description, customer } = selector(state, 'description', 'customer');
  const jobs = selector(state, 'jobs');
  return {
    position,
    slug,
    description,
    customer,
    jobs,
  };
})(JobsFormTable);

export default J;
