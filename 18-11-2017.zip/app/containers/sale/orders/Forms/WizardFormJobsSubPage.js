// Utilites
// React
import React, { Component } from 'react';
// import PropTypes from 'prop-types';
// Redux
// import { bindActionCreators } from 'redux';
// Redux-Form
import { Field } from 'redux-form/immutable';
import { fromJS } from 'immutable';
// import validate from '../validate'
// React-Apollo
import { withApollo } from 'react-apollo';
// Material-Ui
import { withStyles } from 'material-ui/styles';
import Button from 'material-ui/Button';
import Icon from 'material-ui/Icon';
import Snackbar from 'material-ui/Snackbar';
import IconButton from 'material-ui/IconButton';
import CloseIcon from 'material-ui-icons/Close';
import Typography from 'material-ui/Typography';
import Dialog, { DialogActions, DialogContent, DialogContentText, DialogTitle } from 'material-ui/Dialog';

// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';

import RSelect from 'react-select';
// Be sure to include styles at some point, probably during your bootstrapping
import 'react-select/dist/react-select.css';
// Sub-Components
import { parseint as pI, parsefloat as pF } from '../../../../utils/libs';
import I from '../../../../components/form/RenderInput';
import Sw from '../../../../components/form/RenderSwitch';
import S from '../../../../components/form/SimpleSelect';
import S2 from '../../../../components/shared/MySelect';

const stylesJob = (theme) => ({
  close: {
    width: theme.spacing.unit * 4,
    height: theme.spacing.unit * 4,
  },
});

class RenderJobs extends Component {
  state = {
    open_dialog: false,
    open_snackbar: false,
    // age: '',
  };
  handleClickOpen = () => {
    this.setState({ open_dialog: true });
  };

  handleRequestClose = () => {
    this.setState({ open_dialog: false });
  };
  handleRequestCloseTrue = () => {
    this.setState({ open_dialog: false });
  };

  handleClickSnackbar = () => {
    this.setState({ open_snackbar: true });
  };

  handleRequestCloseSnackbar = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    this.setState({ open_snackbar: false });
  };
  autoPosition = () => {
    // Fetch all records. and dispatch new position.
  };
  checkboxToogle = (row) => {
    const name = `${this.props.fields.name}[${row}]`;
    this.props.change(`${name}.position`, '');
  };
  materialChange = async (row, value) => {
    this.props.orderFetchMetalPurities(this.props.client, value, row);
    this.props.orderFetchColors(this.props.client, value, row);
  };
  qtyChange = async (row, qty) => {
    const style = this.props.jobStyleComplete[row];
    const name = `${this.props.fields.name}[${row}]`;
    this.props.change(`${name}.net_weight`, style.net_weight * qty);
    this.props.change(`${name}.pure_weight`, style.pure_weight * qty);
    this.props.change(`${name}.diamond_pcs`, style.diamond_pcs * qty);
    this.props.change(`${name}.diamond_weight`, style.diamond_weight * qty);
    this.props.change(`${name}.cs_pcs`, style.cs_pcs * qty);
    this.props.change(`${name}.cs_weight`, style.cs_weight * qty);
    this.props.change(`${name}.gross_weight`, style.gross_weight * qty);

    const styleDiamonds = this.props.jobStyleComplete[row].diamonds;
    const newDiamonds = styleDiamonds.map((obj) => {
      // clone the current object
      const newObj = Object.assign({}, obj);
      // update the new object
      newObj.pcs = obj.pcs * qty;
      newObj.pointer = obj.pointer * qty;
      newObj.weight = obj.weight * qty;
      return newObj;
    });
    this.props.change(`${name}.diamonds`, newDiamonds);
  };
  purityChange = async (row, v) => {
    const style = this.props.jobStyleComplete[row];
    const name = `${this.props.fields.name}[${row}]`;
    if (v) {
      const purity = this.props.jobMetalPurities[row][v];
      const { qty } = this.props.jobs[row];
      const newNetWt = purity.specific_density * style.volume * qty;
      this.props.change(`${name}.net_weight`, newNetWt);
      this.props.change(`${name}.pure_weight`, (purity.purity * newNetWt) / 100);
      this.props.change(`${name}.gross_weight`, newNetWt + ((this.props.total_d_wt + this.props.total_cs_weight) / 5));
    } else {
      this.props.change(`${name}.purity_per`, 0);
      this.props.change(`${name}.pure_weight`, 0);
      this.props.change(`${name}.volume`, 0);
    }
    // TODO Refresh Summery()
  };

  render() {
    // console.log('myprops', this.props);
    const { fields, meta: { touched, error, submitFailed }, diamondsPage } = this.props;

    const data = this.props.jobs.toJS();
    const { classes } = this.props;

    const columns = [
      // @formatter:off
      {
        Header: '',
        Cell: (props) => (
          <div>
            <Typography type="body2" align="center">
              #{props.index + 1}
              <IconButton
                color="accent"
                aria-label="Delete"
                onClick={() => {
                // fields.remove(props.index)
                  this.handleClickOpen();
                }}
              >
                <Icon color="primary" style={{ fontSize: 25 }}>delete_forever</Icon>
              </IconButton>
              <IconButton color="primary" aria-label="Delete" onClick={() => diamondsPage(props.index)}>
                <Icon color="primary" style={{ fontSize: 25 }}>settings</Icon>
              </IconButton>
            </Typography>
            <Dialog open={this.state.open_dialog} onRequestClose={this.handleRequestClose}>
              <DialogTitle>Are You Sure To delete Entry?</DialogTitle>
              <DialogContent>
                <DialogContentText>
                  You can not undo it.
                </DialogContentText>
              </DialogContent>
              <DialogActions>
                <Button onClick={this.handleRequestClose} color="primary">
                  Disagree
                </Button>
                <Button
                  onClick={() => {
                    this.handleRequestCloseTrue();
                    this.props.orderJobDeleteRow(props.index);
                    fields.remove(props.index);
                    this.handleClickSnackbar();
                  }
                  }
                  color="primary"
                  autoFocus
                >
                  Agree
                </Button>
              </DialogActions>
            </Dialog>
          </div>
        ),
      },
      { Header: 'Final *', accessor: 'is_exist', Cell: (props) => <Field name={`jobs[${props.index}].is_exist`} component={Sw} type="checkbox" label="Final" onChange2={(v) => { this.checkboxToogle(props.index, v); }} /> },
      { Header: () => <div>Position<br /><Button onClick={() => this.autoPosition()}>Auto No</Button></div>, Footer: () => <span><i className="fa-tasks" /> Total Jobs :xxx </span>, Cell: (props) => <Field name={`jobs[${props.index}].position`} component={I} type="number" parse={pI} label="Position" disabled={!data[props.index].is_exist} /> },
      { Header: 'Style *', Cell: (props) => <Field name={`jobs[${props.index}].style_id`} component={S} type="text" parse={pI} options={this.props.jobStyles[props.index]} onChange2={(sId) => this.props.calcStyleChange(this.props.client, props.index, sId, `${this.props.fields.name}[${props.index}]`, this.props.change)} /> },
      // { Header: "Product Type", Cell: props => <Field name={`jobs[${props.index}].product_type_id`} component={S} parse={pI} /> },
      { Header: () => <div>Location<br /><S2 /></div>, Cell: (props) => <Field name={`jobs[${props.index}].location_id`} component={S} parse={pI} options={this.props.jobLocations[props.index]} /> },
      { Header: 'Material *', Cell: (props) => <Field name={`jobs[${props.index}].material_id`} component={S} parse={pI} options={this.props.jobMaterials[props.index]} onChange2={(v) => this.materialChange(props.index, v)} /> },
      { Header: 'Purity *', Cell: (props) => <Field name={`jobs[${props.index}].metal_purity_id`} component={S} parse={pI} options={this.props.jobMetalPurities[props.index]} onChange2={(v) => this.purityChange(props.index, v)} /> },
      { Header: 'Tone *', accessor: 'metal_color_id', Cell: (props) => <Field name={`jobs[${props.index}].metal_color_id`} component={S} parse={pI} options={this.props.jobColors[props.index]} /> },
      {
        Header: 'Qty *', Footer: () => <span><i className="fa-tasks" /> Total Qty :xxx </span>, accessor: 'qty', Cell: (props) => <Field name={`jobs[${props.index}].qty`} component={I} parse={pI} type="number" onChange2={(q) => this.qtyChange(props.index, q)} />,
      },
      // TODO MAKE SELECT WORKING FOR D COLOR, CS PCS, CS WT.
      { Header: () => <div>D Clarity<br /><S2 /></div>, Cell: (props) => <Field name={`jobs[${props.index}].diamond_clarity_id`} options={this.props.jobDGemClarities[props.index]} component={S} parse={pI} /> },
      { Header: () => <div>D Color<br /><S2 /></div>, Cell: (props) => <Field name={`jobs[${props.index}].diamond_color_id`} options={this.props.jobDColors[props.index]} component={S} parse={pI} /> },
      { Header: () => <div>CS Clarity<br /><S2 /></div>, Cell: (props) => <Field name={`jobs[${props.index}].cs_clarity_id`} options={this.props.jobCSGemClarities[props.index]} component={S} parse={pI} /> },
      { Header: () => <div>D Color<br /><S2 /></div>, Cell: (props) => <Field name={`jobs[${props.index}].cs_color_id`} options={this.props.jobCSColors[props.index]} component={S} parse={pI} /> },
      { Header: 'description', Cell: (props) => <Field name={`jobs[${props.index}].description`} component={I} type="text" /> },
      { Header: 'Item Size', Cell: (props) => <Field name={`jobs[${props.index}].item_size`} component={I} type="text" parse={pI} /> },
      { Header: 'Priority', Cell: (props) => <Field name={`jobs[${props.index}].priority_id`} component={S} parse={pI} options={this.props.jobPriorities[props.index]} /> },
      // {Header: 'Department', accessor: 'department_id', Cell: props => <Field name={`jobs[${props.index}].department_id`} component={I} parse={pI} />},
      // {Header: 'Sub Department', accessor: 'sub_department_id', Cell: props => <Field name={`jobs[${props.index}].sub_department_id`} component={I} parse={pI} />},
      { Header: 'Net Wt(g)', Footer: () => <span><i className="fa-tasks" /> Total :xxx </span>, Cell: (props) => <Field name={`jobs[${props.index}].net_weight`} component={I} parse={pF} disabled /> },
      { Header: 'Pure Wt(g)', Footer: () => <span><i className="fa-tasks" /> Total :xxx </span>, Cell: (props) => <Field name={`jobs[${props.index}].pure_weight`} component={I} parse={pF} disabled /> },
      { Header: 'D PCs', Footer: () => <span><i className="fa-tasks" /> Total: {this.props.total_d_pcs} </span>, Cell: (props) => <Field name={`jobs[${props.index}].diamond_pcs`} component={I} parse={pI} disabled /> },
      { Header: 'D Wt(Ct)', Footer: () => <span><i className="fa-tasks" /> Total :xxx </span>, Cell: (props) => <Field name={`jobs[${props.index}].diamond_weight`} component={I} parse={pF} disabled /> },
      { Header: 'CS PCs', Footer: () => <span><i className="fa-tasks" /> Total :xxx </span>, Cell: (props) => <Field name={`jobs[${props.index}].cs_pcs`} component={I} parse={pI} disabled /> },
      { Header: 'CS Wt(Ct)', Footer: () => <span><i className="fa-tasks" /> Total :xxx </span>, Cell: (props) => <Field name={`jobs[${props.index}].cs_weight`} component={I} parse={pF} disabled /> },
      { Header: 'Gross Wt(g)', Footer: () => <span><i className="fa-tasks" /> Total :xxx </span>, Cell: (props) => <Field name={`jobs[${props.index}].gross_weight`} component={I} parse={pF} disabled /> },
    // @formatter:on
    ];
    const options = [
      { value: 'one', label: 'One' },
      { value: 'two', label: 'Two' },
    ];
    return (
      <div>
        <span>TODO : MultiSelect select when selected it automatically add values to jobs row.</span>
        <RSelect
          name="form-field-name"
          value="one"
          options={options}
          // onChange={logChange}
          searchable
          multi
        />
        <Button
          raised
          color="primary"
          type="button"
          onClick={async () => {
            fields.push(fromJS({}));
            const row = fields.length;
            this.props.orderFetchStyles(this.props.client, row);
            this.props.orderFetchMaterials(this.props.client, 1, row);
            this.props.orderFetchMetalPurities(this.props.client, 1, row);
            this.props.orderFetchColors(this.props.client, 1, row);
            this.props.orderFetchDColors(this.props.client, 4, row);
            this.props.orderFetchCSColors(this.props.client, 5, row);
            this.props.orderFetchDGemClarities(this.props.client, 4, row);
            this.props.orderFetchCSGemClarities(this.props.client, 5, row);
            this.props.orderFetchPriorities(this.props.client, row);
            this.props.orderFetchLocations(this.props.client, row);
            this.props.change(`${this.props.fields.name}[${row}].qty`, 1);
            this.props.change(`${this.props.fields.name}[${row}].priority_id`, 2);
          }}
        >
          Add Job
        </Button>

        {(touched || submitFailed) && error && <span>{error}</span>}
        <ReactTable data={data} columns={columns} defaultPageSize={10} sortable={false} resizable={false} />
        <Snackbar
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'left',
          }}
          open={this.state.open_snackbar}
          autoHideDuration={6000}
          onRequestClose={this.handleRequestCloseSnackbar}
          SnackbarContentProps={{
            'aria-describedby': 'message-id',
          }}
          message={<span id="message-id">Note archived</span>}
          action={[
            <Button key="undo" color="accent" dense onClick={this.handleRequestCloseSnackbar}>
              UNDO
            </Button>,
            <IconButton
              key="close"
              aria-label="Close"
              color="inherit"
              className={classes.close}
              onClick={this.handleRequestCloseSnackbar}
            >
              <CloseIcon />
            </IconButton>,
          ]}
        />
      </div>
    );
  }
}

export default withStyles(stylesJob)(withApollo(RenderJobs));
