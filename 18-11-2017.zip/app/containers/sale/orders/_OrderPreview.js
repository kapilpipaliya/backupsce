import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroyOrder from '../../../mutations/sale/orders/destroyOrderMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class OrderPreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroyOrder(this.props.orderRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { orderRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(order.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/orders/${orderRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  order: gql`
    fragment OrderPreviewFragment on SaleOrder {
      id
      position
      customer_id { id slug }
      taken_by_id { id slug }
      order_type_id { id slug }
      order_date
      delivery_date
      product_type_id { id slug }
      description
      created_at
    }
  `,
};

export default withDestroyOrder(withCurrentUser(OrderPreview));
