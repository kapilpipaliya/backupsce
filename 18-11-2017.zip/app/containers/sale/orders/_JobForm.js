import React from 'react';
import { compose } from 'redux';
import { connect } from 'react-redux';
import { Field, reduxForm } from 'redux-form/immutable';
// import { RadioGroup } from 'material-ui/Radio';
// import Checkbox from 'material-ui/Checkbox';
// import Select from 'material-ui/Select';
// import asyncValidate from './asyncValidate'
import { Button } from 'material-ui';
import { withStyles } from 'material-ui/styles';
import RenderField from '../../../components/form/RenderField';
import SimpleSelect from '../../../components/form/SimpleSelect';

import withMaterialsData from '../../../queries/material/materials/materialsQuery';
import withColorsData from '../../../queries/material/colors/colorsQuery';
import withGemClaritiesData from '../../../queries/material/gem_clarities/gemClaritiesQuery';
import { parseint as pI } from '../../../utils/libs';
const styles = () => ({
  container: {
    // display: 'inline-block'
  },
});

const validate = (values) => {
  const errors = {};
  const requiredFields = [
    'is_exist',
    'position',
    'style_id',
    'product_type_id',
    'location_id',
    'material_id',
    'metal_purity_id',
    'metal_color_id',
    'qty',
    'diamond_clarity_id',
    'diamond_color_id',
    'cs_clarity_id',
    'cs_color_id',
    'description',
    'item_size',
    'priority_id',
    'department_id',
    'sub_department_id',
    'net_weight',
    'pure_weight',
    'diamond_pcs',
    'diamond_weight',
    'cs_pcs',
    'cs_weight',
    'gross_weight',
  ];
  requiredFields.forEach((field) => {
    if (!values[field]) {
      errors[field] = 'Required';
    }
  });
  if (
    values.email &&
    !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)
  ) {
    errors.email = 'Invalid email address';
  }
  return errors;
};

// const renderCheckbox = ({ input, label }) => (
//   <Checkbox
//     label={label}
//     checked={!!input.value}
//     onChange={input.onChange}
//   />
// );

// const renderRadioGroup = ({ input, ...rest }) => (
//   <RadioGroup
//     {...input}
//     {...rest}
//     valueSelected={input.value}
//     onChange={(event, value) => input.onChange(value)}
//   />
// );

// const renderSelectField = ({
//   input,
//   label,
//   meta: { touched, error },
//   children,
//   ...custom
// }) => (
//   <Select
//     native
//     placeholder={label}
//     // helperText={touched && error}
//     {...input}
//     onChange={(event, index, value) => input.onChange(value)}
//     children={children}
//     {...custom}
//   />
// );

class MaterialUiForm extends React.Component {
  render() {
    const {
      handleSubmit, pristine, reset, submitting,
    } = this.props;

    const { materials: { allMaterialMaterials } } = this.props;
    const { classes } = this.props;

    return (
      <div className={classes.container}>
        {/*
        <Field
          name="favoriteColor"
          component={renderSelectField}
          label="Favorite Color"
        >
          <option value="ff0000" >abc</option>
          <option value="00ff00" >abc</option>
          <option value="0000ff" >abc</option>
        </Field>
*/}
        <Field name="is_exist" component={RenderField} label="is_exist *" />
        <Field name="position" component={RenderField} label="Position *" parse={pI} options={allMaterialMaterials} />
        <Field name="style_id" component={SimpleSelect} label="Style *" parse={pI} options={allMaterialMaterials} />
        <Field name="product_type_id" component={SimpleSelect} label="Product Type *" parse={pI} options={allMaterialMaterials} />
        <Field name="location_id" component={SimpleSelect} label="Location *" parse={pI} options={allMaterialMaterials} />
        <Field name="material_id" component={SimpleSelect} label="Material *" parse={pI} options={allMaterialMaterials} />
        <Field name="metal_purity_id" component={SimpleSelect} label="Metal Purity *" parse={pI} options={allMaterialMaterials} />
        <Field name="metal_color_id" component={SimpleSelect} label="Color *" parse={pI} options={allMaterialMaterials} />
        <Field name="qty" component={RenderField} label="Qty *" parse={pI} />
        <Field name="diamond_clarity_id" component={SimpleSelect} label="D Clarity *" parse={pI} options={allMaterialMaterials} />
        <Field name="diamond_color_id" component={SimpleSelect} label="D Color *" parse={pI} options={allMaterialMaterials} />
        <Field name="cs_clarity_id" component={SimpleSelect} label="CS Clarity *" parse={pI} options={allMaterialMaterials} />
        <Field name="cs_color_id" component={SimpleSelect} label="CS Color *" parse={pI} options={allMaterialMaterials} />
        <Field name="description" component={RenderField} label="description *" parse={pI} options={allMaterialMaterials} />
        <Field name="item_size" component={RenderField} label="Item Size *" parse={pI} options={allMaterialMaterials} />
        <Field name="priority_id" component={SimpleSelect} label="Priority *" parse={pI} options={allMaterialMaterials} />
        <Field name="department_id" component={SimpleSelect} label="Department *" parse={pI} options={allMaterialMaterials} />
        <Field name="sub_department_id" component={SimpleSelect} label="Sub Department *" parse={pI} options={allMaterialMaterials} />
        <Field name="net_weight" component={RenderField} label="Net Weight *" parse={pI} />
        <Field name="pure_weight" component={RenderField} label="Pure Weight *" parse={pI} />
        <Field name="diamond_pcs" component={RenderField} label="D PCs *" parse={pI} />
        <Field name="diamond_weight" component={RenderField} label="D Weight *" parse={pI} />
        <Field name="cs_pcs" component={RenderField} label="CS PCs *" parse={pI} />
        <Field name="cs_weight" component={RenderField} label="CS Weight *" parse={pI} />
        <Field name="gross_weight" component={RenderField} label="Gross Weight *" parse={pI} />
        <Button
          raised
          color="primary"
          type="submit"
          disabled={pristine || submitting}
          onClick={handleSubmit(this.props.onSubmit)}
        >
          Submit
        </Button>
        <Button raised type="button" disabled={pristine || submitting} onClick={reset}>
          Clear Values
        </Button>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  form: ownProps.formId,
  // other props...
});

export default compose(
  withMaterialsData,
  withGemClaritiesData,
  withColorsData,
  connect(mapStateToProps),
  reduxForm({
    // other redux-form options...
    validate,
    // asyncValidate
  })
)(withStyles(styles)(MaterialUiForm));
