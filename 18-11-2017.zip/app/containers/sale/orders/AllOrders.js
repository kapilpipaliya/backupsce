import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withOrdersData from '../../../queries/sale/orders/ordersQuery';

import ListOrders from './_ListOrders';
import HeadListOrders from './_HeadListOrders';

class AllOrders extends Component {
  componentDidMount() {
    this.props.orders.refetch(); // You can pass variables here.
  }

  render() {
    const { orders: { loading, error }, orders } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListOrders />
        <ListOrders data={orders} />
      </div>
    );
  }
}

export default withOrdersData(AllOrders);
