import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import OrderForm from './_OrderForm';
import withOrderForEditing from '../../../queries/sale/orders/orderForEditingQuery';
import withUpdateOrder from '../../../mutations/sale/orders/updateOrderMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditOrder extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { order, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing order</h1>
        <OrderForm action={this.props.updateOrder} initialValues={{ ...flatIDValue(order) }} submitName="Update Order" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  order: gql`
    fragment OrderForEditingFragment on SaleOrder {
      id
      position
      customer_id { id slug }
      taken_by_id { id slug }
      order_type_id { id slug }
      order_date
      delivery_date
      product_type_id { id slug }
      description
    }
  `,
};

export default withOrderForEditing(withUpdateOrder(EditOrder));
