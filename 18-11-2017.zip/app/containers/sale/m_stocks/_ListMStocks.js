import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';

// import M_StockPreview from './_M_StockPreview'

class ListMStocks extends Component {
  render() {
    const {
      allSaleMStocks,
      // mStocksCount,
      loading,
      error,
      // loadMoreMStocks,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allSaleMStocks}
        columns={[
          // @formatter:off
          // {accessor: 'M_StockPreview', Header: '-', Cell: props => (<M_StockPreview mStock={row} /> ) },
          { accessor: 'id', Header: 'ID' },
          { accessor: 'position', Header: 'Position' },
          { accessor: 'slug', Header: 'Code' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListMStocks;
