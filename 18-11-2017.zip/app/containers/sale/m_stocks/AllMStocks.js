import React, { Component } from 'react';
import withMStocksData from '../../../queries/sale/m_stocks/mStocksQuery';

import ListMStocks from './_ListMStocks';

class AllMStocks extends Component {
  componentDidMount() {
    this.props.mstocks.refetch(); // You can pass variables here.
  }

  render() {
    const { mstocks: { loading, error }, mstocks } = this.props;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <ListMStocks data={mstocks} />
      </div>
    );
  }
}

export default withMStocksData(AllMStocks);
