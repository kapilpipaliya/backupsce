import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withMStock from '../../../queries/sale/m_stocks/mStockQuery';

class MStock extends Component {
  render() {
    const { mStock, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="mStock">
        <p>MStock</p>
        <h2 className="mStock-heading">{mStock.slug}</h2>
        <div className="mStock-meta">
          <span className="mStock-author">
            Posted by: <em>{/* {mStock.author.name} */}</em>
          </span>
          <span className="mStock-date">
            {moment(new Date(mStock.created_at)).fromNow()}
          </span>
        </div>
        <div className="mStock-content">
          contents display here: ID : {mStock.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  mStock: gql`
    fragment MStockFragment on SaleMStock {
      id
      slug
      created_at
    }
  `,
};

export default withMStock(MStock);
