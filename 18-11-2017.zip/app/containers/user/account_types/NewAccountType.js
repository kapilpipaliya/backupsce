import React, { Component } from 'react';
import Button from 'material-ui/Button';
import AccountTypeForm from './_AccountTypeForm';
import withCreateAccountType from '../../../mutations/user/account_types/createAccountTypeMutation';

class NewAccountType extends Component {
  render() {
    return (
      <div>
        <h1>New AccountType</h1>
        <AccountTypeForm action={this.props.createAccountType} submitName="Create AccountType" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateAccountType(NewAccountType);
