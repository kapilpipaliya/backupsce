import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import Button from 'material-ui/Button';
import TextField from 'material-ui/TextField';

const styles = (theme) => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
  },
  menu: {
    width: 200,
  },
});

@withStyles(styles)
class SearchForm extends Component {
  static propTypes = {
    initialKeywords: PropTypes.string,
    loading: PropTypes.bool,
    history: PropTypes.object,
  };

  static defaultProps = {
    initialKeywords: '',
    loading: false,
  };

  componentWillMount() {
    this.setState({ keywords: this.props.initialKeywords });
  }
  onInputChange = (name) => (event) => {
    this.setState({
      [name]: event.target.value,
    });
  };
  onSearch = (event) => {
    event.preventDefault();
    const { keywords } = this.state;
    const pathName = keywords ? `/accounttypes/search/${keywords}` : '/';
    this.props.history.push(pathName);
  };
  render() {
    const { loading } = this.props;
    const { classes } = this.props;

    return (
      <div>
        <form onSubmit={this.onSearch}>
          <p>{this.state.keywords}</p>
          <TextField id="keywords" label="keywords" className={classes.textField} value={this.state.keywords} onChange={this.onInputChange(('keywords'))} margin="normal" />
          <Button raised type="submit" disabled={loading ? 'disabled' : false}>Search</Button>
        </form>
      </div>
    );
  }
}

export default withRouter(SearchForm);
