import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroyAccountType from '../../../mutations/user/account_types/destroyAccountTypeMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class AccountTypePreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroyAccountType(this.props.accountTypeRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { accountTypeRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(accountType.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/accounttypes/${accountTypeRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  accountType: gql`
    fragment AccountTypePreviewFragment on UserAccountType {
      id
      position
      slug
      account_type
      created_at
    }
  `,
};

export default withDestroyAccountType(withCurrentUser(AccountTypePreview));
