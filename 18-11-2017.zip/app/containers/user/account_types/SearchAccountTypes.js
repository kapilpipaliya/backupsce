import React, { Component } from 'react';
import ListAccountTypes from './_ListAccountTypes';
import HeadListAccountTypes from './_HeadListAccountTypes';
import withAccountTypesData from '../../../queries/user/account_types/accountTypesQuery';

class SearchAccountTypes extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.accountTypes = [];
    }
  }

  render() {
    const { accountTypes, accountTypesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreAccountTypes,
      firstAccountTypesLoading,
    } = this.props;

    return (
      <div className="search-accountTypes">
        <h1>Searching accountTypes</h1>
        <HeadListAccountTypes
          initialKeywords={keywords}
          loading={firstAccountTypesLoading}
        />

        {!firstAccountTypesLoading && accountTypes && accountTypes.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListAccountTypes
            accountTypes={accountTypes}
            accountTypesCount={accountTypesCount}
            loading={loading}
            loadMoreAccountTypes={loadMoreAccountTypes}
          />
        )}
      </div>
    );
  }
}

export default withAccountTypesData(SearchAccountTypes);
