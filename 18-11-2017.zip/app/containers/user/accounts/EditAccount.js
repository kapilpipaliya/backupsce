import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import AccountForm from './_AccountForm';
import withAccountForEditing from '../../../queries/user/accounts/accountForEditingQuery';
import withUpdateAccount from '../../../mutations/user/accounts/updateAccountMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditAccount extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { account, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing account</h1>
        <AccountForm action={this.props.updateAccount} initialValues={{ ...flatIDValue(account) }} submitName="Update Account" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  account: gql`
    fragment AccountForEditingFragment on UserAccount {
      id
      account_type_id { id slug }
      position
      slug
      join_date
      company_name
      first_name
      last_name
      phone
      mobile
      salary
      role_id { id slug }
      email
      encrypted_password
      reset_password_token
      reset_password_sent_at
      remember_created_at
      sign_in_count
      current_sign_in_at
      last_sign_in_at
      current_sign_in_ip
      last_sign_in_ip
    }
  `,
};

export default withAccountForEditing(withUpdateAccount(EditAccount));
