import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroyAccount from '../../../mutations/user/accounts/destroyAccountMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class AccountPreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroyAccount(this.props.accountRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { accountRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(account.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/accounts/${accountRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  account: gql`
    fragment AccountPreviewFragment on UserAccount {
      id
      account_type_id { id slug }
      position
      slug
      join_date
      company_name
      first_name
      last_name
      phone
      mobile
      salary
      role_id { id slug }
      email
      encrypted_password
      reset_password_token
      reset_password_sent_at
      remember_created_at
      sign_in_count
      current_sign_in_at
      last_sign_in_at
      current_sign_in_ip
      last_sign_in_ip
      created_at
    }
  `,
};

export default withDestroyAccount(withCurrentUser(AccountPreview));
