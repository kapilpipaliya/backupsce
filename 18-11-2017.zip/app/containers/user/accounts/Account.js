import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withAccount from '../../../queries/user/accounts/accountQuery';

class Account extends Component {
  render() {
    const { account, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="account">
        <p>Account</p>
        <h2 className="account-heading">{account.slug}</h2>
        <div className="account-meta">
          <span className="account-author">
            Posted by: <em>{/* {account.author.name} */}</em>
          </span>
          <span className="account-date">
            {moment(new Date(account.created_at)).fromNow()}
          </span>
        </div>
        <div className="account-content">
          contents display here: ID : {account.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  account: gql`
    fragment AccountFragment on UserAccount {
      id
      account_type_id { id slug }
      position
      slug
      join_date
      company_name
      first_name
      last_name
      phone
      mobile
      salary
      role_id { id slug }
      email
      encrypted_password
      reset_password_token
      reset_password_sent_at
      remember_created_at
      sign_in_count
      current_sign_in_at
      last_sign_in_at
      current_sign_in_ip
      last_sign_in_ip
      created_at
    }
  `,
};

export default withAccount(Account);
