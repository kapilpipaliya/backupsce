import React, { Component } from 'react';
import ListAccounts from './_ListAccounts';
import HeadListAccounts from './_HeadListAccounts';
import withAccountsData from '../../../queries/user/accounts/accountsQuery';

class SearchAccounts extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.accounts = [];
    }
  }

  render() {
    const { accounts, accountsCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreAccounts,
      firstAccountsLoading,
    } = this.props;

    return (
      <div className="search-accounts">
        <h1>Searching accounts</h1>
        <HeadListAccounts
          initialKeywords={keywords}
          loading={firstAccountsLoading}
        />

        {!firstAccountsLoading && accounts && accounts.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListAccounts
            accounts={accounts}
            accountsCount={accountsCount}
            loading={loading}
            loadMoreAccounts={loadMoreAccounts}
          />
        )}
      </div>
    );
  }
}

export default withAccountsData(SearchAccounts);
