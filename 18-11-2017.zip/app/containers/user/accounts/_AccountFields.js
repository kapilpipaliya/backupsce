import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';
import S from '../../../components/form/SimpleSelect';
import RDate from '../../../components/shared/CustomDatePicker/index';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI } from '../../../utils/libs';

export class AccountTypeId extends React.Component {
  render() {
    return (
      <Field name='account_type_id' label='Account type' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class Slug extends React.Component {
  render() {
    return (
      <Field name='slug' label='Code' component={F} {...this.props} />
    );
  }
}

export class JoinDate extends React.Component {
  render() {
    return (
      <Field name='join_date' label='Join date' type='date' component={RDate} {...this.props} />
    );
  }
}

export class CompanyName extends React.Component {
  render() {
    return (
      <Field name='company_name' label='Company name' component={F} {...this.props} />
    );
  }
}

export class FirstName extends React.Component {
  render() {
    return (
      <Field name='first_name' label='First name' component={F} {...this.props} />
    );
  }
}

export class LastName extends React.Component {
  render() {
    return (
      <Field name='last_name' label='Last name' component={F} {...this.props} />
    );
  }
}

export class Phone extends React.Component {
  render() {
    return (
      <Field name='phone' label='Phone' component={F} {...this.props} />
    );
  }
}

export class Mobile extends React.Component {
  render() {
    return (
      <Field name='mobile' label='Mobile' component={F} {...this.props} />
    );
  }
}

export class Salary extends React.Component {
  render() {
    return (
      <Field name='salary' label='Salary' component={F} parse={pI} placeholder='Salary' type='number' {...this.props} />
    );
  }
}

export class RoleId extends React.Component {
  render() {
    return (
      <Field name='role_id' label='Role' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Email extends React.Component {
  render() {
    return (
      <Field name='email' label='Email' component={F} {...this.props} />
    );
  }
}

export class EncryptedPassword extends React.Component {
  render() {
    return (
      <Field name='encrypted_password' label='Encrypted password' component={F} {...this.props} />
    );
  }
}

export class ResetPasswordToken extends React.Component {
  render() {
    return (
      <Field name='reset_password_token' label='Reset password token' component={F} {...this.props} />
    );
  }
}

export class ResetPasswordSentAt extends React.Component {
  render() {
    return (
      <Field name='reset_password_sent_at' label='Reset password sent at' type='datetime' component={RDate} {...this.props} />
    );
  }
}

export class RememberCreatedAt extends React.Component {
  render() {
    return (
      <Field name='remember_created_at' label='Remember created at' type='datetime' component={RDate} {...this.props} />
    );
  }
}

export class SignInCount extends React.Component {
  render() {
    return (
      <Field name='sign_in_count' label='Sign in count' component={F} parse={pI} placeholder='Sign in count' type='number' {...this.props} />
    );
  }
}

export class CurrentSignInAt extends React.Component {
  render() {
    return (
      <Field name='current_sign_in_at' label='Current sign in at' type='datetime' component={RDate} {...this.props} />
    );
  }
}

export class LastSignInAt extends React.Component {
  render() {
    return (
      <Field name='last_sign_in_at' label='Last sign in at' type='datetime' component={RDate} {...this.props} />
    );
  }
}

export class CurrentSignInIp extends React.Component {
  render() {
    return (
      <Field name='current_sign_in_ip' label='Current sign in ip' component={F} {...this.props} />
    );
  }
}

export class LastSignInIp extends React.Component {
  render() {
    return (
      <Field name='last_sign_in_ip' label='Last sign in ip' component={F} {...this.props} />
    );
  }
}

// import { AccountTypeId, Position, Slug, JoinDate, CompanyName, FirstName, LastName, Phone, Mobile, Salary, RoleId, Email, EncryptedPassword, ResetPasswordToken, ResetPasswordSentAt, RememberCreatedAt, SignInCount, CurrentSignInAt, LastSignInAt, CurrentSignInIp, LastSignInIp } from './_AccountFields'; // eslint-disable-line no-unused-vars
