import React, { Component } from 'react';

import { Field, reduxForm, SubmissionError } from 'redux-form/immutable';
import { withApollo } from 'react-apollo';
import Button from 'material-ui/Button';
import RenderField from '../../../components/form/RenderField';
import { AccountTypeId, Position, Slug, JoinDate, CompanyName, FirstName, LastName, Phone, Mobile, Salary, RoleId, Email, EncryptedPassword, ResetPasswordToken, ResetPasswordSentAt, RememberCreatedAt, SignInCount, CurrentSignInAt, LastSignInAt, CurrentSignInIp, LastSignInIp } from './_AccountFields'; // eslint-disable-line no-unused-vars
import { fexecuteAT, fexecuteAR } from '../../../utils/Fetch';
import HOCFetch from '../../HOC/Fetch';
@withApollo
@HOCFetch
class AccountForm extends Component {
   state = { loading: false };

  // Fetch Internal Options
   componentDidMount() {
     this.props.fetch(fexecuteAT, 'account_types'); // Fetch Account Types.
     this.props.fetch(fexecuteAR, 'roles'); // Fetch User Roles.
   }

  submitForm = (values) => {
    this.setState({ loading: true });
    return this.props.action(values).then((errors) => {
      if (errors) {
        this.setState({ loading: false });
        throw new SubmissionError(errors);
      }
    });
  }

  render() {
    const {
      handleSubmit, pristine, reset, invalid, submitting, submitName,
    } = this.props;
    const { loading } = this.state;

    return (
      <form onSubmit={handleSubmit(this.submitForm)}>
        <fieldset>
          {/* <legend></legend> */}
          <AccountTypeId options={this.props.account_types} oField="account_type" />
          <Position label="Position(optional)" />
          <Slug />
          <br />
          <span>Join Date: </span>
          <JoinDate /> <br />
          <CompanyName />
          <FirstName />
          <LastName />
          <Email />
          <Field name="password" label="Password" component={RenderField} type="password" />
          <Phone />
          <Mobile />
          <Salary />
          <RoleId options={this.props.roles} oField="role" />

          <Button raised type="submit" disabled={loading || invalid || submitting}>{submitName}</Button>
          <Button raised disabled={loading || pristine || submitting} onClick={reset} style={{ margin: '5px' }}>Clear Values</Button>
        </fieldset>
      </form>
    );
  }
}

function validate(values) {
  const errors = {};
  if (!values.get('slug')) {
    errors.slug = "can't be blank";
  }
  if (!values.get('company_name')) {
    errors.company_name = "can't be blank";
  }
  return errors;
}

export default reduxForm({
  form: 'AccountForm',
  validate,
})(AccountForm);
