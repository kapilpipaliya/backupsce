import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroyCompany from '../../../mutations/user/companies/destroyCompanyMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class CompanyPreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroyCompany(this.props.companyRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { companyRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(company.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/companies/${companyRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  company: gql`
    fragment CompanyPreviewFragment on UserCompany {
      id
      contact_id { id slug }
      position
      slug
      company
      name
      email
      address
      gst_no
      created_at
    }
  `,
};

export default withDestroyCompany(withCurrentUser(CompanyPreview));
