import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import CompanyForm from './_CompanyForm';
import withCompanyForEditing from '../../../queries/user/companies/companyForEditingQuery';
import withUpdateCompany from '../../../mutations/user/companies/updateCompanyMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditCompany extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { company, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing company</h1>
        <CompanyForm action={this.props.updateCompany} initialValues={{ ...flatIDValue(company) }} submitName="Update Company" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  company: gql`
    fragment CompanyForEditingFragment on UserCompany {
      id
      contact_id { id slug }
      position
      slug
      company
      name
      email
      address
      gst_no
    }
  `,
};

export default withCompanyForEditing(withUpdateCompany(EditCompany));
