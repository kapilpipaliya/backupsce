import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withCompaniesData from '../../../queries/user/companies/companiesQuery';

import ListCompanies from './_ListCompanies';
import HeadListCompanies from './_HeadListCompanies';

class AllCompanies extends Component {
  componentDidMount() {
    this.props.companies.refetch(); // You can pass variables here.
  }

  render() {
    const { companies: { loading, error }, companies } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListCompanies />
        <ListCompanies data={companies} />
      </div>
    );
  }
}

export default withCompaniesData(AllCompanies);
