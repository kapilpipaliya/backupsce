import React, { Component } from 'react';
import Button from 'material-ui/Button';
import CountryForm from './_CountryForm';
import withCreateCountry from '../../../mutations/user/countries/createCountryMutation';

class NewCountry extends Component {
  render() {
    return (
      <div>
        <h1>New Country</h1>
        <CountryForm action={this.props.createCountry} submitName="Create Country" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateCountry(NewCountry);
