import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withCountry from '../../../queries/user/countries/countryQuery';

class Country extends Component {
  render() {
    const { country, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="country">
        <p>Country</p>
        <h2 className="country-heading">{country.slug}</h2>
        <div className="country-meta">
          <span className="country-author">
            Posted by: <em>{/* {country.author.name} */}</em>
          </span>
          <span className="country-date">
            {moment(new Date(country.created_at)).fromNow()}
          </span>
        </div>
        <div className="country-content">
          contents display here: ID : {country.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  country: gql`
    fragment CountryFragment on UserCountry {
      id
      position
      slug
      country
      created_at
    }
  `,
};

export default withCountry(Country);
