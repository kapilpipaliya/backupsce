import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroyRole from '../../../mutations/user/roles/destroyRoleMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class RolePreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroyRole(this.props.roleRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { roleRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(role.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/roles/${roleRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  role: gql`
    fragment RolePreviewFragment on UserRole {
      id
      position
      slug
      role
      created_at
    }
  `,
};

export default withDestroyRole(withCurrentUser(RolePreview));
