import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import RolePreview from './_RolePreview';

class ListRoles extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allUserRoles,
      // rolesCount,
      loading,
      error,
      // loadMoreRoles,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allUserRoles}
        columns={[
          // @formatter:off
          { accessor: 'RolePreview', Header: '-', Cell: (props) => <RolePreview roleRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'slug', Header: 'Code' },
          { accessor: 'role', Header: 'Role' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListRoles;
