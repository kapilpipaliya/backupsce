import AllRoles from './AllRoles';
import SearchRoles from './SearchRoles';
import Role from './Role';
import NewRole from './NewRole';
import EditRole from './EditRole';

export {
  AllRoles,
  SearchRoles,
  Role,
  NewRole,
  EditRole,
};
