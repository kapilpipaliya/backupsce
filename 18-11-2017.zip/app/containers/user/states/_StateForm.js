import React, { Component } from 'react';

import { reduxForm, SubmissionError } from 'redux-form/immutable';
import { withApollo } from 'react-apollo';
import Button from 'material-ui/Button';

import { fexecuteAC } from '../../../utils/Fetch';
import { Position, CountryId, Slug, State } from './_StateFields'; // eslint-disable-line no-unused-vars

import HOCFetch from '../../HOC/Fetch';
@withApollo
@HOCFetch
class StateForm extends Component {
   state = { loading: false };

  // Fetch Internal Options
   componentDidMount() {
     this.props.fetch(fexecuteAC, 'countries'); // Fetch countries.
   }

  submitForm = (values) => {
    this.setState({ loading: true });
    return this.props.action(values).then((errors) => {
      if (errors) {
        this.setState({ loading: false });
        throw new SubmissionError(errors);
      }
    });
  }

  render() {
    const {
      handleSubmit, pristine, reset, invalid, submitting, submitName,
    } = this.props;
    const { loading } = this.state;

    return (
      <form onSubmit={handleSubmit(this.submitForm)}>
        <Position label="Position(optional)" />
        <Slug />
        <CountryId options={this.props.countries} />
        <State />
        <Button
          raised
          type="submit"
          disabled={loading || invalid || submitting}
        >
          {submitName}
        </Button>
        <Button
          raised
          disabled={loading || pristine || submitting}
          onClick={reset}
          style={{ margin: '5px' }}
        >
          Clear Values
        </Button>
      </form>
    );
  }
}

function validate(values) {
  const errors = {};
  if (!values.get('slug')) {
    errors.slug = "can't be blank";
  }
  if (!values.get('state')) {
    errors.state = "can't be blank";
  }
  if (!values.get('country_id')) {
    errors.country_id = "can't be blank";
  }
  return errors;
}

export default reduxForm({
  form: 'StateForm',
  validate,
})(StateForm);
