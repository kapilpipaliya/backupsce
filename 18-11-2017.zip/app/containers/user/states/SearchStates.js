import React, { Component } from 'react';
import ListStates from './_ListStates';
import HeadListStates from './_HeadListStates';
import withStatesData from '../../../queries/user/states/statesQuery';

class SearchStates extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.states = [];
    }
  }

  render() {
    const { states, statesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreStates,
      firstStatesLoading,
    } = this.props;

    return (
      <div className="search-states">
        <h1>Searching states</h1>
        <HeadListStates
          initialKeywords={keywords}
          loading={firstStatesLoading}
        />

        {!firstStatesLoading && states && states.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListStates
            states={states}
            statesCount={statesCount}
            loading={loading}
            loadMoreStates={loadMoreStates}
          />
        )}
      </div>
    );
  }
}

export default withStatesData(SearchStates);
