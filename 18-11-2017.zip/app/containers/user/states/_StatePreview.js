import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroyState from '../../../mutations/user/states/destroyStateMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class StatePreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroyState(this.props.stateRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { stateRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(state.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/states/${stateRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  state: gql`
    fragment StatePreviewFragment on UserState {
      id
      position
      country_id { id slug }
      slug
      state
      created_at
    }
  `,
};

export default withDestroyState(withCurrentUser(StatePreview));
