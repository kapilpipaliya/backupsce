import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withState from '../../../queries/user/states/stateQuery';

class State extends Component {
  render() {
    const { state, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="state">
        <p>State</p>
        <h2 className="state-heading">{state.slug}</h2>
        <div className="state-meta">
          <span className="state-author">
            Posted by: <em>{/* {state.author.name} */}</em>
          </span>
          <span className="state-date">
            {moment(new Date(state.created_at)).fromNow()}
          </span>
        </div>
        <div className="state-content">
          contents display here: ID : {state.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  state: gql`
    fragment StateFragment on UserState {
      id
      position
      country_id { id slug }
      slug
      state
      created_at
    }
  `,
};

export default withState(State);
