import React, { Component } from 'react';
import Button from 'material-ui/Button';
import StateForm from './_StateForm';
import withCreateState from '../../../mutations/user/states/createStateMutation';

class NewState extends Component {
  render() {
    return (
      <div>
        <h1>New State</h1>
        <StateForm action={this.props.createState} submitName="Create State" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateState(NewState);
