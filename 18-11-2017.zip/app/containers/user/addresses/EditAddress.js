import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import AddressForm from './_AddressForm';
import withAddressForEditing from '../../../queries/user/addresses/addressForEditingQuery';
import withUpdateAddress from '../../../mutations/user/addresses/updateAddressMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditAddress extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { address, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing address</h1>
        <AddressForm action={this.props.updateAddress} initialValues={{ ...flatIDValue(address) }} submitName="Update Address" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  address: gql`
    fragment AddressForEditingFragment on UserAddress {
      id
      account_id { id slug }
      position
      firstname
      lastname
      address1
      address2
      city
      zipcode
      state_id { id slug }
      country_id { id slug }
      phone
      alternative_phone
      company
    }
  `,
};

export default withAddressForEditing(withUpdateAddress(EditAddress));
