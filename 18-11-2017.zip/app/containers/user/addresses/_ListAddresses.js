import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import AddressPreview from './_AddressPreview';

class ListAddresses extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allUserAddresses,
      // addressesCount,
      loading,
      error,
      // loadMoreAddresses,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allUserAddresses}
        columns={[
          // @formatter:off
          { accessor: 'AddressPreview', Header: '-', Cell: (props) => <AddressPreview addressRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { Header: 'Account', Cell: (props) => (props.original.account_id ? props.original.account_id.slug : undefined) },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'firstname', Header: 'Firstname' },
          { accessor: 'lastname', Header: 'Lastname' },
          { accessor: 'address1', Header: 'Address1' },
          { accessor: 'address2', Header: 'Address2' },
          { accessor: 'city', Header: 'City' },
          { accessor: 'zipcode', Header: 'Zipcode' },
          { Header: 'State', Cell: (props) => (props.original.state_id ? props.original.state_id.slug : undefined) },
          { Header: 'Country', Cell: (props) => (props.original.country_id ? props.original.country_id.slug : undefined) },
          { accessor: 'phone', Header: 'Phone' },
          { accessor: 'alternative_phone', Header: 'Alternative phone' },
          { accessor: 'company', Header: 'Company' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListAddresses;
