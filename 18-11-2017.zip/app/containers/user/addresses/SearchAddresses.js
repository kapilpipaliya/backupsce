import React, { Component } from 'react';
import ListAddresses from './_ListAddresses';
import HeadListAddresses from './_HeadListAddresses';
import withAddressesData from '../../../queries/user/addresses/addressesQuery';

class SearchAddresses extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.addresses = [];
    }
  }

  render() {
    const { addresses, addressesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreAddresses,
      firstAddressesLoading,
    } = this.props;

    return (
      <div className="search-addresses">
        <h1>Searching addresses</h1>
        <HeadListAddresses
          initialKeywords={keywords}
          loading={firstAddressesLoading}
        />

        {!firstAddressesLoading && addresses && addresses.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListAddresses
            addresses={addresses}
            addressesCount={addressesCount}
            loading={loading}
            loadMoreAddresses={loadMoreAddresses}
          />
        )}
      </div>
    );
  }
}

export default withAddressesData(SearchAddresses);
