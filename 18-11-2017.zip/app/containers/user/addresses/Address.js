import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withAddress from '../../../queries/user/addresses/addressQuery';

class Address extends Component {
  render() {
    const { address, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="address">
        <p>Address</p>
        <h2 className="address-heading">{address.slug}</h2>
        <div className="address-meta">
          <span className="address-author">
            Posted by: <em>{/* {address.author.name} */}</em>
          </span>
          <span className="address-date">
            {moment(new Date(address.created_at)).fromNow()}
          </span>
        </div>
        <div className="address-content">
          contents display here: ID : {address.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  address: gql`
    fragment AddressFragment on UserAddress {
      id
      account_id { id slug }
      position
      firstname
      lastname
      address1
      address2
      city
      zipcode
      state_id { id slug }
      country_id { id slug }
      phone
      alternative_phone
      company
      created_at
    }
  `,
};

export default withAddress(Address);
