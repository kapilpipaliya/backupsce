import React, { Component } from 'react';

import { reduxForm, SubmissionError } from 'redux-form/immutable';
import { withApollo } from 'react-apollo';
import Button from 'material-ui/Button';
import { AccountId, Position, Firstname, Lastname, Address1, Address2, City, Zipcode, StateId, CountryId, Phone, AlternativePhone, Company } from './_AddressFields'; // eslint-disable-line no-unused-vars

import HOCFetch from '../../HOC/Fetch';
import { fexecuteA, fexecuteAC, fexecuteAS } from '../../../utils/Fetch';
@withApollo
@HOCFetch
class AddressForm extends Component {
   state = { loading: false };

  // Fetch Internal Options
   componentDidMount() {
     this.props.fetch(fexecuteA, 'accounts'); // Fetch Accounts.
     this.props.fetch(fexecuteAC, 'countries'); // Fetch Countries.
   }
  submitForm = (values) => {
    this.setState({ loading: true });
    return this.props.action(values).then((errors) => {
      if (errors) {
        this.setState({ loading: false });
        throw new SubmissionError(errors);
      }
    });
  }

  render() {
    const {
      handleSubmit, pristine, reset, invalid, submitting, submitName,
    } = this.props;
    const { loading } = this.state;

    return (
      <form onSubmit={handleSubmit(this.submitForm)}>
        <fieldset>
          {/* <legend></legend> */}
          <AccountId options={this.props.accounts} />
          <Position label="Position(optional)" />
          <Company />
          <Firstname />
          <Lastname />
          <Address1 />
          <Address2 />
          <City />
          <Zipcode />
          <Phone />
          <AlternativePhone />
          <CountryId
            options={this.props.countries}
            onChange2={(value) => {
              this.props.fetch(fexecuteAS, 'states', value);
            }}
          />
          <StateId options={this.props.states} />
          <Button raised type="submit" disabled={loading || invalid || submitting}>{submitName}</Button>
          <Button raised disabled={loading || pristine || submitting} onClick={reset} style={{ margin: '5px' }}>Clear Values</Button>
        </fieldset>
      </form>
    );
  }
}

function validate(values) {
  const errors = {};
  if (!values.get('firstname')) {
    errors.firstname = "can't be blank";
  }
  if (!values.get('account_id')) {
    errors.account_id = "can't be blank";
  }
  return errors;
}

export default reduxForm({
  form: 'AddressForm',
  validate,
})(AddressForm);
