import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import TaxTypePreview from './_TaxTypePreview';

class ListTaxTypes extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allUserTaxTypes,
      // taxTypesCount,
      loading,
      error,
      // loadMoreTaxTypes,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allUserTaxTypes}
        columns={[
          // @formatter:off
          { accessor: 'TaxTypePreview', Header: '-', Cell: (props) => <TaxTypePreview taxTypeRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'slug', Header: 'Code' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListTaxTypes;
