import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withTaxTypesData from '../../../queries/user/tax_types/taxTypesQuery';

import ListTaxTypes from './_ListTaxTypes';
import HeadListTaxTypes from './_HeadListTaxTypes';

class AllTaxTypes extends Component {
  componentDidMount() {
    this.props.taxtypes.refetch(); // You can pass variables here.
  }

  render() {
    const { taxtypes: { loading, error }, taxtypes } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListTaxTypes />
        <ListTaxTypes data={taxtypes} />
      </div>
    );
  }
}

export default withTaxTypesData(AllTaxTypes);
