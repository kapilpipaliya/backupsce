import React, { Component } from 'react';
import Button from 'material-ui/Button';
import TaxTypeForm from './_TaxTypeForm';
import withCreateTaxType from '../../../mutations/user/tax_types/createTaxTypeMutation';

class NewTaxType extends Component {
  render() {
    return (
      <div>
        <h1>New TaxType</h1>
        <TaxTypeForm action={this.props.createTaxType} submitName="Create TaxType" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateTaxType(NewTaxType);
