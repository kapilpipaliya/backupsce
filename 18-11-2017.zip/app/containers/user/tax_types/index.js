import AllTaxTypes from './AllTaxTypes';
import SearchTaxTypes from './SearchTaxTypes';
import TaxType from './TaxType';
import NewTaxType from './NewTaxType';
import EditTaxType from './EditTaxType';

export {
  AllTaxTypes,
  SearchTaxTypes,
  TaxType,
  NewTaxType,
  EditTaxType,
};
