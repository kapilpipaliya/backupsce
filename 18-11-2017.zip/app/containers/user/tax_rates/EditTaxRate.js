import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import TaxRateForm from './_TaxRateForm';
import withTaxRateForEditing from '../../../queries/user/tax_rates/taxRateForEditingQuery';
import withUpdateTaxRate from '../../../mutations/user/tax_rates/updateTaxRateMutation';
import Loading from '../../../components/Loading';

class EditTaxRate extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { taxRate, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing taxRate</h1>
        <TaxRateForm action={this.props.updateTaxRate} initialValues={{ ...taxRate }} submitName="Update TaxRate" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  taxRate: gql`
    fragment TaxRateForEditingFragment on UserTaxRate {
      id
      user_tax_type { id slug }
      position
      slug
      rate
    }
  `,
};

export default withTaxRateForEditing(withUpdateTaxRate(EditTaxRate));
