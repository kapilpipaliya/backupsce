import AllTaxRates from './AllTaxRates';
import SearchTaxRates from './SearchTaxRates';
import TaxRate from './TaxRate';
import NewTaxRate from './NewTaxRate';
import EditTaxRate from './EditTaxRate';

export {
  AllTaxRates,
  SearchTaxRates,
  TaxRate,
  NewTaxRate,
  EditTaxRate,
};
