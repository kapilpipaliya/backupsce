import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import TaxRatePreview from './_TaxRatePreview';

class ListTaxRates extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allUserTaxRates,
      // taxRatesCount,
      loading,
      error,
      // loadMoreTaxRates,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allUserTaxRates}
        columns={[
          // @formatter:off
          { accessor: 'TaxRatePreview', Header: '-', Cell: (props) => <TaxRatePreview taxRate={props.original} data={this.props.data} variables={this.state.variables} /> },
          { Header: 'User tax type', Cell: (props) => (props.original.user_tax_type ? props.original.user_tax_type.slug : undefined) },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'slug', Header: 'Code' },
          { accessor: 'rate', Header: 'Rate' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListTaxRates;
