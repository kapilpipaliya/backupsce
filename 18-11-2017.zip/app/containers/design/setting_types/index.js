import AllSettingTypes from './AllSettingTypes';
import SearchSettingTypes from './SearchSettingTypes';
import SettingType from './SettingType';
import NewSettingType from './NewSettingType';
import EditSettingType from './EditSettingType';

export {
  AllSettingTypes,
  SearchSettingTypes,
  SettingType,
  NewSettingType,
  EditSettingType,
};
