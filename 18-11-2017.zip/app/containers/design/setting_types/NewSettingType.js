import React, { Component } from 'react';
import Button from 'material-ui/Button';
import SettingTypeForm from './_SettingTypeForm';
import withCreateSettingType from '../../../mutations/design/setting_types/createSettingTypeMutation';

class NewSettingType extends Component {
  render() {
    return (
      <div>
        <h1>New SettingType</h1>
        <SettingTypeForm action={this.props.createSettingType} submitName="Create SettingType" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateSettingType(NewSettingType);
