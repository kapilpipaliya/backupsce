import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withSettingType from '../../../queries/design/setting_types/settingTypeQuery';

class SettingType extends Component {
  render() {
    const { settingType, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="settingType">
        <p>SettingType</p>
        <h2 className="settingType-heading">{settingType.slug}</h2>
        <div className="settingType-meta">
          <span className="settingType-author">
            Posted by: <em>{/* {settingType.author.name} */}</em>
          </span>
          <span className="settingType-date">
            {moment(new Date(settingType.created_at)).fromNow()}
          </span>
        </div>
        <div className="settingType-content">
          contents display here: ID : {settingType.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  settingType: gql`
    fragment SettingTypeFragment on DesignSettingType {
      id
      position
      slug
      setting_type
      isdefault
      created_at
    }
  `,
};

export default withSettingType(SettingType);
