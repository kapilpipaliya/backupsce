import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroySettingType from '../../../mutations/design/setting_types/destroySettingTypeMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class SettingTypePreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroySettingType(this.props.settingTypeRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { settingTypeRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(settingType.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/settingtypes/${settingTypeRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  settingType: gql`
    fragment SettingTypePreviewFragment on DesignSettingType {
      id
      position
      slug
      setting_type
      isdefault
      created_at
    }
  `,
};

export default withDestroySettingType(withCurrentUser(SettingTypePreview));
