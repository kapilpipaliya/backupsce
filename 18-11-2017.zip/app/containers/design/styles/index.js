import AllStyles from './AllStyles';
import SearchStyles from './SearchStyles';
import Style from './Style';
import NewStyle from './NewStyle';
import EditStyle from './EditStyle';

export {
  AllStyles,
  SearchStyles,
  Style,
  NewStyle,
  EditStyle,
};
