import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withStyle from '../../../queries/design/styles/styleQuery';

class Style extends Component {
  render() {
    const { style, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="style">
        <p>Style</p>
        <h2 className="style-heading">{style.slug}</h2>
        <div className="style-meta">
          <span className="style-author">
            Posted by: <em>{/* {style.author.name} */}</em>
          </span>
          <span className="style-date">
            {moment(new Date(style.created_at)).fromNow()}
          </span>
        </div>
        <div className="style-content">
          contents display here: ID : {style.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  style: gql`
    fragment StyleFragment on DesignStyle {
      id
      position
      slug
      collection_id { id slug }
      making_type_id { id slug }
      setting_type_id { id slug }
      designer_id { id slug }
      material_id { id slug }
      metal_purity_id { id slug }
      color_id { id slug }
      net_weight
      purity_per
      pure_weight
      volume
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
      description
      active
      created_at
    }
  `,
};

export default withStyle(Style);
