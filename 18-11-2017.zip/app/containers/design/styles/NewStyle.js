import React, { Component } from 'react';
import Button from 'material-ui/Button';
import StyleForm from './_StyleForm';
import withCreateStyle from '../../../mutations/design/styles/createStyleMutation';

class NewStyle extends Component {
  render() {
    return (
      <div>
        <h1>New Style</h1>
        <StyleForm action={this.props.createStyle} submitName="Create Style" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateStyle(NewStyle);
