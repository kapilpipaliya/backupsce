import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import StyleForm from './_StyleForm';
import withStyleForEditing from '../../../queries/design/styles/styleForEditingQuery';
import withUpdateStyle from '../../../mutations/design/styles/updateStyleMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditStyle extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { style, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    const d = flatIDValue(style);
    d.diamonds = d.diamonds.map(flatIDValue);
    return (
      <div>
        <h1>Editing style</h1>
        <StyleForm action={this.props.updateStyle} initialValues={{ ...d }} submitName="Update Style" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  style: gql`
    fragment StyleForEditingFragment on DesignStyle {
      id
      position
      slug
      collection_id { id slug }
      making_type_id { id slug }
      setting_type_id { id slug }
      designer_id { id slug }
      material_id { id slug }
      metal_purity_id { id slug }
      color_id { id slug }
      net_weight
      purity_per
      pure_weight
      volume
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
      description
      active
      diamonds {
        id
        material_id { id }
        gem_size_id { id }
        gem_shape_id { id }
        gem_clarity_id { id }
        color_id { id }
        pcs
        pointer
        weight
      }
    }
  `,
};

export default withStyleForEditing(withUpdateStyle(EditStyle));
