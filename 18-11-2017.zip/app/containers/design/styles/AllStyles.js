import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withStylesData from '../../../queries/design/styles/stylesQuery';

import ListStyles from './_ListStyles';
import HeadListStyles from './_HeadListStyles';

class AllStyles extends Component {
  componentDidMount() {
    this.props.styles.refetch(); // You can pass variables here.
  }

  render() {
    const { styles: { loading, error }, styles } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListStyles />
        <ListStyles data={styles} />
      </div>
    );
  }
}

export default withStylesData(AllStyles);
