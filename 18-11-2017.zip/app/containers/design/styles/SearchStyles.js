import React, { Component } from 'react';
import ListStyles from './_ListStyles';
import HeadListStyles from './_HeadListStyles';
import withStylesData from '../../../queries/design/styles/stylesQuery';

class SearchStyles extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.styles = [];
    }
  }

  render() {
    const { styles, stylesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreStyles,
      firstStylesLoading,
    } = this.props;

    return (
      <div className="search-styles">
        <h1>Searching styles</h1>
        <HeadListStyles
          initialKeywords={keywords}
          loading={firstStylesLoading}
        />

        {!firstStylesLoading && styles && styles.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListStyles
            styles={styles}
            stylesCount={stylesCount}
            loading={loading}
            loadMoreStyles={loadMoreStyles}
          />
        )}
      </div>
    );
  }
}

export default withStylesData(SearchStyles);
