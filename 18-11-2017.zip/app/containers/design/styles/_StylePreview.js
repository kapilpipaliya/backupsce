import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroyStyle from '../../../mutations/design/styles/destroyStyleMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class StylePreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroyStyle(this.props.styleRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { styleRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(style.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/styles/${styleRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  style: gql`
    fragment StylePreviewFragment on DesignStyle {
      id
      position
      slug
      collection_id { id slug }
      making_type_id { id slug }
      setting_type_id { id slug }
      designer_id { id slug }
      material_id { id slug }
      metal_purity_id { id slug }
      color_id { id slug }
      net_weight
      purity_per
      pure_weight
      volume
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
      description
      active
      created_at
    }
  `,
};

export default withDestroyStyle(withCurrentUser(StylePreview));
