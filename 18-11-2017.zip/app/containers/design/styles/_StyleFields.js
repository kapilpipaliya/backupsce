import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';
import S from '../../../components/form/SimpleSelect';
import Sw from '../../../components/form/RenderSwitch';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI, parsefloat as pF } from '../../../utils/libs';

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class Slug extends React.Component {
  render() {
    return (
      <Field name='slug' label='Code' component={F} {...this.props} />
    );
  }
}

export class CollectionId extends React.Component {
  render() {
    return (
      <Field name='collection_id' label='Collection' component={S} parse={pI} {...this.props} />
    );
  }
}

export class MakingTypeId extends React.Component {
  render() {
    return (
      <Field name='making_type_id' label='Making type' component={S} parse={pI} {...this.props} />
    );
  }
}

export class SettingTypeId extends React.Component {
  render() {
    return (
      <Field name='setting_type_id' label='Setting type' component={S} parse={pI} {...this.props} />
    );
  }
}

export class DesignerId extends React.Component {
  render() {
    return (
      <Field name='designer_id' label='Designer' component={S} parse={pI} {...this.props} />
    );
  }
}

export class MaterialId extends React.Component {
  render() {
    return (
      <Field name='material_id' label='Material' component={S} parse={pI} {...this.props} />
    );
  }
}

export class MetalPurityId extends React.Component {
  render() {
    return (
      <Field name='metal_purity_id' label='Metal purity' component={S} parse={pI} {...this.props} />
    );
  }
}

export class ColorId extends React.Component {
  render() {
    return (
      <Field name='color_id' label='Color' component={S} parse={pI} {...this.props} />
    );
  }
}

export class NetWeight extends React.Component {
  render() {
    return (
      <Field name='net_weight' label='Net weight' component={F} parse={pF} placeholder='Net weight' type='number' {...this.props} />
    );
  }
}

export class PurityPer extends React.Component {
  render() {
    return (
      <Field name='purity_per' label='Purity per' component={F} parse={pF} placeholder='Purity per' type='number' {...this.props} />
    );
  }
}

export class PureWeight extends React.Component {
  render() {
    return (
      <Field name='pure_weight' label='Pure weight' component={F} parse={pF} placeholder='Pure weight' type='number' {...this.props} />
    );
  }
}

export class Volume extends React.Component {
  render() {
    return (
      <Field name='volume' label='Volume' component={F} parse={pF} placeholder='Volume' type='number' {...this.props} />
    );
  }
}

export class DiamondPcs extends React.Component {
  render() {
    return (
      <Field name='diamond_pcs' label='Diamond pcs' component={F} parse={pI} placeholder='Diamond pcs' type='number' {...this.props} />
    );
  }
}

export class DiamondWeight extends React.Component {
  render() {
    return (
      <Field name='diamond_weight' label='Diamond weight' component={F} parse={pF} placeholder='Diamond weight' type='number' {...this.props} />
    );
  }
}

export class CsPcs extends React.Component {
  render() {
    return (
      <Field name='cs_pcs' label='Cs pcs' component={F} parse={pI} placeholder='Cs pcs' type='number' {...this.props} />
    );
  }
}

export class CsWeight extends React.Component {
  render() {
    return (
      <Field name='cs_weight' label='Cs weight' component={F} parse={pF} placeholder='Cs weight' type='number' {...this.props} />
    );
  }
}

export class GrossWeight extends React.Component {
  render() {
    return (
      <Field name='gross_weight' label='Gross weight' component={F} parse={pF} placeholder='Gross weight' type='number' {...this.props} />
    );
  }
}

export class Description extends React.Component {
  render() {
    return (
      <Field name='description' label='Description' component={F} {...this.props} />
    );
  }
}

export class Active extends React.Component {
  render() {
    return (
      <Field name='active' label='Active?' component={Sw} type='checkbox' {...this.props} />
    );
  }
}

// import { Position, Slug, CollectionId, MakingTypeId, SettingTypeId, DesignerId, MaterialId, MetalPurityId, ColorId, NetWeight, PurityPer, PureWeight, Volume, DiamondPcs, DiamondWeight, CsPcs, CsWeight, GrossWeight, Description, Active } from './_StyleFields'; // eslint-disable-line no-unused-vars
