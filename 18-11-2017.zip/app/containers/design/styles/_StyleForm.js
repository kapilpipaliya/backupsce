import _ from 'lodash';
import React, { Component } from 'react';
import { connect } from 'react-redux';

import { change, FieldArray, formValueSelector, reduxForm, SubmissionError } from 'redux-form/immutable';
import { withApollo } from 'react-apollo';
import { List } from 'immutable';
import { Button } from 'material-ui';
import { withStyles } from 'material-ui/styles';
import Grid from 'material-ui/Grid';
import Divider from 'material-ui/Divider';

import RenderDiamonds from '../../../components/form/RenderDiamonds';

// import RDatePicker from '../../../components/shared/CustomDatePicker/index'; // TODO make use of date
import HOCFetch from '../../HOC/Fetch';
import { fexecuteM, fexecuteA, fexecuteP, fexecuteColor, fexecuteCollection, fexecuteMakingType, fexecuteSettingType } from '../../../utils/Fetch';
import { Position, Slug, CollectionId, MakingTypeId, SettingTypeId, DesignerId, MaterialId, MetalPurityId, ColorId, NetWeight, PurityPer, PureWeight, Volume, DiamondPcs, DiamondWeight, CsPcs, CsWeight, GrossWeight, Description, Active } from './_StyleFields';
const styles = (theme) => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  formControl: {
    marginLeft: 0,
    marginRight: theme.spacing.unit,
    minWidth: 200,
  },
});

const FIELDS = {
// position: { },
  color_id: {},
  collection_id: {},
  slug: {},
  making_type_id: {},
  setting_type_id: {},
  designer_id: {},
  material_id: {},
  metal_purity_id: {},
  net_weight: {},
  purity_per: {},
  pure_weight: {},
  volume: {},
  // diamond_pcs: {},
  // diamond_weight: {},
  // cs_pcs: {},
  // cs_weight: {},
  gross_weight: {},
  description: {},
};
@withApollo
@HOCFetch
@withStyles(styles)
class StyleForm extends Component {
  state = {
    loading: false,
  };
  // Fetch Internal Options
  componentDidMount() {
    this.props.fetch(fexecuteM, 'materials', 1); // Fetch Materials.
    this.props.fetch(fexecuteA, 'accounts', 5); // Fetch Designer.
    this.props.fetch(fexecuteCollection, 'collections');
    this.props.fetch(fexecuteMakingType, 'makingTypes');
    this.props.fetch(fexecuteSettingType, 'settingTypes');
    if (this.props.initialValues) {
      const i = this.props.initialValues.toJS();
      this.props.fetch(fexecuteP, 'metal_purities', i.material_id);
      this.props.fetch(fexecuteColor, 'colors', i.material_id);
    }
  }
  submitForm = (values) => {
    this.setState({ loading: true });
    return this.props.action(values).then((errors) => {
      if (errors) {
        this.setState({ loading: false });
        throw new SubmissionError(errors);
      }
    });
  };

  render() {
    const {
      handleSubmit, pristine, reset, invalid, submitting, submitName,
    } = this.props;
    const { loading } = this.state;

    const { classes } = this.props;
    return (
      <form onSubmit={handleSubmit(this.submitForm)}>
        <fieldset>
          {/* <legend></legend> */}
          <Grid className={classes.container} container spacing={16}>
            <Grid item xs={2}><Position label="Position(optional)" /></Grid>
            <Grid item xs={4}><CollectionId options={this.props.collections} /></Grid>
            <Grid item xs={4}><Slug /></Grid>
            <Grid item xs={2}><DesignerId options={this.props.accounts} /></Grid>
            <Grid item xs={6}><MakingTypeId options={this.props.makingTypes} /></Grid>
            <Grid item xs={6}> <SettingTypeId options={this.props.settingTypes} /></Grid>
            <Grid item xs={2}><MaterialId
              options={this.props.materials}
              onChange2={(value) => {
                this.props.fetch(fexecuteP, 'metal_purities', value);
                this.props.fetch(fexecuteColor, 'colors', value);
              }}
            />
            </Grid>
            <Grid item xs={2}><MetalPurityId
              options={this.props.metal_purities}
              onChange2={(v) => {
                if (v) {
                  const purityPer = this.props.metal_purities[v].purity;
                  const netWeight = this.props.net_weight;
                  this.props.change('purity_per', this.props.metal_purities[v].purity);
                  this.props.change('pure_weight', (purityPer * this.props.net_weight) / 100);
                  this.props.change('volume', netWeight / this.props.metal_purities[v].specific_density);
                } else {
                  this.props.change('purity_per', 0);
                  this.props.change('pure_weight', 0);
                  this.props.change('volume', 0);
                }
              }}
            />
            </Grid>
            <Grid item xs={2}><ColorId options={this.props.colors} /></Grid>
            <Grid item xs={2}><NetWeight
              onChange2={(nw) => {
                this.props.calcTotals();
                if (this.props.metal_purity_id) {
                  this.props.change('pure_weight', (this.props.purity_per * nw) / 100);
                  this.props.change('volume', nw / this.props.metal_purities[this.props.metal_purity_id].specific_density);
                }
              }}
            />
            </Grid>
            <Grid item xs={1}><PurityPer label="Purity%" placeholder="Purity%" disabled /></Grid>
            <Grid item xs={2}><PureWeight disabled /></Grid>
            <Grid item xs={1}><Volume disabled /></Grid>

            <Grid item xs={2}><DiamondPcs disabled /></Grid>
            <Grid item xs={2}><DiamondWeight disabled /></Grid>
            <Grid item xs={2}><CsPcs label="CS Pcs" placeholder="CS Pcs" disabled /></Grid>
            <Grid item xs={2}><CsWeight label="CS Wt" placeholder="CS Wt" disabled /></Grid>
            <Grid item xs={4}><GrossWeight type="number" disabled /></Grid>
            <Grid item xs={12}><Description /></Grid>
            <Grid item xs={12}><Active /></Grid>
          </Grid>

          <FieldArray
            name="diamonds"
            component={RenderDiamonds}
            initial={this.props.initialValues.get('diamonds')}
            diamonds={this.props.diamonds}
            change={this.props.change}
            calcTotals={this.props.calcTotals}
          />
          <Divider light />
          <Button raised type="submit" disabled={loading || invalid || submitting}>{submitName}</Button>
          <Button raised disabled={loading || pristine || submitting} onClick={reset} style={{ margin: '5px' }}>Clear Values</Button>
          <Divider light />
          <p>* Required</p>
        </fieldset>
      </form>
    );
  }
}
// TODO Buttons should not be desabled when critical graphql errors occur.
function validate(values) {
  // IMPORTANT: values is an Immutable.Map here!
  const errors = {};

  _.each(FIELDS, (type, field) => {
    if (!values.get(field)) {
      errors[field] = "can't be blank";
    }
  });

  if (!values.get('diamonds') || !values.get('diamonds').size) {
    errors.diamonds = { _error: 'At least one diamond must be entered' };
  } else {
    // const styleDetailsArrayErrors = [];
    // values.diamonds.forEach((diamond, diamondIndex) => {
    //   const diamondErrors = {};
    //   if (!diamond || !diamond.material_id) {
    //     diamondErrors.material_id = 'Required';
    //     styleDetailsArrayErrors[diamondIndex] = diamondErrors;
    //   }
    //   if (!diamond || !diamond.gem_shape_id) {
    //     diamondErrors.gem_shape_id = 'Required';
    //     styleDetailsArrayErrors[diamondIndex] = diamondErrors;
    //   }
    //   if (!diamond || !diamond.gem_clarity_id) {
    //     diamondErrors.gem_clarity_id = 'Required';
    //     styleDetailsArrayErrors[diamondIndex] = diamondErrors;
    //   }
    //   if (!diamond || !diamond.color_id) {
    //     diamondErrors.color_id = 'Required';
    //     styleDetailsArrayErrors[diamondIndex] = diamondErrors;
    //   }
    //   if (!diamond || !diamond.gem_size_id) {
    //     diamondErrors.gem_size_id = 'Required';
    //     styleDetailsArrayErrors[diamondIndex] = diamondErrors;
    //   }
    //   if (!diamond || !diamond.pcs) {
    //     diamondErrors.pcs = 'Required';
    //     styleDetailsArrayErrors[diamondIndex] = diamondErrors;
    //   }
    //   if (!diamond || !diamond.pointer) {
    //     diamondErrors.pointer = 'Required';
    //     styleDetailsArrayErrors[diamondIndex] = diamondErrors;
    //   }
    //   if (!diamond || !diamond.weight) {
    //     diamondErrors.weight = 'Required';
    //     styleDetailsArrayErrors[diamondIndex] = diamondErrors;
    //   }
    // });
    // if (styleDetailsArrayErrors.length) {
    //   errors.diamonds = styleDetailsArrayErrors;
    // }
  }

  return errors;
}

// Never use toJS() in mapStateToProps
// http://redux.js.org/docs/recipes/UsingImmutableJS.html
const selector = formValueSelector('StyleForm'); // <-- same as form name
const mapStateToProps = (state) => {
  const position = selector(state, 'position');
  const slug = selector(state, 'slug');
  const {
    material_id, metal_purity_id, purity_per, net_weight,
  } = selector(state, 'material_id', 'metal_purity_id', 'purity_per', 'net_weight');
  let diamonds = selector(state, 'diamonds');
  if (!diamonds) diamonds = List();
  return {
    position,
    slug,
    material_id,
    metal_purity_id,
    purity_per,
    net_weight,
    diamonds,
  };
};

const mapDispatchToProps = (dispatch) => ({
  calcTotals: () => {
    dispatch(doTableActions());
  },
});

const C = connect(mapStateToProps, mapDispatchToProps)(StyleForm);

export default reduxForm({
  form: 'StyleForm',
  fields: _.keys(FIELDS),
  validate,
})(C);

// Actions. Redux-Thunk Can Return Function instead of action.
function doTableActions() {
  return (dispatch, getState) => {
    // dispatch(change('StyleForm', 'diamond_pcs', 11));
    const state = getState();
    // do some logic based on state, and then:
    const diamonds = selector(state, 'diamonds');
    const netWt = selector(state, 'net_weight');
    let dpcs = 0;
    let dwt = 0.0;
    let cspcs = 0;
    let cswt = 0.0;
    let grosswt = 0.0;
    if (diamonds) {
      _.forEach(diamonds.toJS(), (d) => {
        if (d.material_id === 4) {
          dpcs += d.pcs;
          dwt += d.weight;
        }
        if (d.material_id === 5) {
          cspcs += d.pcs;
          cswt += d.weight;
        }
        grosswt = netWt + ((dwt + cswt) / 5);
      });
      dispatch(change('StyleForm', 'diamond_pcs', dpcs));
      dispatch(change('StyleForm', 'diamond_weight', dwt));
      dispatch(change('StyleForm', 'cs_pcs', cspcs));
      dispatch(change('StyleForm', 'cs_weight', cswt));
      dispatch(change('StyleForm', 'gross_weight', grosswt));
    }
  };
}
/* You can also use this method to dispatch change in any form.
RenderDiamonds = connect(null,
  /* mapDispatchToProps = * function(dispatch) {
    return {
      // This will be passed as a property to the presentational component
      changeFieldValue: function (field, value) {
        dispatch(change(form, field, value))
      }
    }
  }
)
*/
