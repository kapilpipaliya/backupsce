import React, { Component } from 'react';
import Button from 'material-ui/Button';
import CollectionForm from './_CollectionForm';
import withCreateCollection from '../../../mutations/design/collections/createCollectionMutation';

class NewCollection extends Component {
  render() {
    return (
      <div>
        <h1>New Collection</h1>
        <CollectionForm action={this.props.createCollection} submitName="Create Collection" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateCollection(NewCollection);
