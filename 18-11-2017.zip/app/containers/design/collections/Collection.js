import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withCollection from '../../../queries/design/collections/collectionQuery';

class Collection extends Component {
  render() {
    const { collection, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="collection">
        <p>Collection</p>
        <h2 className="collection-heading">{collection.slug}</h2>
        <div className="collection-meta">
          <span className="collection-author">
            Posted by: <em>{/* {collection.author.name} */}</em>
          </span>
          <span className="collection-date">
            {moment(new Date(collection.created_at)).fromNow()}
          </span>
        </div>
        <div className="collection-content">
          contents display here: ID : {collection.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  collection: gql`
    fragment CollectionFragment on DesignCollection {
      id
      position
      slug
      collection
      parent_id { id slug }
      created_at
    }
  `,
};

export default withCollection(Collection);
