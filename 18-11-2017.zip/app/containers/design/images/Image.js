import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withImage from '../../../queries/design/images/imageQuery';

class Image extends Component {
  render() {
    const { image, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="image">
        <p>Image</p>
        <h2 className="image-heading">{image.slug}</h2>
        <div className="image-meta">
          <span className="image-author">
            Posted by: <em>{/* {image.author.name} */}</em>
          </span>
          <span className="image-date">
            {moment(new Date(image.created_at)).fromNow()}
          </span>
        </div>
        <div className="image-content">
          contents display here: ID : {image.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  image: gql`
    fragment ImageFragment on DesignImage {
      id
      imageable_type
      imageable_id { id slug }
      image
      created_at
    }
  `,
};

export default withImage(Image);
