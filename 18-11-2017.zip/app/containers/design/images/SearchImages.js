import React, { Component } from 'react';
import ListImages from './_ListImages';
import HeadListImages from './_HeadListImages';
import withImagesData from '../../../queries/design/images/imagesQuery';

class SearchImages extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.images = [];
    }
  }

  render() {
    const { images, imagesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreImages,
      firstImagesLoading,
    } = this.props;

    return (
      <div className="search-images">
        <h1>Searching images</h1>
        <HeadListImages
          initialKeywords={keywords}
          loading={firstImagesLoading}
        />

        {!firstImagesLoading && images && images.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListImages
            images={images}
            imagesCount={imagesCount}
            loading={loading}
            loadMoreImages={loadMoreImages}
          />
        )}
      </div>
    );
  }
}

export default withImagesData(SearchImages);
