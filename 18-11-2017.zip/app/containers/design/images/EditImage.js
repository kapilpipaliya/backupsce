import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import ImageForm from './_ImageForm';
import withImageForEditing from '../../../queries/design/images/imageForEditingQuery';
import withUpdateImage from '../../../mutations/design/images/updateImageMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditImage extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { image, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing image</h1>
        <ImageForm action={this.props.updateImage} initialValues={{ ...flatIDValue(image) }} submitName="Update Image" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  image: gql`
    fragment ImageForEditingFragment on DesignImage {
      id
      imageable_type
      imageable_id { id slug }
      image
    }
  `,
};

export default withImageForEditing(withUpdateImage(EditImage));
