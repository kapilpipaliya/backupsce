import AllImages from './AllImages';
import SearchImages from './SearchImages';
import Image from './Image';
import NewImage from './NewImage';
import EditImage from './EditImage';

export {
  AllImages,
  SearchImages,
  Image,
  NewImage,
  EditImage,
};
