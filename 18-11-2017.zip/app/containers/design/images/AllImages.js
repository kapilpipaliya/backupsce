import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withImagesData from '../../../queries/design/images/imagesQuery';

import ListImages from './_ListImages';
import HeadListImages from './_HeadListImages';

class AllImages extends Component {
  componentDidMount() {
    this.props.images.refetch(); // You can pass variables here.
  }

  render() {
    const { images: { loading, error }, images } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListImages />
        <ListImages data={images} />
      </div>
    );
  }
}

export default withImagesData(AllImages);
