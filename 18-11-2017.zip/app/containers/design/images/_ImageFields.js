import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';
import S from '../../../components/form/SimpleSelect';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI } from '../../../utils/libs';

export class ImageableType extends React.Component {
  render() {
    return (
      <Field name='imageable_type' label='Imageable type' component={F} {...this.props} />
    );
  }
}

export class ImageableId extends React.Component {
  render() {
    return (
      <Field name='imageable_id' label='Imageable' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Image extends React.Component {
  render() {
    return (
      <Field name='image' label='Image' component={F} {...this.props} />
    );
  }
}

// import { ImageableType, ImageableId, Image } from './_ImageFields'; // eslint-disable-line no-unused-vars
