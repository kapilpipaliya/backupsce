import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';
import Sw from '../../../components/form/RenderSwitch';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI } from '../../../utils/libs';

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class Slug extends React.Component {
  render() {
    return (
      <Field name='slug' label='Code' component={F} {...this.props} />
    );
  }
}

export class MakingType extends React.Component {
  render() {
    return (
      <Field name='making_type' label='Making type' component={F} {...this.props} />
    );
  }
}

export class Isdefault extends React.Component {
  render() {
    return (
      <Field name='isdefault' label='Isdefault?' component={Sw} type='checkbox' {...this.props} />
    );
  }
}

// import { Position, Slug, MakingType, Isdefault } from './_MakingTypeFields'; // eslint-disable-line no-unused-vars
