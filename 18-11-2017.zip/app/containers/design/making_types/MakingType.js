import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withMakingType from '../../../queries/design/making_types/makingTypeQuery';

class MakingType extends Component {
  render() {
    const { makingType, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="makingType">
        <p>MakingType</p>
        <h2 className="makingType-heading">{makingType.slug}</h2>
        <div className="makingType-meta">
          <span className="makingType-author">
            Posted by: <em>{/* {makingType.author.name} */}</em>
          </span>
          <span className="makingType-date">
            {moment(new Date(makingType.created_at)).fromNow()}
          </span>
        </div>
        <div className="makingType-content">
          contents display here: ID : {makingType.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  makingType: gql`
    fragment MakingTypeFragment on DesignMakingType {
      id
      position
      slug
      making_type
      isdefault
      created_at
    }
  `,
};

export default withMakingType(MakingType);
