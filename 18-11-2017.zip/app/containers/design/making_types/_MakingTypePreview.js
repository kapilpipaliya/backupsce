import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroyMakingType from '../../../mutations/design/making_types/destroyMakingTypeMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class MakingTypePreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroyMakingType(this.props.makingTypeRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { makingTypeRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(makingType.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/makingtypes/${makingTypeRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  makingType: gql`
    fragment MakingTypePreviewFragment on DesignMakingType {
      id
      position
      slug
      making_type
      isdefault
      created_at
    }
  `,
};

export default withDestroyMakingType(withCurrentUser(MakingTypePreview));
