import React, { Component } from 'react';
import ListMakingTypes from './_ListMakingTypes';
import HeadListMakingTypes from './_HeadListMakingTypes';
import withMakingTypesData from '../../../queries/design/making_types/makingTypesQuery';

class SearchMakingTypes extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.makingTypes = [];
    }
  }

  render() {
    const { makingTypes, makingTypesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreMakingTypes,
      firstMakingTypesLoading,
    } = this.props;

    return (
      <div className="search-makingTypes">
        <h1>Searching makingTypes</h1>
        <HeadListMakingTypes
          initialKeywords={keywords}
          loading={firstMakingTypesLoading}
        />

        {!firstMakingTypesLoading && makingTypes && makingTypes.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListMakingTypes
            makingTypes={makingTypes}
            makingTypesCount={makingTypesCount}
            loading={loading}
            loadMoreMakingTypes={loadMoreMakingTypes}
          />
        )}
      </div>
    );
  }
}

export default withMakingTypesData(SearchMakingTypes);
