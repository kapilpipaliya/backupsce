import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import MakingTypeForm from './_MakingTypeForm';
import withMakingTypeForEditing from '../../../queries/design/making_types/makingTypeForEditingQuery';
import withUpdateMakingType from '../../../mutations/design/making_types/updateMakingTypeMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditMakingType extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { makingType, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing makingType</h1>
        <MakingTypeForm action={this.props.updateMakingType} initialValues={{ ...flatIDValue(makingType) }} submitName="Update MakingType" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  makingType: gql`
    fragment MakingTypeForEditingFragment on DesignMakingType {
      id
      position
      slug
      making_type
      isdefault
    }
  `,
};

export default withMakingTypeForEditing(withUpdateMakingType(EditMakingType));
