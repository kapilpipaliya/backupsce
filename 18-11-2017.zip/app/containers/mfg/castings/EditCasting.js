import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import CastingForm from './_CastingForm';
import withCastingForEditing from '../../../queries/mfg/castings/castingForEditingQuery';
import withUpdateCasting from '../../../mutations/mfg/castings/updateCastingMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditCasting extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { casting, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing casting</h1>
        <CastingForm action={this.props.updateCasting} initialValues={{ ...flatIDValue(casting) }} submitName="Update Casting" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  casting: gql`
    fragment CastingForEditingFragment on MfgCasting {
      id
      position
      date
      slug
      employee_id { id slug }
      description
      t_issue
      t_issue_pure
      t_rcv
      t_rcv_pure
      loss
      loss_pure
    }
  `,
};

export default withCastingForEditing(withUpdateCasting(EditCasting));
