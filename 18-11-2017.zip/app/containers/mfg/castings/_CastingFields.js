import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';
import S from '../../../components/form/SimpleSelect';
import RDate from '../../../components/shared/CustomDatePicker/index';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI, parsefloat as pF } from '../../../utils/libs';

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class Date extends React.Component {
  render() {
    return (
      <Field name='date' label='Date' type='datetime' component={RDate} {...this.props} />
    );
  }
}

export class Slug extends React.Component {
  render() {
    return (
      <Field name='slug' label='Code' component={F} {...this.props} />
    );
  }
}

export class EmployeeId extends React.Component {
  render() {
    return (
      <Field name='employee_id' label='Employee' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Description extends React.Component {
  render() {
    return (
      <Field name='description' label='Description' component={F} {...this.props} />
    );
  }
}

export class TIssue extends React.Component {
  render() {
    return (
      <Field name='t_issue' label='T issue' component={F} parse={pF} placeholder='T issue' type='number' {...this.props} />
    );
  }
}

export class TIssuePure extends React.Component {
  render() {
    return (
      <Field name='t_issue_pure' label='T issue pure' component={F} parse={pF} placeholder='T issue pure' type='number' {...this.props} />
    );
  }
}

export class TRcv extends React.Component {
  render() {
    return (
      <Field name='t_rcv' label='T rcv' component={F} parse={pF} placeholder='T rcv' type='number' {...this.props} />
    );
  }
}

export class TRcvPure extends React.Component {
  render() {
    return (
      <Field name='t_rcv_pure' label='T rcv pure' component={F} parse={pF} placeholder='T rcv pure' type='number' {...this.props} />
    );
  }
}

export class Loss extends React.Component {
  render() {
    return (
      <Field name='loss' label='Loss' component={F} parse={pF} placeholder='Loss' type='number' {...this.props} />
    );
  }
}

export class LossPure extends React.Component {
  render() {
    return (
      <Field name='loss_pure' label='Loss pure' component={F} parse={pF} placeholder='Loss pure' type='number' {...this.props} />
    );
  }
}

// import { Position, Date, Slug, EmployeeId, Description, TIssue, TIssuePure, TRcv, TRcvPure, Loss, LossPure } from './_CastingFields'; // eslint-disable-line no-unused-vars
