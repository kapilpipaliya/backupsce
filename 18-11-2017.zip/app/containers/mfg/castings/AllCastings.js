import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withCastingsData from '../../../queries/mfg/castings/castingsQuery';

import ListCastings from './_ListCastings';
import HeadListCastings from './_HeadListCastings';

class AllCastings extends Component {
  componentDidMount() {
    this.props.castings.refetch(); // You can pass variables here.
  }

  render() {
    const { castings: { loading, error }, castings } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListCastings />
        <ListCastings data={castings} />
      </div>
    );
  }
}

export default withCastingsData(AllCastings);
