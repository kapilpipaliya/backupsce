import React, { Component } from 'react';

import { reduxForm, SubmissionError } from 'redux-form/immutable';
import Button from 'material-ui/Button';
import { withApollo } from 'react-apollo';
import { Position, Date, Slug, EmployeeId, Description, TIssue, TIssuePure, TRcv, TRcvPure, Loss, LossPure } from './_CastingFields'; // eslint-disable-line no-unused-vars
import { fexecuteA } from '../../../utils/Fetch';
import HOCFetch from '../../HOC/Fetch';
@withApollo
@HOCFetch
class CastingForm extends Component {
   state = { loading: false };

  // Fetch Internal Options
   componentDidMount() {
     this.props.fetch(fexecuteA, 'staffs', 1);
     // this.props.fetch(fexecuteLocations, 'locations');
     // this.props.fetch(fexecuteJob, 'jobs');
   }

  submitForm = (values) => {
    this.setState({ loading: true });
    return this.props.action(values).then((errors) => {
      if (errors) {
        this.setState({ loading: false });
        throw new SubmissionError(errors);
      }
    });
  }

  render() {
    const {
      handleSubmit, pristine, reset, invalid, submitting, submitName,
    } = this.props;
    const { loading } = this.state;

    return (
      // placeholder removed because of time-limit
      <form onSubmit={handleSubmit(this.submitForm)}>
        <fieldset>
          {/* <legend></legend> */}
          {/* <Position label="Position(optional)" component={RenderField} parse={pI} placeholder="Position" type='number'/> */}
          <br />
          <span>Date: </span>
          <Date />
          <Slug label="Batch Name" />
          <EmployeeId options={this.props.staffs} />
          <Description />
          <TIssue label="Total Issue Wt" disabled />
          <TIssuePure label="Total Issue Pure Wt" disabled />
          <TRcv label="Total Receive Wt" disabled />
          <TRcvPure label="Total Receive Pure Wt" disabled />
          <Loss label="Total Loss" disabled />
          <LossPure label="Total Loss Pure" disabled />
          <Button raised type="submit" disabled={loading || invalid || submitting}>{submitName}</Button>
          <Button raised disabled={loading || pristine || submitting} onClick={reset} style={{ margin: '5px' }}>Clear Values</Button>
        </fieldset>
      </form>
    );
  }
}

function validate(values) {
  const errors = {};
  if (!values.get('slug')) {
    errors.slug = "can't be blank";
  }
  if (!values.get('description')) {
    errors.description = "can't be blank";
  }
  if (!values.get('employee_id')) {
    errors.employee_id = "can't be blank";
  }
  return errors;
}

export default reduxForm({
  form: 'CastingForm',
  validate,
})(CastingForm);
