import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroySubDepartment from '../../../mutations/mfg/sub_departments/destroySubDepartmentMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class SubDepartmentPreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroySubDepartment(this.props.subDepartmentRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { subDepartmentRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(subDepartment.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/subdepartments/${subDepartmentRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  subDepartment: gql`
    fragment SubDepartmentPreviewFragment on MfgSubDepartment {
      id
      department_id { id slug }
      position
      slug
      sub_department
      created_at
    }
  `,
};

export default withDestroySubDepartment(withCurrentUser(SubDepartmentPreview));
