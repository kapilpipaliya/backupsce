import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withSubDepartment from '../../../queries/mfg/sub_departments/subDepartmentQuery';

class SubDepartment extends Component {
  render() {
    const { subDepartment, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="subDepartment">
        <p>SubDepartment</p>
        <h2 className="subDepartment-heading">{subDepartment.slug}</h2>
        <div className="subDepartment-meta">
          <span className="subDepartment-author">
            Posted by: <em>{/* {subDepartment.author.name} */}</em>
          </span>
          <span className="subDepartment-date">
            {moment(new Date(subDepartment.created_at)).fromNow()}
          </span>
        </div>
        <div className="subDepartment-content">
          contents display here: ID : {subDepartment.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  subDepartment: gql`
    fragment SubDepartmentFragment on MfgSubDepartment {
      id
      department_id { id slug }
      position
      slug
      sub_department
      created_at
    }
  `,
};

export default withSubDepartment(SubDepartment);
