import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import SubDepartmentPreview from './_SubDepartmentPreview';

class ListSubDepartments extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allMfgSubDepartments,
      // subDepartmentsCount,
      loading,
      error,
      // loadMoreSubDepartments,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allMfgSubDepartments}
        columns={[
          // @formatter:off
          { accessor: 'SubDepartmentPreview', Header: '-', Cell: (props) => <SubDepartmentPreview subDepartmentRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { Header: 'Department', Cell: (props) => (props.original.department_id ? props.original.department_id.slug : undefined) },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'slug', Header: 'Code' },
          { accessor: 'sub_department', Header: 'Sub department' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListSubDepartments;
