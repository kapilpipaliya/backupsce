import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withSubDepartmentsData from '../../../queries/mfg/sub_departments/subDepartmentsQuery';

import ListSubDepartments from './_ListSubDepartments';
import HeadListSubDepartments from './_HeadListSubDepartments';

class AllSubDepartments extends Component {
  componentDidMount() {
    this.props.subdepartments.refetch(); // You can pass variables here.
  }

  render() {
    const { subdepartments: { loading, error }, subdepartments } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListSubDepartments />
        <ListSubDepartments data={subdepartments} />
      </div>
    );
  }
}

export default withSubDepartmentsData(AllSubDepartments);
