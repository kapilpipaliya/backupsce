import React, { Component } from 'react';
import Button from 'material-ui/Button';
import SubDepartmentForm from './_SubDepartmentForm';
import withCreateSubDepartment from '../../../mutations/mfg/sub_departments/createSubDepartmentMutation';

class NewSubDepartment extends Component {
  render() {
    return (
      <div>
        <h1>New SubDepartment</h1>
        <SubDepartmentForm action={this.props.createSubDepartment} submitName="Create SubDepartment" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateSubDepartment(NewSubDepartment);
