import React, { Component } from 'react';
import ListSubDepartments from './_ListSubDepartments';
import HeadListSubDepartments from './_HeadListSubDepartments';
import withSubDepartmentsData from '../../../queries/mfg/sub_departments/subDepartmentsQuery';

class SearchSubDepartments extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.subDepartments = [];
    }
  }

  render() {
    const { subDepartments, subDepartmentsCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreSubDepartments,
      firstSubDepartmentsLoading,
    } = this.props;

    return (
      <div className="search-subDepartments">
        <h1>Searching subDepartments</h1>
        <HeadListSubDepartments
          initialKeywords={keywords}
          loading={firstSubDepartmentsLoading}
        />

        {!firstSubDepartmentsLoading && subDepartments && subDepartments.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListSubDepartments
            subDepartments={subDepartments}
            subDepartmentsCount={subDepartmentsCount}
            loading={loading}
            loadMoreSubDepartments={loadMoreSubDepartments}
          />
        )}
      </div>
    );
  }
}

export default withSubDepartmentsData(SearchSubDepartments);
