import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import SubDepartmentForm from './_SubDepartmentForm';
import withSubDepartmentForEditing from '../../../queries/mfg/sub_departments/subDepartmentForEditingQuery';
import withUpdateSubDepartment from '../../../mutations/mfg/sub_departments/updateSubDepartmentMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditSubDepartment extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { subDepartment, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing subDepartment</h1>
        <SubDepartmentForm action={this.props.updateSubDepartment} initialValues={{ ...flatIDValue(subDepartment) }} submitName="Update SubDepartment" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  subDepartment: gql`
    fragment SubDepartmentForEditingFragment on MfgSubDepartment {
      id
      department_id { id slug }
      position
      slug
      sub_department
    }
  `,
};

export default withSubDepartmentForEditing(withUpdateSubDepartment(EditSubDepartment));
