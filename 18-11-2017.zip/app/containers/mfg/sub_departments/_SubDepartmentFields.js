import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';
import S from '../../../components/form/SimpleSelect';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI } from '../../../utils/libs';

export class DepartmentId extends React.Component {
  render() {
    return (
      <Field name='department_id' label='Department' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class Slug extends React.Component {
  render() {
    return (
      <Field name='slug' label='Code' component={F} {...this.props} />
    );
  }
}

export class SubDepartment extends React.Component {
  render() {
    return (
      <Field name='sub_department' label='Sub department' component={F} {...this.props} />
    );
  }
}

// import { DepartmentId, Position, Slug, SubDepartment } from './_SubDepartmentFields'; // eslint-disable-line no-unused-vars
