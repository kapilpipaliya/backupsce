import AllSubDepartments from './AllSubDepartments';
import SearchSubDepartments from './SearchSubDepartments';
import SubDepartment from './SubDepartment';
import NewSubDepartment from './NewSubDepartment';
import EditSubDepartment from './EditSubDepartment';

export {
  AllSubDepartments,
  SearchSubDepartments,
  SubDepartment,
  NewSubDepartment,
  EditSubDepartment,
};
