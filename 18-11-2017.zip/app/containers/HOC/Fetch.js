import React from 'react';

const HOCFetch = (InnerComponent) => class extends React.Component {
  state = {};
  executeGeneralM = async (fn, mystate, id) => {
    const d = await fn(this.props.client, id);
    this.setState(() => ({ [mystate]: d }));
  };

  render() {
    return (
      <InnerComponent
        {...this.props}
        {...this.state}
        fetch={this.executeGeneralM}
      />
    );
  }
};

export default HOCFetch;
