import gql from 'graphql-tag';
export const ALL_MATERIALS_CHANGE_QUERY = gql`
query AllMaterialsChangeQuery($f_material_id: Int!) {
  allMaterialMetalPurities(f_material_id: $f_material_id) {
    id
    slug
    purity
    price
  }
  allMaterialGemShapes(f_material_id: $f_material_id) {
    id
    material_id {
      id
      slug
    }
    position
    slug
    shape
  }
  allMaterialGemClarities(f_material_id: $f_material_id) {
    id
    material_id {
      id
      slug
    }
    position
    slug
    clarity
  }
  allMaterialColors(f_material_id: $f_material_id) {
    id
    material_id {
      id
      slug
    }
    position
    slug
    color
  }
}
`;

export const ALL_SHAPE_OR_CLARITY_CHANGE_QUERY = gql`
query AllShapesChangeQuery($f_material_id: Int!, $f_gem_shape_id: Int!, $f_gem_clarity_id: Int) {
  allMaterialGemSizes(f_material_id: $f_material_id, f_gem_shape_id: $f_gem_shape_id, f_gem_clarity_id: $f_gem_clarity_id) {
    id
    material_id {
      id
      slug
    }
    gem_shape_id {
      id
      slug
    }
    position
    slug
    mm_size
    carat_weight
    price
  }
}
`;

export const ALL_STYLES_QUERY = gql`
query allDesignStylesQuery {
  allDesignStyles {
    id
    slug
  }
}
`;

export const ALL_JOBS_QUERY = gql`
query {
  allSaleJobs {
    id
    position
  }
}
`;

export const stylefragment = gql`
    fragment StyleForEditingFragment on DesignStyle {
      id
      position
      slug
      collection_id {
        id
        slug
      }
      making_type_id {
        id
        slug
      }
      setting_type_id {
        id
        slug
      }
      designer_id {
        id
        slug
      }
      material_id {
        id
        slug
      }
      metal_purity_id {
        id
        slug
      }
      color_id {
        id
        slug
      }
      diamonds{
        id
        material {
          id slug
        }
        gem_shape {
          id slug
        }
        gem_clarity {
          id slug
        }
        color {
          id slug
        }
        gem_size {
          id slug
        }
        pcs
        pointer
        weight
        created_at
        updated_at
      }
      net_weight
      purity_per
      pure_weight
      volume
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
      description
      active
    }
  `;

export const GET_STYLE_QUERY = gql`
  query getStyle($id: ID) {
    style(id: $id) {
      ...StyleForEditingFragment
    }
  }
  ${stylefragment}
`;
