// Utilites
import _ from 'lodash';
// React-Apollo

import { AllMaterialsQuery } from '../queries/material/materials/materialsQuery';
import { AllAccountsQuery } from '../queries/user/accounts/accountsQuery';
import { AllAccountTypesQuery } from '../queries/user/account_types/accountTypesQuery';
import { AllRolesQuery } from '../queries/user/roles/rolesQuery';
import { AllContactsQuery } from '../queries/user/contacts/contactsQuery';
import { AllCountriesQuery } from '../queries/user/countries/countriesQuery';
import { AllStatesQuery } from '../queries/user/states/statesQuery';
import { AllMetalPuritiesQuery } from '../queries/material/metal_purities/metalPuritiesQuery';
import { AllColorsQuery } from '../queries/material/colors/colorsQuery';
import { AllGemShapesQuery } from '../queries/material/gem_shapes/gemShapesQuery';
import { AllAccessoriesQuery } from '../queries/material/accessories/accessoriesQuery';
import { AllGemTypesQuery } from '../queries/material/gem_types/gemTypesQuery';
import { AllGemClaritiesQuery } from '../queries/material/gem_clarities/gemClaritiesQuery';
import { AllLocationsQuery } from '../queries/material/locations/locationsQuery';
import { AllLockersQuery } from '../queries/material/lockers/lockersQuery';
import { AllPrioritiesQuery } from '../queries/mfg/priorities/prioritiesQuery';
import { AllProductTypesQuery } from '../queries/mfg/product_types/productTypesQuery';
import { AllMTxnTypesQuery } from '../queries/sale/m_txn_types/mTxnTypesQuery';
import { AllCollectionsQuery } from '../queries/design/collections/collectionsQuery';
import { AllMakingTypesQuery } from '../queries/design/making_types/makingTypesQuery';
import { AllSettingTypesQuery } from '../queries/design/setting_types/settingTypesQuery';
import { ALL_MATERIALS_CHANGE_QUERY,
  ALL_SHAPE_OR_CLARITY_CHANGE_QUERY,
  ALL_STYLES_QUERY,
  GET_STYLE_QUERY,
  ALL_JOBS_QUERY } from './query';

export const fexecuteM = async (aClient, id) => {
  const result = await aClient.query({
    query: AllMaterialsQuery,
    variables: { f_m_type_id: id },
  });
  return _.mapKeys(result.data.allMaterialMaterials, (value) => value.id);
};

export const fexecuteMChange = async (aClient, mID) => {
  const result = await aClient.query({
    query: ALL_MATERIALS_CHANGE_QUERY,
    variables: { f_material_id: mID },
  });
  const metalpurities = _.mapKeys(result.data.allMaterialMetalPurities, (value) => value.id);
  const gemshapes = _.mapKeys(result.data.allMaterialGemShapes, (value) => value.id);
  const gemclarities = _.mapKeys(result.data.allMaterialGemClarities, (value) => value.id);
  const colors = _.mapKeys(result.data.allMaterialColors, (value) => value.id);
  return ({
    metalpurities, gemshapes, gemclarities, colors,
  });
};

export const fexecuteShapeorClarityChange = async (aClient, mID, shapeId, clarityId) => {
  const result = await aClient.query({
    query: ALL_SHAPE_OR_CLARITY_CHANGE_QUERY,
    variables: { f_material_id: mID, f_gem_shape_id: shapeId, f_gem_clarity_id: clarityId },
  });
  return _.mapKeys(result.data.allMaterialGemSizes, (value) => value.id);
};


export const fexecuteA = async (aClient, id) => {
  const result = await aClient.query({
    query: AllAccountsQuery,
    variables: { f_a_type_id: id },
  });
  return _.mapKeys(result.data.allUserAccounts, (value) => value.id);
};
export const fexecuteAR = async (aClient) => {
  const result = await aClient.query({
    query: AllRolesQuery,
  });
  return _.mapKeys(result.data.allUserRoles, (value) => value.id);
};

export const fexecuteAT = async (aClient) => {
  const result = await aClient.query({
    query: AllAccountTypesQuery,
  });
  return _.mapKeys(result.data.allUserAccountTypes, (value) => value.id);
};
export const fexecuteAContact = async (aClient) => {
  const result = await aClient.query({
    query: AllContactsQuery,
  });
  return _.mapKeys(result.data.allUserContacts, (value) => value.id);
};
export const fexecuteAC = async (aClient) => {
  const result = await aClient.query({
    query: AllCountriesQuery,
  });
  return _.mapKeys(result.data.allUserCountries, (value) => value.id);
};
export const fexecuteAS = async (aClient, cID) => {
  const result = await aClient.query({
    query: AllStatesQuery,
    variables: { f_country_id: cID },
  });
  return _.mapKeys(result.data.allUserStates, (value) => value.id);
};
export const fexecuteP = async (aClient, mID) => {
  const result = await aClient.query({
    query: AllMetalPuritiesQuery,
    variables: { f_material_id: mID },
  });
  return _.mapKeys(result.data.allMaterialMetalPurities, (value) => value.id);
};

export const fexecuteColor = async (aClient, mID) => {
  const result = await aClient.query({
    query: AllColorsQuery,
    variables: { f_material_id: mID },
  });
  return _.mapKeys(result.data.allMaterialColors, (value) => value.id);
};
export const fexecuteAccessory = async (aClient) => {
  const result = await aClient.query({
    query: AllAccessoriesQuery,
    // variables: {f_material_id: mID}
  });
  return _.mapKeys(result.data.allMaterialAccessories, (value) => value.id);
};
export const fexecuteGemType = async (aClient) => {
  const result = await aClient.query({
    query: AllGemTypesQuery,
    // variables: {f_material_id: mID}
  });
  return _.mapKeys(result.data.allMaterialGemTypes, (value) => value.id);
};

export const fexecuteClarity = async (aClient, mID) => {
  const result = await aClient.query({
    query: AllGemClaritiesQuery,
    variables: { f_material_id: mID },
  });
  return _.mapKeys(result.data.allMaterialGemClarities, (value) => value.id);
};

export const fexecuteShape = async (aClient, mID) => {
  const result = await aClient.query({
    query: AllGemShapesQuery,
    variables: { f_material_id: mID },
  });
  return _.mapKeys(result.data.allMaterialGemShapes, (value) => value.id);
};

export const fexecuteLocations = async (aClient) => {
  const result = await aClient.query({
    query: AllLocationsQuery,
  });
  return _.mapKeys(result.data.allMaterialLocations, (value) => value.id);
};
export const fexecuteLocker = async (aClient, tID) => {
  const result = await aClient.query({
    query: AllLockersQuery,
    variables: { f_location_id: tID },
  });
  return _.mapKeys(result.data.allMaterialLockers, (value) => value.id);
};
export const fexecutePriorities = async (aClient) => {
  const result = await aClient.query({
    query: AllPrioritiesQuery,
  });
  return _.mapKeys(result.data.allMfgPriorities, (value) => value.id);
};

export const fexecuteS = async (aClient) => {
  const result = await aClient.query({
    query: ALL_STYLES_QUERY,
  });
  return _.mapKeys(result.data.allDesignStyles, (value) => value.id);
};
export const fexecuteS2 = async (aClient, id) => {
  const result = await aClient.query({
    query: GET_STYLE_QUERY,
    variables: { id },
  });
  const styleComplete1 = Object.assign({}, result.data.style);
  // styleComplete1.diamonds = _.mapKeys(styleComplete1.diamonds, function(value, key) {return value.id;});
  return styleComplete1;
};

export const fexecuteMTxnType = async (aClient) => {
  const result = await aClient.query({
    query: AllMTxnTypesQuery,
  });
  return _.mapKeys(result.data.allSaleMTxnTypes, (value) => value.id);
};

export const fexecuteJob = async (aClient) => {
  const result = await aClient.query({
    query: ALL_JOBS_QUERY,
  });
  return _.mapKeys(result.data.allSaleJobs, (value) => value.id);
};

export const fexecuteCollection = async (aClient) => {
  const result = await aClient.query({
    query: AllCollectionsQuery,
  });
  return _.mapKeys(result.data.allDesignCollections, (value) => value.id);
};
export const fexecuteMakingType = async (aClient) => {
  const result = await aClient.query({
    query: AllMakingTypesQuery,
  });
  return _.mapKeys(result.data.allDesignMakingTypes, (value) => value.id);
};
export const fexecuteSettingType = async (aClient) => {
  const result = await aClient.query({
    query: AllSettingTypesQuery,
  });
  return _.mapKeys(result.data.allDesignSettingTypes, (value) => value.id);
};

export const fexecutePT = async (aClient) => {
  const result = await aClient.query({
    query: AllProductTypesQuery,
  });
  return _.mapKeys(result.data.allMfgProductTypes, (value) => value.id);
};
