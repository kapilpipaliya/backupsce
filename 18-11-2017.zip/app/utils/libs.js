import _ from 'lodash';
export const parseint = (value) => (value === undefined || value === '' ? undefined : parseInt(value, 10));
export const parsefloat = (value) =>
  value === undefined || value === '' ? undefined : parseFloat(value);

// a= {a:1, b:2, c:{id:1}, d: {id: 1}}
export const flatIDValue = (a) =>
  _.mapValues(a, (value) => {
    if (value == null) {
      return value;
    }
    if (typeof value === 'object' && value.hasOwnProperty('id')) { // eslint-disable-line
      return parseInt(value.id, 10);
    }
    return value;
  });

